﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using sp18RossJacksonHW4.Models;
using System.Data.Entity;

namespace sp18RossJacksonHW4.DAL
{
    public class AppDbContext : DbContext
    {
        //Constructor that invokes the base constructor
        public AppDbContext() : base("MyDBConnection") { }

        //Create the db set
        public DbSet<Vendor> Vendors { get; set; }
    }
}