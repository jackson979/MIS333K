﻿//Author:       Jackson Ross (jrr4557)
//Date:         February 07, 2018
//Assignment:   Homework 2
//Description:  This program will take an order from the user, ask the user what type of customer they are, then create an instance of the appropriate order object. Then, the program will populate the object using the user input and the class methods. Finally, the program will display a receipt with all object properties.

//default imported libraries
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ross_Jackson_HW2
{
    //create class for main program
    class Program
    {
        //create main method
        static void Main(string[] args)
        {
            //create string variables for the user input and order type
            String strOrderType;
            String strUserInput;

            //create boolean variable for the order type validation
            Boolean boolTypeValidation;

            //create a string variable to store the uppercase order type
            String strTypeUpper;

            //create int variables for quantities
            Int32 intPuzzles;
            Int32 intGames;
            Int32 intTotalItems;

            //begin do while loop that will run until the user has ordered at least 1 item
            do
            {
                //begin do while loop that will run until the user enters a non-negative number
                do
                {
                    //prompt user for quantity input
                    Console.WriteLine("Please enter the number of puzzles you wish to purchase: ");

                    //get user input and store it
                    strUserInput = Console.ReadLine();
                    Console.WriteLine();

                    //call the CheckItem method from the Validation class, passing it the user input; store the returned values in an int
                    intPuzzles = Validation.CheckItem(strUserInput);

                    //if the user entered an invalid number, print an error message
                    if (intPuzzles < 0)
                    {
                        Console.WriteLine("Error. Please enter a non-negative integer.");
                        Console.WriteLine();
                    }

                } while (intPuzzles == -1);

                //begin do while loop that will run until the user enters a non-negative number
                do
                {
                    //prompt user for quantity input
                    Console.WriteLine("Please enter the number of board games you wish to purchase: ");

                    //get user input and store it
                    strUserInput = Console.ReadLine();
                    Console.WriteLine();

                    //call the CheckItem method from the Validation class, passing it the user input; store the returned values in an int
                    intGames = Validation.CheckItem(strUserInput);

                    //if the user entered an invalid number, print an error message
                    if (intGames < 0)
                    {
                        Console.WriteLine("Error. Please enter a non-negative integer.");
                        Console.WriteLine();
                    }

                } while (intGames == -1);

                //calculate total items and store in an int
                intTotalItems = intGames + intPuzzles;

                //if the user did not order any items, print an error message
                if (intTotalItems == 0)
                {
                    Console.WriteLine("Error. Please enter at least one positive value.");
                    Console.WriteLine();
                }

            } while (intTotalItems == 0);

            //begin do while loop that will run until the user enters either CONSUMER or WHOLESALE (not case sensitive)
            do
            {
                //prompt the user to enter order type
                Console.WriteLine("Please enter type of order do you want to process ('CONSUMER' or 'WHOLESALE'): ");

                //get user input and store it
                strOrderType = Console.ReadLine();
                Console.WriteLine();

                //convert the order type to all upper case
                strTypeUpper = strOrderType.ToUpper();

                //call the CheckCustomerType function in the Validation class, passing it the user's code; store the result in a boolan
                boolTypeValidation = Validation.CheckCustomerType(strTypeUpper);

                //if the code was invalid, print an error message
                if (boolTypeValidation == false)
                {
                    Console.WriteLine("Error. Please enter either CONSUMER or WHOLESALE.");
                    Console.WriteLine();
                }

            } while (boolTypeValidation == false);

            //if the valid code is CONSUMER call the CheckoutConsumer method, passing it the quantities from the user
            if (strTypeUpper == "CONSUMER")
            {
                CheckoutConsumer(intPuzzles, intGames);
            }
            //otherwise call the CheckoutWholesale method, passing it the quantities from the user
            else
                if (strTypeUpper == "WHOLESALE")
            {
                CheckoutWholesale(intPuzzles, intGames);
            }

        }

        //create CheckoutConsumer method with no return type and two Int32 parameters
        public static void CheckoutConsumer(Int32 intPuzzles, Int32 intBoardGames)
        {
            //create string variable to store user input
            String strUserInput;

            //create an instance of the ConsumerOrder object
            ConsumerOrder ConsumerObject = new ConsumerOrder();

            //prompt the user for their name
            Console.WriteLine("Please enter your name: ");

            //get user input and store it in the input variable
            strUserInput = Console.ReadLine();
            Console.WriteLine();

            //set the object's CustomerType enum to CONSUMER
            ConsumerObject.CustomerType = CustomerType.CONSUMER;

            //set the object's CustomerName property to what the user just entered
            ConsumerObject.CustomerName = strUserInput;

            //populate the objects quantities with the values passed to CheckoutConsumer from main
            ConsumerObject.NumberOfPuzzles = intPuzzles;
            ConsumerObject.NumberOfGames = intBoardGames;

            //populate the rest of the properties by calling the CalcTotals() class function
            ConsumerObject.CalcTotals();

            //call the object's ToString() method and print the returned string
            Console.WriteLine(ConsumerObject.ToString());

            //code to keep the console open
            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }

        //create CheckoutWholesale method with no return type and two Int32 parameters
        public static void CheckoutWholesale(Int32 intPuzzles, Int32 intBoardGames)
        {
            //create string variables to store user input
            String strCodeInput;
            String strUserInput;
            String strPreferredCustomer;

            //create boolean variable for code validation
            Boolean boolCodeValidation;

            //create decimal variable to store the delivery fee
            Decimal decDeliveryFee;

            //create an instance of the WholesaleOrder object
            WholesaleOrder WholesaleObject = new WholesaleOrder();

            //begin do while loop that will run until the user enters a valid customer code
            do
            {
                //prompt the user for their customer code
                Console.WriteLine("Please enter your customer code: ");

                //get user input and store it in the input string
                strCodeInput = Console.ReadLine();
                Console.WriteLine();

                //call the CheckCustomerCode method in the Validation class, store the result in a boolean
                boolCodeValidation = Validation.CheckCustomerCode(strCodeInput);

                //if the code is invalid, print an error message
                if (boolCodeValidation == false)
                {
                    Console.WriteLine("Error. Please enter a valid customer code.");
                }

            } while (boolCodeValidation == false);

            //begin do while loop that will run until the user enters a non-negative number
            do
            {
                //prompt the user for their delivery fee
                Console.WriteLine("Please enter your delivery fee: ");

                //get user input and store it in the input string
                strUserInput = Console.ReadLine();
                Console.WriteLine();

                //call the CheckDeliveryFee method in the Validation class, store the result in a decimal
                decDeliveryFee = Validation.CheckDeliveryFee(strUserInput);

                //if the user's delivery fee is invalid, print an error message
                if (decDeliveryFee == -1)
                {
                    Console.WriteLine("Error. Please enter a non-negative number.");
                }

            } while (decDeliveryFee == -1);

            //prompt the user for their status as a preffered customer
            Console.WriteLine("Are you a preferred customer? (Y or N) ");

            //get user input, store it in a string, then convert that string to upper case (makes next step easier)
            strPreferredCustomer = Console.ReadLine().ToUpper();
            Console.WriteLine();

            //if the user is a preferred customer, set the object's PreferredCustomer property to true
            if (strPreferredCustomer == "Y")
            {
                WholesaleObject.PreferredCustomer = true;
            }
            //otherwise set the object's PreferredCustomer property to false
            else
            {
                WholesaleObject.PreferredCustomer = false;
            }

            //set the object's CustomerCode to the user's code
            WholesaleObject.CustomerCode = strCodeInput;

            //set the object's CustomerType enum to WHOLESALE
            WholesaleObject.CustomerType = CustomerType.WHOLESALE;

            //populate the object's quantities using the values passed to CheckoutWholesale from main
            WholesaleObject.NumberOfPuzzles = intPuzzles;
            WholesaleObject.NumberOfGames = intBoardGames;

            //populate the remaining properties using the CalcTotals class method
            WholesaleObject.CalcTotals(decDeliveryFee);

            //call the ToString method for the object and print the returned string
            Console.WriteLine(WholesaleObject.ToString());

            //code to keep the console open
            Console.WriteLine("Press Enter key to exit");
            Console.ReadLine();

        }

    }

}
