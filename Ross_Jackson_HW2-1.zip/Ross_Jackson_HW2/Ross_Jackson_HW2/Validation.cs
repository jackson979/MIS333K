﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ross_Jackson_HW2
{
    //create static Validation class
    static class Validation
    {
        //create static CheckCustomerCode method with a Boolean return type and 1 String parameter
        public static Boolean CheckCustomerCode(String strUserInput)
        {
            //create a variable and define it as the length of the string (using .Length)
            Int32 intLength = strUserInput.Length;

            //check to see if the code is shorter than 5 characters or longer than 7 characters; if it is, return false
            if (intLength < 5 || intLength > 7)
            {
                return false;
            }

            //for loop that will look at each individual character of the string
            foreach (char b in strUserInput)
            {
                //if the character is not a letter, return false
                if (!Char.IsLetter(b))
                {
                    return false;
                }
            }

            //return true if there is no fault in the code
            return true;

        }

        //create static CheckCustomerType method with a Boolean return type and 1 String parameter
        public static Boolean CheckCustomerType(String strUserInput)
        {
            //convert user input to upper case
            strUserInput = strUserInput.ToUpper();

            //return true if the input is a valid CustomerType, otherwise return false
            return Enum.IsDefined(typeof(CustomerType), strUserInput);
        }

        //create static CheckDeliveryFee method with a Decimal return type and 1 String parameter
        public static Decimal CheckDeliveryFee(String strUserInput)
        {
            //create Decimal variable to store a result
            Decimal decResult;

            //try to convert the user's input into a decimal; if successful, store the result
            try
            {

                decResult = Convert.ToDecimal(strUserInput);
            }
            //if the user did not enter a value that can convert to a decimal, return -1 (the flag value for the validation in main)
            catch
            {
                return -1;

            }

            //if the number that the user input is negative, return -1 (flag value)
            if (decResult < 0)
            {
                return -1;
            }

            //the number has been validated; return the number
            return decResult;

        }

        //create static CheckItem method with an Int32 return type and 1 String parameter
        public static Int32 CheckItem(String strUserInput)
        {
            //create Int variable to store a result
            Int32 intResult;

            //try to convert the user's input to an Int32; if successful, store the result
            try
            {

                intResult = Convert.ToInt32(strUserInput);
            }
            //if the user's input was not an integer, return -1 (flag value)
            catch
            {
                return -1;

            }

            //if the number the user entered was negative, return -1 (flag value)
            if (intResult < 0)
            {
                return -1;
            }

            //the number has been validated; return the number
            return intResult;
        }
    }
}
