﻿//default imported libraries
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ross_Jackson_HW2
{
    //create CustomerType enum
    public enum CustomerType { CONSUMER, WHOLESALE }

    //create an abstract class for Order (will be a parent class)
    public abstract class Order
    {
        //create decimal constants to store prices
        public const Decimal decPUZZLECOST = 8.00m;
        public const Decimal decBOARDGAMECOST = 12.00m;

        //create a property block for the CustomerType 
        public CustomerType CustomerType { get; set; }

        //create property blocks for the quantities of items and total items
        public Int32 NumberOfGames { get; set; }
        public Int32 NumberOfPuzzles { get; set; }
        public Int32 TotalItems { get; set; }

        //create property blocks for the subtotals and total
        public Decimal GamesSubtotal { get; set; }
        public Decimal PuzzlesSubtotal { get; set; }
        public Decimal Subtotal { get; set; }
        public Decimal Total { get; set; }


        //create CalcSubtotal method with no return type and 0 parameters
        public void CalcSubtotal()
        {
            //calculate the total items and populate the TotalItems property
            this.TotalItems = this.NumberOfGames + this.NumberOfPuzzles;

            //calculate the puzzle subtotal and populate the PuzzlesSubtotal property
            this.PuzzlesSubtotal = this.NumberOfPuzzles * decPUZZLECOST;

            //calculate the board game subtotal and populate the GamesSubtotal property
            this.GamesSubtotal = this.NumberOfGames * decBOARDGAMECOST;

            //calculate the overall subtotal and populate the Subtotal property
            this.Subtotal = this.PuzzlesSubtotal + this.GamesSubtotal;

        }
    }
}