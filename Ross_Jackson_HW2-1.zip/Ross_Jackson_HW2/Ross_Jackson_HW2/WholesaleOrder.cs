﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ross_Jackson_HW2
{
    //create WholesaleOrder class that extends the abstract Order class
    class WholesaleOrder : Order
    {
        //create a property block for the customer's code
        public String CustomerCode { get; set; }

        //create a property block for the delivery fee
        public Decimal DeliveryFee { get; set; }

        //create a property block for whether or not the customer is preferred
        public Boolean PreferredCustomer { get; set; }

        //declare the CalcTotals method with no return value and 1 decimal parameter
        public void CalcTotals(Decimal decDeliveryFee)
        {
            //call the CalcSubtotals so the child class can populate the subtotal properties
            base.CalcSubtotal();

            //if the customer is preferred, set thgeir delivery fee to 0 
            if (this.PreferredCustomer == true)
            {
                this.DeliveryFee = 0;
            }
            //otherwise set their delivery fee equal to what the user entered
            else
            {
                this.DeliveryFee = decDeliveryFee;
            }

            //calculate the total and use it to populate the Total property
            this.Total = this.Subtotal + this.DeliveryFee;

        }


        //create overriding ToString method with string return type and 0 parameters
        public override string ToString()
        {
            //convert total items to a string
            String strTotalItems = this.TotalItems.ToString();

            //convert all currency values to strings using the 'C' format specifier (gives is currency format)
            String strPuzzleSubtotal = this.PuzzlesSubtotal.ToString("C");
            String strGamesSubtotal = this.GamesSubtotal.ToString("C");
            String strSubtotal = this.Subtotal.ToString("C");
            String strDeliveryFee = this.DeliveryFee.ToString("C");
            String strTotal = this.Total.ToString("C");

            //create an instance of StringBuilder
            StringBuilder ws = new StringBuilder();

            //append the receipt items to the StringBuilder object in the desired order, use AppendLine so that it goes to the next line after each property is displayed
            ws.AppendLine("Customer Type:\t\t" + CustomerType);
            ws.AppendLine("Customer Code:\t\t" + CustomerCode);
            ws.AppendLine("Total Items:\t\t" + strTotalItems);
            ws.AppendLine("Puzzle Subtotal:\t" + strPuzzleSubtotal);
            ws.AppendLine("Games Subtotal:\t\t" + strGamesSubtotal);
            ws.AppendLine("Subtotal:\t\t" + strSubtotal);
            ws.AppendLine("Delivery Fee:\t\t" + strDeliveryFee);
            ws.AppendLine("Grand Total:\t\t" + strTotal);

            //convert the StringBuilder object to a string, then return that string
            return ws.ToString();
        }

    }
}
