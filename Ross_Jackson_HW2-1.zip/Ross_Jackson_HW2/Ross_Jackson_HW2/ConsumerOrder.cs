﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ross_Jackson_HW2
{
    //create ConsumerOrder class that extends the abstract Order class
    class ConsumerOrder : Order
    {
        //create decimal constant to store tax rate and set it to 8.25%
        public const Decimal decTaxRate = .0825m;

        //create a property block for the customer's name
        public String CustomerName { get; set; }

        //create a property block for the sales tax
        public Decimal SalesTax { get; set; }
        
        //create CalcTotals method with no return type and 0 parameters
        public void CalcTotals()
        {
            //call the CalcSubtotals so the child class can populate the subtotal properties
            base.CalcSubtotal();

            //calculate the sales tax and use it to populate the SalesTax property
            SalesTax = this.Subtotal * decTaxRate;

            //calculaate the total and use it to populate the Total property
            this.Total = this.Subtotal + SalesTax;

        }

        //create overriding ToString method with string return type and 0 parameters
        public override string ToString()
        {
            //convert total items to a string
            String strTotalItems = this.TotalItems.ToString();

            //convert all currency values to strings using the 'C' format specifier (gives is currency format)
            String strPuzzleSubtotal = this.PuzzlesSubtotal.ToString("C");
            String strGamesSubtotal = this.GamesSubtotal.ToString("C");
            String strSubtotal = this.Subtotal.ToString("C");
            String strSalesTax = this.SalesTax.ToString("C");
            String strTotal = this.Total.ToString("C");

            //create an instance of StringBuilder
            StringBuilder cs = new StringBuilder();

            //append the receipt items to the StringBuilder object in the desired order, use AppendLine so that it goes to the next line after each property is displayed
            cs.AppendLine("Customer Type:\t\t" + CustomerType);
            cs.AppendLine("Customer Name:\t\t" + CustomerName);
            cs.AppendLine("Total Items:\t\t" + strTotalItems);
            cs.AppendLine("Puzzle Subtotal:\t" + strPuzzleSubtotal);
            cs.AppendLine("Games Subtotal:\t\t" + strGamesSubtotal);
            cs.AppendLine("Subtotal:\t\t" + strSubtotal);
            cs.AppendLine("Sales Tax\t\t" + strSalesTax);
            cs.AppendLine("Grand Total:\t\t" + strTotal);

            //convert the StringBuilder object to a string, then return that string
            return cs.ToString();
        }
    }
}