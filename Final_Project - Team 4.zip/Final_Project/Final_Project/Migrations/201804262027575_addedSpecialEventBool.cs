namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addedSpecialEventBool : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Showings", "SpecialEvent", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Showings", "SpecialEvent");
        }
    }
}
