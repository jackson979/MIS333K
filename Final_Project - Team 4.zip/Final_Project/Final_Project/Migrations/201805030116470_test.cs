namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class test : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.CreditCards",
                c => new
                    {
                        CreditCardID = c.Int(nullable: false, identity: true),
                        CreditCardNumber = c.String(),
                        TypeOfCard = c.Int(nullable: false),
                        CVV = c.String(),
                    })
                .PrimaryKey(t => t.CreditCardID);
            
            AddColumn("dbo.AspNetUsers", "CreditCard_CreditCardID", c => c.Int());
            CreateIndex("dbo.AspNetUsers", "CreditCard_CreditCardID");
            AddForeignKey("dbo.AspNetUsers", "CreditCard_CreditCardID", "dbo.CreditCards", "CreditCardID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AspNetUsers", "CreditCard_CreditCardID", "dbo.CreditCards");
            DropIndex("dbo.AspNetUsers", new[] { "CreditCard_CreditCardID" });
            DropColumn("dbo.AspNetUsers", "CreditCard_CreditCardID");
            DropTable("dbo.CreditCards");
        }
    }
}
