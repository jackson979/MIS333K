namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AlphaNumSeats : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Tickets", "Seat", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Tickets", "Seat", c => c.Int(nullable: false));
        }
    }
}
