namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class IdentityandCCinfo : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AppRoleManagers",
                c => new
                    {
                        AppRoleManagerID = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.AppRoleManagerID);
            
            CreateTable(
                "dbo.AspNetRoles",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Name = c.String(nullable: false, maxLength: 256),
                        Discriminator = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.Name, unique: true, name: "RoleNameIndex");
            
            CreateTable(
                "dbo.AspNetUserRoles",
                c => new
                    {
                        UserId = c.String(nullable: false, maxLength: 128),
                        RoleId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.UserId, t.RoleId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .ForeignKey("dbo.AspNetRoles", t => t.RoleId, cascadeDelete: true)
                .Index(t => t.UserId)
                .Index(t => t.RoleId);
            
            CreateTable(
                "dbo.ChangePasswordViewModels",
                c => new
                    {
                        PasswordID = c.Int(nullable: false, identity: true),
                        OldPassword = c.String(nullable: false),
                        NewPassword = c.String(nullable: false, maxLength: 100),
                        ConfirmPassword = c.String(),
                        AppUser_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.PasswordID)
                .ForeignKey("dbo.AspNetUsers", t => t.AppUser_Id)
                .Index(t => t.AppUser_Id);
            
            CreateTable(
                "dbo.AspNetUsers",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        FirstName = c.String(nullable: false),
                        LastName = c.String(nullable: false),
                        Email = c.String(maxLength: 256),
                        EmailConfirmed = c.Boolean(nullable: false),
                        PasswordHash = c.String(),
                        SecurityStamp = c.String(),
                        PhoneNumber = c.String(),
                        PhoneNumberConfirmed = c.Boolean(nullable: false),
                        TwoFactorEnabled = c.Boolean(nullable: false),
                        LockoutEndDateUtc = c.DateTime(),
                        LockoutEnabled = c.Boolean(nullable: false),
                        AccessFailedCount = c.Int(nullable: false),
                        UserName = c.String(nullable: false, maxLength: 256),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.UserName, unique: true, name: "UserNameIndex");
            
            CreateTable(
                "dbo.AspNetUserClaims",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.String(nullable: false, maxLength: 128),
                        ClaimType = c.String(),
                        ClaimValue = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.AspNetUserLogins",
                c => new
                    {
                        LoginProvider = c.String(nullable: false, maxLength: 128),
                        ProviderKey = c.String(nullable: false, maxLength: 128),
                        UserId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.LoginProvider, t.ProviderKey, t.UserId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.IndexViewModels",
                c => new
                    {
                        IndexID = c.Int(nullable: false, identity: true),
                        HasPassword = c.Boolean(nullable: false),
                        UserName = c.String(),
                        Email = c.String(),
                        UserID = c.String(),
                        AppUser_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.IndexID)
                .ForeignKey("dbo.AspNetUsers", t => t.AppUser_Id)
                .Index(t => t.AppUser_Id);
            
            CreateTable(
                "dbo.LoginViewModels",
                c => new
                    {
                        LoginID = c.Int(nullable: false, identity: true),
                        Email = c.String(nullable: false),
                        Password = c.String(nullable: false),
                        RememberMe = c.Boolean(nullable: false),
                        AppUser_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.LoginID)
                .ForeignKey("dbo.AspNetUsers", t => t.AppUser_Id)
                .Index(t => t.AppUser_Id);
            
            CreateTable(
                "dbo.RegisterViewModels",
                c => new
                    {
                        RegisterID = c.Int(nullable: false, identity: true),
                        FirstName = c.String(nullable: false),
                        LastName = c.String(nullable: false),
                        Birthday = c.DateTime(nullable: false),
                        Email = c.String(nullable: false),
                        Address = c.String(nullable: false),
                        PhoneNumber = c.String(nullable: false),
                        Password = c.String(nullable: false, maxLength: 100),
                        ConfirmPassword = c.String(),
                        AppUser_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.RegisterID)
                .ForeignKey("dbo.AspNetUsers", t => t.AppUser_Id)
                .Index(t => t.AppUser_Id);
            
            CreateTable(
                "dbo.RoleEditModels",
                c => new
                    {
                        RoleEditID = c.Int(nullable: false, identity: true),
                        AppUser_Id = c.String(maxLength: 128),
                        Role_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.RoleEditID)
                .ForeignKey("dbo.AspNetUsers", t => t.AppUser_Id)
                .ForeignKey("dbo.AspNetRoles", t => t.Role_Id)
                .Index(t => t.AppUser_Id)
                .Index(t => t.Role_Id);
            
            CreateTable(
                "dbo.RoleModificationModels",
                c => new
                    {
                        RoleModificationID = c.Int(nullable: false, identity: true),
                        RoleName = c.String(nullable: false),
                        AppUser_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.RoleModificationID)
                .ForeignKey("dbo.AspNetUsers", t => t.AppUser_Id)
                .Index(t => t.AppUser_Id);
            
            AddColumn("dbo.Customers", "LastName", c => c.String(nullable: false));
            AddColumn("dbo.Customers", "CreditCardNumber", c => c.String());
            AddColumn("dbo.Customers", "AppUser_Id", c => c.String(maxLength: 128));
            AddColumn("dbo.Movies", "AppUser_Id", c => c.String(maxLength: 128));
            AddColumn("dbo.Movies", "RegisterViewModel_RegisterID", c => c.Int());
            AddColumn("dbo.Genres", "AppUser_Id", c => c.String(maxLength: 128));
            AddColumn("dbo.Showings", "AppUser_Id", c => c.String(maxLength: 128));
            AddColumn("dbo.Showings", "RegisterViewModel_RegisterID", c => c.Int());
            AddColumn("dbo.Employees", "AppUser_Id", c => c.String(maxLength: 128));
            CreateIndex("dbo.Movies", "AppUser_Id");
            CreateIndex("dbo.Movies", "RegisterViewModel_RegisterID");
            CreateIndex("dbo.Genres", "AppUser_Id");
            CreateIndex("dbo.Showings", "AppUser_Id");
            CreateIndex("dbo.Showings", "RegisterViewModel_RegisterID");
            CreateIndex("dbo.Customers", "AppUser_Id");
            CreateIndex("dbo.Employees", "AppUser_Id");
            AddForeignKey("dbo.Movies", "AppUser_Id", "dbo.AspNetUsers", "Id");
            AddForeignKey("dbo.Genres", "AppUser_Id", "dbo.AspNetUsers", "Id");
            AddForeignKey("dbo.Showings", "AppUser_Id", "dbo.AspNetUsers", "Id");
            AddForeignKey("dbo.Customers", "AppUser_Id", "dbo.AspNetUsers", "Id");
            AddForeignKey("dbo.Employees", "AppUser_Id", "dbo.AspNetUsers", "Id");
            AddForeignKey("dbo.Movies", "RegisterViewModel_RegisterID", "dbo.RegisterViewModels", "RegisterID");
            AddForeignKey("dbo.Showings", "RegisterViewModel_RegisterID", "dbo.RegisterViewModels", "RegisterID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AspNetUserRoles", "RoleId", "dbo.AspNetRoles");
            DropForeignKey("dbo.RoleModificationModels", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.RoleEditModels", "Role_Id", "dbo.AspNetRoles");
            DropForeignKey("dbo.RoleEditModels", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.Showings", "RegisterViewModel_RegisterID", "dbo.RegisterViewModels");
            DropForeignKey("dbo.Movies", "RegisterViewModel_RegisterID", "dbo.RegisterViewModels");
            DropForeignKey("dbo.RegisterViewModels", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.LoginViewModels", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.IndexViewModels", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.Employees", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.Customers", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.ChangePasswordViewModels", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserRoles", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.Showings", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.Genres", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.Movies", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserLogins", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserClaims", "UserId", "dbo.AspNetUsers");
            DropIndex("dbo.RoleModificationModels", new[] { "AppUser_Id" });
            DropIndex("dbo.RoleEditModels", new[] { "Role_Id" });
            DropIndex("dbo.RoleEditModels", new[] { "AppUser_Id" });
            DropIndex("dbo.RegisterViewModels", new[] { "AppUser_Id" });
            DropIndex("dbo.LoginViewModels", new[] { "AppUser_Id" });
            DropIndex("dbo.IndexViewModels", new[] { "AppUser_Id" });
            DropIndex("dbo.Employees", new[] { "AppUser_Id" });
            DropIndex("dbo.Customers", new[] { "AppUser_Id" });
            DropIndex("dbo.Showings", new[] { "RegisterViewModel_RegisterID" });
            DropIndex("dbo.Showings", new[] { "AppUser_Id" });
            DropIndex("dbo.Genres", new[] { "AppUser_Id" });
            DropIndex("dbo.Movies", new[] { "RegisterViewModel_RegisterID" });
            DropIndex("dbo.Movies", new[] { "AppUser_Id" });
            DropIndex("dbo.AspNetUserLogins", new[] { "UserId" });
            DropIndex("dbo.AspNetUserClaims", new[] { "UserId" });
            DropIndex("dbo.AspNetUsers", "UserNameIndex");
            DropIndex("dbo.ChangePasswordViewModels", new[] { "AppUser_Id" });
            DropIndex("dbo.AspNetUserRoles", new[] { "RoleId" });
            DropIndex("dbo.AspNetUserRoles", new[] { "UserId" });
            DropIndex("dbo.AspNetRoles", "RoleNameIndex");
            DropColumn("dbo.Employees", "AppUser_Id");
            DropColumn("dbo.Showings", "RegisterViewModel_RegisterID");
            DropColumn("dbo.Showings", "AppUser_Id");
            DropColumn("dbo.Genres", "AppUser_Id");
            DropColumn("dbo.Movies", "RegisterViewModel_RegisterID");
            DropColumn("dbo.Movies", "AppUser_Id");
            DropColumn("dbo.Customers", "AppUser_Id");
            DropColumn("dbo.Customers", "CreditCardNumber");
            DropColumn("dbo.Customers", "LastName");
            DropTable("dbo.RoleModificationModels");
            DropTable("dbo.RoleEditModels");
            DropTable("dbo.RegisterViewModels");
            DropTable("dbo.LoginViewModels");
            DropTable("dbo.IndexViewModels");
            DropTable("dbo.AspNetUserLogins");
            DropTable("dbo.AspNetUserClaims");
            DropTable("dbo.AspNetUsers");
            DropTable("dbo.ChangePasswordViewModels");
            DropTable("dbo.AspNetUserRoles");
            DropTable("dbo.AspNetRoles");
            DropTable("dbo.AppRoleManagers");
        }
    }
}
