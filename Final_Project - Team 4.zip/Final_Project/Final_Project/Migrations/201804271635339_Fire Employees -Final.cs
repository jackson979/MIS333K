namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class FireEmployeesFinal : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AspNetUsers", "IsNotActive", c => c.Boolean(nullable: false));
            DropColumn("dbo.AspNetUsers", "IsActive");
        }
        
        public override void Down()
        {
            AddColumn("dbo.AspNetUsers", "IsActive", c => c.Boolean(nullable: false));
            DropColumn("dbo.AspNetUsers", "IsNotActive");
        }
    }
}
