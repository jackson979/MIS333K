using System.Data.Entity.Migrations;
using System;
using System.Linq;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Final_Project.DAL;
using Final_Project.Models;

namespace Final_Project.Migrations
{
    public class CustomerData
    {
        public void SeedCustomers(AppDbContext db)
        {
            AppUserManager UserManager = new AppUserManager(new UserStore<AppUser>(db));

            AppUser user1 = db.Users.FirstOrDefault(u => u.Email == "cbaker@example.com");
            if (user1 == null)
            {
                user1 = new AppUser();
                //user1.Id = "5001";
                user1.Password = "hello1";
                user1.LastName = "Baker";
                user1.FirstName = "Christopher";
                user1.MiddleInitial = "L.";
                user1.Birthday = new DateTime(1949, 11, 23);
                user1.TypeOfEmployee = EmpType.Customer;
                user1.Address = "1245 Lake Anchorage Blvd.";
                user1.City = "Austin";
                user1.State = "TX";
                user1.Zip = "78705";
                user1.PhoneNumber = "5125550180";
                user1.Email = "cbaker@example.com";
                user1.UserName = "cbaker@example.com";
                user1.PopcornPoints = 110;

                var result = UserManager.Create(user1, "hello1");
                db.SaveChanges();
                user1 = db.Users.First(u => u.UserName == "cbaker@example.com");
            }

            AppUser user2 = db.Users.FirstOrDefault(u => u.Email == "banker@longhorn.net");
            if (user2 == null)
            {
                user2 = new AppUser();
                //user2.Id = "5002";
                user2.Password = "potato";
                user2.LastName = "Banks";
                user2.FirstName = "Michelle";
                user2.MiddleInitial = "nan";
                user2.Birthday = new DateTime(1962, 11, 27);
                user2.TypeOfEmployee = EmpType.Customer;
                user2.Address = "1300 Tall Pine Lane";
                user2.City = "Austin";
                user2.State = "TX";
                user2.Zip = "78712";
                user2.PhoneNumber = "5125550183";
                user2.Email = "banker@longhorn.net";
                user2.UserName = "banker@longhorn.net";
                user2.PopcornPoints = 40;

                var result = UserManager.Create(user2, "potato");
                db.SaveChanges();
                user2 = db.Users.First(u => u.UserName == "banker@longhorn.net");
            }

            AppUser user3 = db.Users.FirstOrDefault(u => u.Email == "franco@example.com");
            if (user3 == null)
            {
                user3 = new AppUser();
                //user3.Id = "5003";
                user3.Password = "painting";
                user3.LastName = "Broccolo";
                user3.FirstName = "Franco";
                user3.MiddleInitial = "V";
                user3.Birthday = new DateTime(1992, 10, 11);
                user2.TypeOfEmployee = EmpType.Customer;
                user3.Address = "62 Browning Road";
                user3.City = "Austin";
                user3.State = "TX";
                user3.Zip = "78704";
                user3.PhoneNumber = "5125550128";
                user3.Email = "franco@example.com";
                user3.UserName = "franco@example.com";
                user3.PopcornPoints = 30;

                var result = UserManager.Create(user3, "painting");
                db.SaveChanges();
                user3 = db.Users.First(u => u.UserName == "franco@example.com");
            }

            AppUser user4 = db.Users.FirstOrDefault(u => u.Email == "wchang@example.com");
            if (user4 == null)
            {
                user4 = new AppUser();
                //user4.Id = "5004";
                user4.Password = "texas1";
                user4.LastName = "Chang";
                user4.FirstName = "Wendy";
                user4.MiddleInitial = "L";
                user4.Birthday = new DateTime(1997, 5, 16);
                user4.TypeOfEmployee = EmpType.Customer;
                user4.Address = "202 Bellmont Hall";
                user4.City = "Round Rock";
                user4.State = "TX";
                user4.Zip = "78681";
                user4.PhoneNumber = "5125550133";
                user4.Email = "wchang@example.com";
                user4.UserName = "wchang@example.com";
                user4.PopcornPoints = 0;

                var result = UserManager.Create(user4, "texas1");
                db.SaveChanges();
                user4 = db.Users.First(u => u.UserName == "wchang@example.com");
            }

            AppUser user5 = db.Users.FirstOrDefault(u => u.Email == "limchou@gogle.com");
            if (user5 == null)
            {
                user5 = new AppUser();
                //user5.Id = "5005";
                user5.Password = "Anchorage";
                user5.LastName = "Chou";
                user5.FirstName = "Lim";
                user5.MiddleInitial = "nan";
                user5.Birthday = new DateTime(1970, 4, 6);
                user5.TypeOfEmployee = EmpType.Customer;
                user5.Address = "1600 Teresa Lane";
                user5.City = "Austin";
                user5.State = "TX";
                user5.Zip = "78705";
                user5.PhoneNumber = "5125550102";
                user5.Email = "limchou@gogle.com";
                user5.UserName = "limchou@gogle.com";
                user5.PopcornPoints = 40;

                var result = UserManager.Create(user5, "Anchorage");
                db.SaveChanges();
                user5 = db.Users.First(u => u.UserName == "limchou@gogle.com");
            }

            AppUser user6 = db.Users.FirstOrDefault(u => u.Email == "shdixon@aoll.com");
            if (user6 == null)
            {
                user6 = new AppUser();
                //user6.Id = "5006";
                user6.Password = "pepperoni";
                user6.LastName = "Dixon";
                user6.FirstName = "Shan";
                user6.MiddleInitial = "D";
                user6.Birthday = new DateTime(1984, 1, 12);
                user6.TypeOfEmployee = EmpType.Customer;
                user6.Address = "234 Holston Circle";
                user6.City = "Austin";
                user6.State = "TX";
                user6.Zip = "78712";
                user6.PhoneNumber = "5125550146";
                user6.Email = "shdixon@aoll.com";
                user6.UserName = "shdixon@aoll.com";
                user6.PopcornPoints = 20;

                var result = UserManager.Create(user6, "pepperoni");
                db.SaveChanges();
                user6 = db.Users.First(u => u.UserName == "shdixon@aoll.com");
            }

            AppUser user7 = db.Users.FirstOrDefault(u => u.Email == "j.b.evans@aheca.org");
            if (user7 == null)
            {
                user7 = new AppUser();
                //user7.Id = "5007";
                user7.Password = "longhorns";
                user7.LastName = "Evans";
                user7.FirstName = "Jim Bob";
                user7.MiddleInitial = "nan";
                user7.Birthday = new DateTime(1959, 9, 9);
                user7.TypeOfEmployee = EmpType.Customer;
                user7.Address = "506 Farrell Circle";
                user7.City = "Georgetown";
                user7.State = "TX";
                user7.Zip = "78628";
                user7.PhoneNumber = "5125550170";
                user7.Email = "j.b.evans@aheca.org";
                user7.UserName = "j.b.evans@aheca.org";
                user7.PopcornPoints = 50;

                var result = UserManager.Create(user7, "longhorns");
                db.SaveChanges();
                user7 = db.Users.First(u => u.UserName == "j.b.evans@aheca.org");
            }

            AppUser user8 = db.Users.FirstOrDefault(u => u.Email == "feeley@penguin.org");
            if (user8 == null)
            {
                user8 = new AppUser();
                //user8.Id = "5008";
                user8.Password = "aggies";
                user8.LastName = "Feeley";
                user8.FirstName = "Lou Ann";
                user8.MiddleInitial = "K";
                user8.Birthday = new DateTime(2001, 1, 12);
                user8.TypeOfEmployee = EmpType.Customer;
                user8.Address = "600 S 8th Street W";
                user8.City = "Austin";
                user8.State = "TX";
                user8.Zip = "78746";
                user8.PhoneNumber = "5125550105";
                user8.Email = "feeley@penguin.org";
                user8.UserName = "feeley@penguin.org";
                user8.PopcornPoints = 170;

                var result = UserManager.Create(user8, "aggies");
                db.SaveChanges();
                user8 = db.Users.First(u => u.UserName == "feeley@penguin.org");
            }

            AppUser user9 = db.Users.FirstOrDefault(u => u.Email == "tfreeley@minnetonka.ci.us");
            if (user9 == null)
            {
                user9 = new AppUser();
                //user9.Id = "5009";
                user9.Password = "raiders";
                user9.LastName = "Freeley";
                user9.FirstName = "Tesa";
                user9.MiddleInitial = "P";
                user9.Birthday = new DateTime(1991, 2, 4);
                user9.TypeOfEmployee = EmpType.Customer;
                user9.Address = "4448 Fairview Ave.";
                user9.City = "Horseshoe Bay";
                user9.State = "TX";
                user9.Zip = "78657";
                user9.PhoneNumber = "5125550114";
                user9.Email = "tfreeley@minnetonka.ci.us";
                user9.UserName = "tfreeley@minnetonka.ci.us";
                user9.PopcornPoints = 160;

                var result = UserManager.Create(user9, "raiders");
                db.SaveChanges();
                user9 = db.Users.First(u => u.UserName == "tfreeley@minnetonka.ci.us");
            }

            AppUser user10 = db.Users.FirstOrDefault(u => u.Email == "mgarcia@gogle.com");
            if (user10 == null)
            {
                user10 = new AppUser();
                //user10.Id = "5010";
                user10.Password = "mustangs";
                user10.LastName = "Garcia";
                user10.FirstName = "Margaret";
                user10.MiddleInitial = "L";
                user10.Birthday = new DateTime(1991, 10, 2);
                user10.TypeOfEmployee = EmpType.Customer;
                user10.Address = "594 Longview";
                user10.City = "Austin";
                user10.State = "TX";
                user10.Zip = "78727";
                user10.PhoneNumber = "5125550155";
                user10.Email = "mgarcia@gogle.com";
                user10.UserName = "mgarcia@gogle.com";
                user10.PopcornPoints = 10;

                var result = UserManager.Create(user10, "mustangs");
                db.SaveChanges();
                user10 = db.Users.First(u => u.UserName == "mgarcia@gogle.com");
            }

            AppUser user11 = db.Users.FirstOrDefault(u => u.Email == "chaley@thug.com");
            if (user11 == null)
            {
                user11 = new AppUser();
                //user11.Id = "5011";
                user11.Password = "onetime";
                user11.LastName = "Haley";
                user11.FirstName = "Charles";
                user11.MiddleInitial = "E";
                user11.Birthday = new DateTime(1974, 7, 10);
                user11.TypeOfEmployee = EmpType.Customer;
                user11.Address = "One Cowboy Pkwy";
                user11.City = "Austin";
                user11.State = "TX";
                user11.Zip = "78712";
                user11.PhoneNumber = "5125550116";
                user11.Email = "chaley@thug.com";
                user11.UserName = "chaley@thug.com";
                user11.PopcornPoints = 40;

                var result = UserManager.Create(user11, "onetime");
                db.SaveChanges();
                user11 = db.Users.First(u => u.UserName == "chaley@thug.com");
            }

            AppUser user12 = db.Users.FirstOrDefault(u => u.Email == "jeffh@sonic.com");
            if (user12 == null)
            {
                user12 = new AppUser();
                //user12.Id = "5012";
                user12.Password = "hampton1";
                user12.LastName = "Hampton";
                user12.FirstName = "Jeffrey";
                user12.MiddleInitial = "T.";
                user12.Birthday = new DateTime(2004, 3, 10);
                user12.TypeOfEmployee = EmpType.Customer;
                user12.Address = "337 38th St.";
                user12.City = "San Marcos";
                user12.State = "TX";
                user12.Zip = "78666";
                user12.PhoneNumber = "5125550150";
                user12.Email = "jeffh@sonic.com";
                user12.UserName = "jeffh@sonic.com";
                user12.PopcornPoints = 150;

                var result = UserManager.Create(user12, "hampton1");
                db.SaveChanges();
                user12 = db.Users.First(u => u.UserName == "jeffh@sonic.com");
            }

            AppUser user13 = db.Users.FirstOrDefault(u => u.Email == "wjhearniii@umich.org");
            if (user13 == null)
            {
                user13 = new AppUser();
                //user13.Id = "5013";
                user13.Password = "jhearn22";
                user13.LastName = "Hearn";
                user13.FirstName = "John";
                user13.MiddleInitial = "B";
                user13.Birthday = new DateTime(1950, 8, 5);
                user13.TypeOfEmployee = EmpType.Customer;
                user13.Address = "4225 North First";
                user13.City = "Austin";
                user13.State = "TX";
                user13.Zip = "78705";
                user13.PhoneNumber = "5125550196";
                user13.Email = "wjhearniii@umich.org";
                user13.UserName = "wjhearniii@umich.org";
                user13.PopcornPoints = 0;

                var result = UserManager.Create(user13, "jhearn22");
                db.SaveChanges();
                user13 = db.Users.First(u => u.UserName == "wjhearniii@umich.org");
            }

            AppUser user14 = db.Users.FirstOrDefault(u => u.Email == "ahick@yaho.com");
            if (user14 == null)
            {
                user14 = new AppUser();
                //user14.Id = "5014";
                user14.Password = "hickhickup";
                user14.LastName = "Hicks";
                user14.FirstName = "Anthony";
                user14.MiddleInitial = "J";
                user14.Birthday = new DateTime(2004, 12, 8);
                user14.TypeOfEmployee = EmpType.Customer;
                user14.Address = "32 NE Garden Ln., Ste 910";
                user14.City = "Austin";
                user14.State = "TX";
                user14.Zip = "78712";
                user14.PhoneNumber = "5125550188";
                user14.Email = "ahick@yaho.com";
                user14.UserName = "ahick@yaho.com";
                user14.PopcornPoints = 60;

                var result = UserManager.Create(user14, "hickhickup");
                db.SaveChanges();
                user14 = db.Users.First(u => u.UserName == "ahick@yaho.com");
            }

            AppUser user15 = db.Users.FirstOrDefault(u => u.Email == "ingram@jack.com");
            if (user15 == null)
            {
                user15 = new AppUser();
                //user15.Id = "5015";
                user15.Password = "ingram2015";
                user15.LastName = "Ingram";
                user15.FirstName = "Brad";
                user15.MiddleInitial = "S.";
                user15.Birthday = new DateTime(2001, 9, 5);
                user15.TypeOfEmployee = EmpType.Customer;
                user15.Address = "6548 La Posada Ct.";
                user15.City = "New York";
                user15.State = "NY";
                user15.Zip = "10101";
                user15.PhoneNumber = "5125550116";
                user15.Email = "ingram@jack.com";
                user15.UserName = "ingram@jack.com";
                user15.PopcornPoints = 20;

                var result = UserManager.Create(user15, "ingram2015");
                db.SaveChanges();
                user15 = db.Users.First(u => u.UserName == "ingram@jack.com");
            }

            AppUser user16 = db.Users.FirstOrDefault(u => u.Email == "toddj@yourmom.com");
            if (user16 == null)
            {
                user16 = new AppUser();
                //user16.Id = "5016";
                user16.Password = "toddy25";
                user16.LastName = "Jacobs";
                user16.FirstName = "Todd";
                user16.MiddleInitial = "L.";
                user16.Birthday = new DateTime(1999, 1, 20);
                user16.TypeOfEmployee = EmpType.Customer;
                user16.Address = "4564 Elm St.";
                user16.City = "Austin";
                user16.State = "TX";
                user16.Zip = "78729";
                user16.PhoneNumber = "5125550166";
                user16.Email = "toddj@yourmom.com";
                user16.UserName = "toddj@yourmom.com";
                user16.PopcornPoints = 170;

                var result = UserManager.Create(user16, "toddy25");
                db.SaveChanges();
                user16 = db.Users.First(u => u.UserName == "toddj@yourmom.com");
            }

            AppUser user17 = db.Users.FirstOrDefault(u => u.Email == "thequeen@aska.net");
            if (user17 == null)
            {
                user17 = new AppUser();
                //user17.Id = "5017";
                user17.Password = "something";
                user17.LastName = "Lawrence";
                user17.FirstName = "Victoria";
                user17.MiddleInitial = "M.";
                user17.Birthday = new DateTime(2000, 4, 14);
                user17.TypeOfEmployee = EmpType.Customer;
                user17.Address = "6639 Butterfly Ln.";
                user17.City = "Beverly Hills";
                user17.State = "CA";
                user17.Zip = "90210";
                user17.PhoneNumber = "5125550173";
                user17.Email = "thequeen@aska.net";
                user17.UserName = "thequeen@aska.net";
                user17.PopcornPoints = 130;

                var result = UserManager.Create(user17, "something");
                db.SaveChanges();
                user17 = db.Users.First(u => u.UserName == "thequeen@aska.net");
            }

            AppUser user18 = db.Users.FirstOrDefault(u => u.Email == "linebacker@gogle.com");
            if (user18 == null)
            {
                user18 = new AppUser();
                //user18.Id = "5018";
                user18.Password = "Password1";
                user18.LastName = "Lineback";
                user18.FirstName = "Erik";
                user18.MiddleInitial = "W";
                user18.Birthday = new DateTime(2003, 12, 2);
                user18.TypeOfEmployee = EmpType.Customer;
                user18.Address = "1300 Netherland St";
                user18.City = "Austin";
                user18.State = "TX";
                user18.Zip = "78758";
                user18.PhoneNumber = "5125550167";
                user18.Email = "linebacker@gogle.com";
                user18.UserName = "linebacker@gogle.com";
                user18.PopcornPoints = 60;

                var result = UserManager.Create(user18, "Password1");
                db.SaveChanges();
                user18 = db.Users.First(u => u.UserName == "linebacker@gogle.com");
            }

            AppUser user19 = db.Users.FirstOrDefault(u => u.Email == "elowe@netscare.net");
            if (user19 == null)
            {
                user19 = new AppUser();
                //user19.Id = "5019";
                user19.Password = "aclfest2017";
                user19.LastName = "Lowe";
                user19.FirstName = "Ernest";
                user19.MiddleInitial = "S";
                user19.Birthday = new DateTime(1977, 12, 7);
                user19.TypeOfEmployee = EmpType.Customer;
                user19.Address = "3201 Pine Drive";
                user19.City = "New Braunfels";
                user19.State = "TX";
                user19.Zip = "78130";
                user19.PhoneNumber = "5125550187";
                user19.Email = "elowe@netscare.net";
                user19.UserName = "elowe@netscare.net";
                user19.PopcornPoints = 20;

                var result = UserManager.Create(user19, "aclfest2017");
                db.SaveChanges();
                user19 = db.Users.First(u => u.UserName == "elowe@netscare.net");
            }

            AppUser user20 = db.Users.FirstOrDefault(u => u.Email == "cluce@gogle.com");
            if (user20 == null)
            {
                user20 = new AppUser();
                //user20.Id = "5020";
                user20.Password = "nothinggood";
                user20.LastName = "Luce";
                user20.FirstName = "Chuck";
                user20.MiddleInitial = "B";
                user20.Birthday = new DateTime(1949, 3, 16);
                user20.TypeOfEmployee = EmpType.Customer;
                user20.Address = "2345 Rolling Clouds";
                user20.City = "Cactus";
                user20.State = "TX";
                user20.Zip = "79013";
                user20.PhoneNumber = "5125550141";
                user20.Email = "cluce@gogle.com";
                user20.UserName = "cluce@gogle.com";
                user20.PopcornPoints = 180;

                var result = UserManager.Create(user20, "nothinggood");
                db.SaveChanges();
                user20 = db.Users.First(u => u.UserName == "cluce@gogle.com");
            }

            AppUser user21 = db.Users.FirstOrDefault(u => u.Email == "mackcloud@george.com");
            if (user21 == null)
            {
                user21 = new AppUser();
                //user21.Id = "5021";
                user21.Password = "whatever";
                user21.LastName = "MacLeod";
                user21.FirstName = "Jennifer";
                user21.MiddleInitial = "D.";
                user21.Birthday = new DateTime(1947, 2, 21);
                user21.TypeOfEmployee = EmpType.Customer;
                user21.Address = "2504 Far West Blvd.";
                user21.City = "Marble Falls";
                user21.State = "TX";
                user21.Zip = "78654";
                user21.PhoneNumber = "5125550185";
                user21.Email = "mackcloud@george.com";
                user21.UserName = "mackcloud@george.com";
                user21.PopcornPoints = 170;

                var result = UserManager.Create(user21, "whatever");
                db.SaveChanges();
                user21 = db.Users.First(u => u.UserName == "mackcloud@george.com");
            }

            AppUser user22 = db.Users.FirstOrDefault(u => u.Email == "cmartin@beets.com");
            if (user22 == null)
            {
                user22 = new AppUser();
                //user22.Id = "5022";
                user22.Password = "whocares";
                user22.LastName = "Markham";
                user22.FirstName = "Elizabeth";
                user22.MiddleInitial = "P.";
                user22.Birthday = new DateTime(1972, 3, 20);
                user22.TypeOfEmployee = EmpType.Customer;
                user22.Address = "7861 Chevy Chase";
                user22.City = "Kissimmee";
                user22.State = "FL";
                user22.Zip = "34741";
                user22.PhoneNumber = "5125550134";
                user22.Email = "cmartin@beets.com";
                user22.UserName = "cmartin@beets.com";
                user22.PopcornPoints = 100;

                var result = UserManager.Create(user22, "whocares");
                db.SaveChanges();
                user22 = db.Users.First(u => u.UserName == "cmartin@beets.com");
            }

            AppUser user23 = db.Users.FirstOrDefault(u => u.Email == "clarence@yoho.com");
            if (user23 == null)
            {
                user23 = new AppUser();
                //user23.Id = "5023";
                user23.Password = "xcellent";
                user23.LastName = "Martin";
                user23.FirstName = "Clarence";
                user23.MiddleInitial = "A";
                user23.Birthday = new DateTime(1992, 7, 19);
                user23.TypeOfEmployee = EmpType.Customer;
                user23.Address = "87 Alcedo St.";
                user23.City = "Austin";
                user23.State = "TX";
                user23.Zip = "78709";
                user23.PhoneNumber = "5125550151";
                user23.Email = "clarence@yoho.com";
                user23.UserName = "clarence@yoho.com";
                user23.PopcornPoints = 130;

                var result = UserManager.Create(user23, "xcellent");
                db.SaveChanges();
                user23 = db.Users.First(u => u.UserName == "clarence@yoho.com");
            }

            AppUser user24 = db.Users.FirstOrDefault(u => u.Email == "gregmartinez@drdre.com");
            if (user24 == null)
            {
                user24 = new AppUser();
                //user24.Id = "5024";
                user24.Password = "snowsnow";
                user24.LastName = "Martinez";
                user24.FirstName = "Gregory";
                user24.MiddleInitial = "R.";
                user24.Birthday = new DateTime(1947, 5, 28);
                user24.TypeOfEmployee = EmpType.Customer;
                user24.Address = "8295 Sunset Blvd.";
                user24.City = "Red Rock";
                user24.State = "TX";
                user24.Zip = "78662";
                user24.PhoneNumber = "5125550120";
                user24.Email = "gregmartinez@drdre.com";
                user24.UserName = "gregmartinez@drdre.com";
                user24.PopcornPoints = 20;

                var result = UserManager.Create(user24, "snowsnow");
                db.SaveChanges();
                user24 = db.Users.First(u => u.UserName == "gregmartinez@drdre.com");
            }

            AppUser user25 = db.Users.FirstOrDefault(u => u.Email == "cmiller@bob.com");
            if (user25 == null)
            {
                user25 = new AppUser();
                //user25.Id = "5025";
                user25.Password = "mydogspot";
                user25.LastName = "Miller";
                user25.FirstName = "Charles";
                user25.MiddleInitial = "R.";
                user25.Birthday = new DateTime(1990, 10, 15);
                user25.TypeOfEmployee = EmpType.Customer;
                user25.Address = "8962 Main St.";
                user25.City = "South Padre Island";
                user25.State = "TX";
                user25.Zip = "78597";
                user25.PhoneNumber = "5125550198";
                user25.Email = "cmiller@bob.com";
                user25.UserName = "cmiller@bob.com";
                user25.PopcornPoints = 20;

                var result = UserManager.Create(user25, "mydogspot");
                db.SaveChanges();
                user25 = db.Users.First(u => u.UserName == "cmiller@bob.com");
            }

            AppUser user26 = db.Users.FirstOrDefault(u => u.Email == "knelson@aoll.com");
            if (user26 == null)
            {
                user26 = new AppUser();
                //user26.Id = "5026";
                user26.Password = "spotmydog";
                user26.LastName = "Nelson";
                user26.FirstName = "Kelly";
                user26.MiddleInitial = "T";
                user26.Birthday = new DateTime(1971, 7, 13);
                user26.TypeOfEmployee = EmpType.Customer;
                user26.Address = "2601 Red River";
                user26.City = "Disney";
                user26.State = "OK";
                user26.Zip = "74340";
                user26.PhoneNumber = "5125550177";
                user26.Email = "knelson@aoll.com";
                user26.UserName = "knelson@aoll.com";
                user26.PopcornPoints = 110;

                var result = UserManager.Create(user26, "spotmydog");
                db.SaveChanges();
                user26 = db.Users.First(u => u.UserName == "knelson@aoll.com");
            }

            AppUser user27 = db.Users.FirstOrDefault(u => u.Email == "joewin@xfactor.com");
            if (user27 == null)
            {
                user27 = new AppUser();
                //user27.Id = "5027";
                user27.Password = "joejoejoe";
                user27.LastName = "Nguyen";
                user27.FirstName = "Joe";
                user27.MiddleInitial = "C";
                user27.Birthday = new DateTime(1984, 3, 17);
                user27.TypeOfEmployee = EmpType.Customer;
                user27.Address = "1249 4th SW St.";
                user27.City = "Del Rio";
                user27.State = "TX";
                user27.Zip = "78841";
                user27.PhoneNumber = "5125550174";
                user27.Email = "joewin@xfactor.com";
                user27.UserName = "joewin@xfactor.com";
                user27.PopcornPoints = 150;

                var result = UserManager.Create(user27, "joejoejoe");
                db.SaveChanges();
                user27 = db.Users.First(u => u.UserName == "joewin@xfactor.com");
            }

            AppUser user28 = db.Users.FirstOrDefault(u => u.Email == "orielly@foxnews.cnn");
            if (user28 == null)
            {
                user28 = new AppUser();
                //user28.Id = "5028";
                user28.Password = "billyboy";
                user28.LastName = "O'Reilly";
                user28.FirstName = "Bill";
                user28.MiddleInitial = "T";
                user28.Birthday = new DateTime(1959, 7, 8);
                user28.TypeOfEmployee = EmpType.Customer;
                user28.Address = "8800 Gringo Drive";
                user28.City = "Austin";
                user28.State = "TX";
                user28.Zip = "78746";
                user28.PhoneNumber = "5125550167";
                user28.Email = "orielly@foxnews.cnn";
                user28.UserName = "orielly@foxnews.cnn";
                user28.PopcornPoints = 190;

                var result = UserManager.Create(user28, "billyboy");
                db.SaveChanges();
                user28 = db.Users.First(u => u.UserName == "orielly@foxnews.cnn");
            }

            AppUser user29 = db.Users.FirstOrDefault(u => u.Email == "ankaisrad@gogle.com");
            if (user29 == null)
            {
                user29 = new AppUser();
                //user29.Id = "5029";
                user29.Password = "radgirl";
                user29.LastName = "Radkovich";
                user29.FirstName = "Anka";
                user29.MiddleInitial = "L";
                user29.Birthday = new DateTime(1966, 5, 19);
                user29.TypeOfEmployee = EmpType.Customer;
                user29.Address = "1300 Elliott Pl";
                user29.City = "Austin";
                user29.State = "TX";
                user29.Zip = "78712";
                user29.PhoneNumber = "5125550151";
                user29.Email = "ankaisrad@gogle.com";
                user29.UserName = "ankaisrad@gogle.com";
                user29.PopcornPoints = 120;

                var result = UserManager.Create(user29, "radgirl");
                db.SaveChanges();
                user29 = db.Users.First(u => u.UserName == "ankaisrad@gogle.com");
            }

            AppUser user30 = db.Users.FirstOrDefault(u => u.Email == "megrhodes@freserve.co.uk");
            if (user30 == null)
            {
                user30 = new AppUser();
                //user30.Id = "5030";
                user30.Password = "meganr34";
                user30.LastName = "Rhodes";
                user30.FirstName = "Megan";
                user30.MiddleInitial = "C.";
                user30.Birthday = new DateTime(1965, 3, 12);
                user30.TypeOfEmployee = EmpType.Customer;
                user30.Address = "4587 Enfield Rd.";
                user30.City = "Austin";
                user30.State = "TX";
                user30.Zip = "78705";
                user30.PhoneNumber = "5125550133";
                user30.Email = "megrhodes@freserve.co.uk";
                user30.UserName = "megrhodes@freserve.co.uk";
                user30.PopcornPoints = 190;

                var result = UserManager.Create(user30, "meganr34");
                db.SaveChanges();
                user30 = db.Users.First(u => u.UserName == "megrhodes@freserve.co.uk");
            }

            AppUser user31 = db.Users.FirstOrDefault(u => u.Email == "erynrice@aoll.com");
            if (user31 == null)
            {
                user31 = new AppUser();
                //user31.Id = "5031";
                user31.Password = "ricearoni";
                user31.LastName = "Rice";
                user31.FirstName = "Eryn";
                user31.MiddleInitial = "M.";
                user31.Birthday = new DateTime(1975, 4, 28);
                user31.TypeOfEmployee = EmpType.Customer;
                user31.Address = "3405 Rio Grande";
                user31.City = "Austin";
                user31.State = "TX";
                user31.Zip = "78785";
                user31.PhoneNumber = "5125550196";
                user31.Email = "erynrice@aoll.com";
                user31.UserName = "erynrice@aoll.com";
                user31.PopcornPoints = 190;

                var result = UserManager.Create(user31, "ricearoni");
                db.SaveChanges();
                user31 = db.Users.First(u => u.UserName == "erynrice@aoll.com");
            }

            AppUser user32 = db.Users.FirstOrDefault(u => u.Email == "jorge@noclue.com");
            if (user32 == null)
            {
                user32 = new AppUser();
                //user32.Id = "5032";
                user32.Password = "jrod2017";
                user32.LastName = "Rodriguez";
                user32.FirstName = "Jorge";
                user32.MiddleInitial = "nan";
                user32.Birthday = new DateTime(1953, 12, 8);
                user32.TypeOfEmployee = EmpType.Customer;
                user32.Address = "6788 Cotter Street";
                user32.City = "Littlefield";
                user32.State = "TX";
                user32.Zip = "79339";
                user32.PhoneNumber = "5125550141";
                user32.Email = "jorge@noclue.com";
                user32.UserName = "jorge@noclue.com";
                user32.PopcornPoints = 20;

                var result = UserManager.Create(user32, "jrod2017");
                db.SaveChanges();
                user32 = db.Users.First(u => u.UserName == "jorge@noclue.com");
            }

            AppUser user33 = db.Users.FirstOrDefault(u => u.Email == "mrrogers@lovelyday.com");
            if (user33 == null)
            {
                user33 = new AppUser();
                //user33.Id = "5033";
                user33.Password = "rogerthat";
                user33.LastName = "Rogers";
                user33.FirstName = "Allen";
                user33.MiddleInitial = "B.";
                user33.Birthday = new DateTime(1973, 4, 22);
                user33.TypeOfEmployee = EmpType.Customer;
                user33.Address = "4965 Oak Hill";
                user33.City = "Austin";
                user33.State = "TX";
                user33.Zip = "78733";
                user33.PhoneNumber = "5125550189";
                user33.Email = "mrrogers@lovelyday.com";
                user33.UserName = "mrrogers@lovelyday.com";
                user33.PopcornPoints = 100;

                var result = UserManager.Create(user33, "rogerthat");
                db.SaveChanges();
                user33 = db.Users.First(u => u.UserName == "mrrogers@lovelyday.com");
            }

            AppUser user34 = db.Users.FirstOrDefault(u => u.Email == "stjean@athome.com");
            if (user34 == null)
            {
                user34 = new AppUser();
                //user34.Id = "5034";
                user34.Password = "bunnyhop";
                user34.LastName = "Saint-Jean";
                user34.FirstName = "Olivier";
                user34.MiddleInitial = "M";
                user34.Birthday = new DateTime(1995, 2, 19);
                user34.TypeOfEmployee = EmpType.Customer;
                user34.Address = "255 Toncray Dr.";
                user34.City = "Austin";
                user34.State = "TX";
                user34.Zip = "78755";
                user34.PhoneNumber = "5125550152";
                user34.Email = "stjean@athome.com";
                user34.UserName = "stjean@athome.com";
                user34.PopcornPoints = 250;

                var result = UserManager.Create(user34, "bunnyhop");
                db.SaveChanges();
                user34 = db.Users.First(u => u.UserName == "stjean@athome.com");
            }

            AppUser user35 = db.Users.FirstOrDefault(u => u.Email == "saunders@pen.com");
            if (user35 == null)
            {
                user35 = new AppUser();
                //user35.Id = "5035";
                user35.Password = "penguin12";
                user35.LastName = "Saunders";
                user35.FirstName = "Sarah";
                user35.MiddleInitial = "J.";
                user35.Birthday = new DateTime(1978, 2, 19);
                user35.TypeOfEmployee = EmpType.Customer;
                user35.Address = "332 Avenue C";
                user35.City = "Austin";
                user35.State = "TX";
                user35.Zip = "78701";
                user35.PhoneNumber = "5125550146";
                user35.Email = "saunders@pen.com";
                user35.UserName = "saunders@pen.com";
                user35.PopcornPoints = 40;

                var result = UserManager.Create(user35, "penguin12");
                db.SaveChanges();
                user35 = db.Users.First(u => u.UserName == "saunders@pen.com");
            }

            AppUser user36 = db.Users.FirstOrDefault(u => u.Email == "willsheff@email.com");
            if (user36 == null)
            {
                user36 = new AppUser();
                //user36.Id = "5036";
                user36.Password = "alaskaboy";
                user36.LastName = "Sewell";
                user36.FirstName = "William";
                user36.MiddleInitial = "T.";
                user36.Birthday = new DateTime(2004, 12, 23);
                user36.TypeOfEmployee = EmpType.Customer;
                user36.Address = "2365 51st St.";
                user36.City = "El Paso";
                user36.State = "TX";
                user36.Zip = "79953";
                user36.PhoneNumber = "5125550192";
                user36.Email = "willsheff@email.com";
                user36.UserName = "willsheff@email.com";
                user36.PopcornPoints = 200;

                var result = UserManager.Create(user36, "alaskaboy");
                db.SaveChanges();
                user36 = db.Users.First(u => u.UserName == "willsheff@email.com");
            }

            AppUser user37 = db.Users.FirstOrDefault(u => u.Email == "sheffiled@gogle.com");
            if (user37 == null)
            {
                user37 = new AppUser();
                //user37.Id = "5037";
                user37.Password = "martin1234";
                user37.LastName = "Sheffield";
                user37.FirstName = "Martin";
                user37.MiddleInitial = "J.";
                user37.Birthday = new DateTime(1960, 5, 8);
                user37.TypeOfEmployee = EmpType.Customer;
                user37.Address = "3886 Avenue A";
                user37.City = "Balmorhea";
                user37.State = "TX";
                user37.Zip = "79718";
                user37.PhoneNumber = "5125550131";
                user37.Email = "sheffiled@gogle.com";
                user37.UserName = "sheffiled@gogle.com";
                user37.PopcornPoints = 130;

                var result = UserManager.Create(user37, "martin1234");
                db.SaveChanges();
                user37 = db.Users.First(u => u.UserName == "sheffiled@gogle.com");
            }

            AppUser user38 = db.Users.FirstOrDefault(u => u.Email == "johnsmith187@aoll.com");
            if (user38 == null)
            {
                user38 = new AppUser();
                //user38.Id = "5038";
                user38.Password = "smitty444";
                user38.LastName = "Smith";
                user38.FirstName = "John";
                user38.MiddleInitial = "A";
                user38.Birthday = new DateTime(1955, 6, 25);
                user38.TypeOfEmployee = EmpType.Customer;
                user38.Address = "23 Hidden Forge Dr.";
                user38.City = "Austin";
                user38.State = "TX";
                user38.Zip = "78760";
                user38.PhoneNumber = "5125550190";
                user38.Email = "johnsmith187@aoll.com";
                user38.UserName = "johnsmith187@aoll.com";
                user38.PopcornPoints = 130;

                var result = UserManager.Create(user38, "smitty444");
                db.SaveChanges();
                user38 = db.Users.First(u => u.UserName == "johnsmith187@aoll.com");
            }

            AppUser user39 = db.Users.FirstOrDefault(u => u.Email == "dustroud@mail.com");
            if (user39 == null)
            {
                user39 = new AppUser();
                //user39.Id = "5039";
                user39.Password = "dustydusty";
                user39.LastName = "Stroud";
                user39.FirstName = "Dustin";
                user39.MiddleInitial = "P";
                user39.Birthday = new DateTime(1967, 7, 26);
                user39.TypeOfEmployee = EmpType.Customer;
                user39.Address = "1212 Rita Rd";
                user39.City = "Austin";
                user39.State = "TX";
                user39.Zip = "78734";
                user39.PhoneNumber = "5125550157";
                user39.Email = "dustroud@mail.com";
                user39.UserName = "dustroud@mail.com";
                user39.PopcornPoints = 90;

                var result = UserManager.Create(user39, "dustydusty");
                db.SaveChanges();
                user39 = db.Users.First(u => u.UserName == "dustroud@mail.com");
            }

            AppUser user40 = db.Users.FirstOrDefault(u => u.Email == "estuart@anchor.net");
            if (user40 == null)
            {
                user40 = new AppUser();
                //user40.Id = "5040";
                user40.Password = "stewball";
                user40.LastName = "Stuart";
                user40.FirstName = "Eric";
                user40.MiddleInitial = "D.";
                user40.Birthday = new DateTime(1947, 12, 4);
                user40.TypeOfEmployee = EmpType.Customer;
                user40.Address = "5576 Toro Ring";
                user40.City = "Kyle";
                user40.State = "TX";
                user40.Zip = "78640";
                user40.PhoneNumber = "5125550191";
                user40.Email = "estuart@anchor.net";
                user40.UserName = "estuart@anchor.net";
                user40.PopcornPoints = 170;

                var result = UserManager.Create(user40, "stewball");
                db.SaveChanges();
                user40 = db.Users.First(u => u.UserName == "estuart@anchor.net");
            }

            AppUser user41 = db.Users.FirstOrDefault(u => u.Email == "peterstump@noclue.com");
            if (user41 == null)
            {
                user41 = new AppUser();
                //user41.Id = "5041";
                user41.Password = "slowwind";
                user41.LastName = "Stump";
                user41.FirstName = "Peter";
                user41.MiddleInitial = "L";
                user41.Birthday = new DateTime(1974, 7, 10);
                user41.TypeOfEmployee = EmpType.Customer;
                user41.Address = "1300 Kellen Circle";
                user41.City = "Philadelphia";
                user41.State = "PA";
                user41.Zip = "19123";
                user41.PhoneNumber = "5125550136";
                user41.Email = "peterstump@noclue.com";
                user41.UserName = "peterstump@noclue.com";
                user41.PopcornPoints = 50;

                var result = UserManager.Create(user41, "slowwind");
                db.SaveChanges();
                user41 = db.Users.First(u => u.UserName == "peterstump@noclue.com");
            }

            AppUser user42 = db.Users.FirstOrDefault(u => u.Email == "jtanner@mustang.net");
            if (user42 == null)
            {
                user42 = new AppUser();
                //user42.Id = "5042";
                user42.Password = "tanner5454";
                user42.LastName = "Tanner";
                user42.FirstName = "Jeremy";
                user42.MiddleInitial = "S.";
                user42.Birthday = new DateTime(1944, 1, 11);
                user42.TypeOfEmployee = EmpType.Customer;
                user42.Address = "4347 Almstead";
                user42.City = "Austin";
                user42.State = "TX";
                user42.Zip = "78747";
                user42.PhoneNumber = "5125550170";
                user42.Email = "jtanner@mustang.net";
                user42.UserName = "jtanner@mustang.net";
                user42.PopcornPoints = 190;

                var result = UserManager.Create(user42, "tanner5454");
                db.SaveChanges();
                user42 = db.Users.First(u => u.UserName == "jtanner@mustang.net");
            }

            AppUser user43 = db.Users.FirstOrDefault(u => u.Email == "taylordjay@aoll.com");
            if (user43 == null)
            {
                user43 = new AppUser();
                //user43.Id = "5043";
                user43.Password = "allyrally";
                user43.LastName = "Taylor";
                user43.FirstName = "Allison";
                user43.MiddleInitial = "R.";
                user43.Birthday = new DateTime(1990, 11, 14);
                user43.TypeOfEmployee = EmpType.Customer;
                user43.Address = "467 Nueces St.";
                user43.City = "Austin";
                user43.State = "TX";
                user43.Zip = "78712";
                user43.PhoneNumber = "5125550160";
                user43.Email = "taylordjay@aoll.com";
                user43.UserName = "taylordjay@aoll.com";
                user43.PopcornPoints = 110;

                var result = UserManager.Create(user43, "allyrally");
                db.SaveChanges();
                user43 = db.Users.First(u => u.UserName == "taylordjay@aoll.com");
            }

            AppUser user44 = db.Users.FirstOrDefault(u => u.Email == "rtaylor@gogle.com");
            if (user44 == null)
            {
                user44 = new AppUser();
                //user44.Id = "5044";
                user44.Password = "taylorbaylor";
                user44.LastName = "Taylor";
                user44.FirstName = "Rachel";
                user44.MiddleInitial = "K.";
                user44.Birthday = new DateTime(1976, 1, 18);
                user44.TypeOfEmployee = EmpType.Customer;
                user44.Address = "345 Longview Dr.";
                user44.City = "Austin";
                user44.State = "TX";
                user44.Zip = "78758";
                user44.PhoneNumber = "5125550127";
                user44.Email = "rtaylor@gogle.com";
                user44.UserName = "rtaylor@gogle.com";
                user44.PopcornPoints = 160;

                var result = UserManager.Create(user44, "taylorbaylor");
                db.SaveChanges();
                user44 = db.Users.First(u => u.UserName == "rtaylor@gogle.com");
            }

            AppUser user45 = db.Users.FirstOrDefault(u => u.Email == "teefrank@noclue.com");
            if (user45 == null)
            {
                user45 = new AppUser();
                //user45.Id = "5045";
                user45.Password = "teeoff22";
                user45.LastName = "Tee";
                user45.FirstName = "Frank";
                user45.MiddleInitial = "J";
                user45.Birthday = new DateTime(1998, 9, 6);
                user45.TypeOfEmployee = EmpType.Customer;
                user45.Address = "5590 Lavell Dr";
                user45.City = "Austin";
                user45.State = "TX";
                user45.Zip = "78729";
                user45.PhoneNumber = "5125550161";
                user45.Email = "teefrank@noclue.com";
                user45.UserName = "teefrank@noclue.com";
                user45.PopcornPoints = 70;

                var result = UserManager.Create(user45, "teeoff22");
                db.SaveChanges();
                user45 = db.Users.First(u => u.UserName == "teefrank@noclue.com");
            }

            AppUser user46 = db.Users.FirstOrDefault(u => u.Email == "ctucker@alphabet.co.uk");
            if (user46 == null)
            {
                user46 = new AppUser();
                //user46.Id = "5046";
                user46.Password = "tucksack1";
                user46.LastName = "Tucker";
                user46.FirstName = "Clent";
                user46.MiddleInitial = "J";
                user46.Birthday = new DateTime(1943, 2, 25);
                user46.TypeOfEmployee = EmpType.Customer;
                user46.Address = "312 Main St.";
                user46.City = "Round Rock";
                user46.State = "TX";
                user46.Zip = "78665";
                user46.PhoneNumber = "5125550106";
                user46.Email = "ctucker@alphabet.co.uk";
                user46.UserName = "ctucker@alphabet.co.uk";
                user46.PopcornPoints = 150;

                var result = UserManager.Create(user46, "tucksack1");
                db.SaveChanges();
                user46 = db.Users.First(u => u.UserName == "ctucker@alphabet.co.uk");
            }

            AppUser user47 = db.Users.FirstOrDefault(u => u.Email == "avelasco@yoho.com");
            if (user47 == null)
            {
                user47 = new AppUser();
                //user47.Id = "5047";
                user47.Password = "meow88";
                user47.LastName = "Velasco";
                user47.FirstName = "Allen";
                user47.MiddleInitial = "G";
                user47.Birthday = new DateTime(1985, 9, 10);
                user47.TypeOfEmployee = EmpType.Customer;
                user47.Address = "679 W. 4th";
                user47.City = "Cedar Park";
                user47.State = "TX";
                user47.Zip = "78613";
                user47.PhoneNumber = "5125550170";
                user47.Email = "avelasco@yoho.com";
                user47.UserName = "avelasco@yoho.com";
                user47.PopcornPoints = 0;

                var result = UserManager.Create(user47, "meow88");
                db.SaveChanges();
                user47 = db.Users.First(u => u.UserName == "avelasco@yoho.com");
            }

            AppUser user48 = db.Users.FirstOrDefault(u => u.Email == "vinovino@grapes.com");
            if (user48 == null)
            {
                user48 = new AppUser();
                //user48.Id = "5048";
                user48.Password = "vinovino";
                user48.LastName = "Vino";
                user48.FirstName = "Janet";
                user48.MiddleInitial = "E";
                user48.Birthday = new DateTime(1985, 2, 7);
                user48.TypeOfEmployee = EmpType.Customer;
                user48.Address = "189 Grape Road";
                user48.City = "Lockhart";
                user48.State = "TX";
                user48.Zip = "78644";
                user48.PhoneNumber = "5125550128";
                user48.Email = "vinovino@grapes.com";
                user48.UserName = "vinovino@grapes.com";
                user48.PopcornPoints = 160;

                var result = UserManager.Create(user48, "vinovino");
                db.SaveChanges();
                user48 = db.Users.First(u => u.UserName == "vinovino@grapes.com");
            }

            AppUser user49 = db.Users.FirstOrDefault(u => u.Email == "westj@pioneer.net");
            if (user49 == null)
            {
                user49 = new AppUser();
                //user49.Id = "5049";
                user49.Password = "gowest";
                user49.LastName = "West";
                user49.FirstName = "Jake";
                user49.MiddleInitial = "T";
                user49.Birthday = new DateTime(1976, 1, 9);
                user49.TypeOfEmployee = EmpType.Customer;
                user49.Address = "RR 3287";
                user49.City = "Austin";
                user49.State = "TX";
                user49.Zip = "78705";
                user49.PhoneNumber = "2025550170";
                user49.Email = "westj@pioneer.net";
                user49.UserName = "westj@pioneer.net";
                user49.PopcornPoints = 70;

                var result = UserManager.Create(user49, "gowest");
                db.SaveChanges();
                user49 = db.Users.First(u => u.UserName == "westj@pioneer.net");
            }

            AppUser user50 = db.Users.FirstOrDefault(u => u.Email == "winner@hootmail.com");
            if (user50 == null)
            {
                user50 = new AppUser();
                //user50.Id = "5050";
                user50.Password = "louielouie";
                user50.LastName = "Winthorpe";
                user50.FirstName = "Louis";
                user50.MiddleInitial = "L";
                user50.Birthday = new DateTime(1953, 4, 19);
                user50.TypeOfEmployee = EmpType.Customer;
                user50.Address = "2500 Padre Blvd";
                user50.City = "Austin";
                user50.State = "TX";
                user50.Zip = "78747";
                user50.PhoneNumber = "2025550141";
                user50.Email = "winner@hootmail.com";
                user50.UserName = "winner@hootmail.com";
                user50.PopcornPoints = 150;

                var result = UserManager.Create(user50, "louielouie");
                db.SaveChanges();
                user50 = db.Users.First(u => u.UserName == "winner@hootmail.com");
            }

            AppUser user51 = db.Users.FirstOrDefault(u => u.Email == "rwood@voyager.net");
            if (user51 == null)
            {
                user51 = new AppUser();
                //user51.Id = "5051";
                user51.Password = "woodyman1";
                user51.LastName = "Wood";
                user51.FirstName = "Reagan";
                user51.MiddleInitial = "B.";
                user51.Birthday = new DateTime(2002, 12, 28);
                user51.TypeOfEmployee = EmpType.Customer;
                user51.Address = "447 Westlake Dr.";
                user51.City = "Austin";
                user51.State = "TX";
                user51.Zip = "78753";
                user51.PhoneNumber = "2025550128";
                user51.Email = "rwood@voyager.net";
                user51.UserName = "rwood@voyager.net";
                user51.PopcornPoints = 20;

                var result = UserManager.Create(user51, "woodyman1");
                db.SaveChanges();
                user51 = db.Users.First(u => u.UserName == "rwood@voyager.net");
            }
        }
    }
}

