namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangedMoviemodeltoallowRatings : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Movies", "TotalStars", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            AddColumn("dbo.Movies", "TotalReviews", c => c.Decimal(nullable: false, precision: 18, scale: 2));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Movies", "TotalReviews");
            DropColumn("dbo.Movies", "TotalStars");
        }
    }
}
