namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemoveReviewtable : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Reviews", "ReviewText", c => c.String());
            DropColumn("dbo.Reviews", "Approved");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Reviews", "Approved", c => c.Boolean(nullable: false));
            AlterColumn("dbo.Reviews", "ReviewText", c => c.String(maxLength: 100));
        }
    }
}
