namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ValidateRegistrationAge : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.RegisterViewModels", "City", c => c.String(nullable: false));
            AddColumn("dbo.RegisterViewModels", "Zip", c => c.String(nullable: false, maxLength: 5));
            AlterColumn("dbo.AspNetUsers", "Password", c => c.String());
            AlterColumn("dbo.AspNetUsers", "State", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.AspNetUsers", "State", c => c.String(nullable: false));
            AlterColumn("dbo.AspNetUsers", "Password", c => c.String(nullable: false));
            DropColumn("dbo.RegisterViewModels", "Zip");
            DropColumn("dbo.RegisterViewModels", "City");
        }
    }
}
