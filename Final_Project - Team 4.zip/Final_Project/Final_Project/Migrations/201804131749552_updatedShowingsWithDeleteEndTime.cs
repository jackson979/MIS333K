namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class updatedShowingsWithDeleteEndTime : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.Showings", "EndTime");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Showings", "EndTime", c => c.DateTime(nullable: false));
        }
    }
}
