namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class reviewupdate : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Reviews", "Status", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Reviews", "Status");
        }
    }
}
