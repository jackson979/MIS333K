using Final_Project.Models;
using Final_Project.DAL;
using System.Data.Entity.Migrations;
using System;
using System.Linq;

namespace Final_Project.Migrations
{
    public class GenreData
    {
        public void SeedGenres(AppDbContext db)
        {
            Genre gen1 = new Genre();
            gen1.Name = "Action";
            db.Genres.AddOrUpdate(l => l.Name, gen1);
            db.SaveChanges();

            Genre gen2 = new Genre();
            gen2.Name = "Drama";
            db.Genres.AddOrUpdate(l => l.Name, gen2);
            db.SaveChanges();

            Genre gen3 = new Genre();
            gen3.Name = "Adventure";
            db.Genres.AddOrUpdate(l => l.Name, gen3);
            db.SaveChanges();

            Genre gen4 = new Genre();
            gen4.Name = "Animation";
            db.Genres.AddOrUpdate(l => l.Name, gen4);
            db.SaveChanges();

            Genre gen5 = new Genre();
            gen5.Name = "Comedy";
            db.Genres.AddOrUpdate(l => l.Name, gen5);
            db.SaveChanges();

            Genre gen6 = new Genre();
            gen6.Name = "Crime";
            db.Genres.AddOrUpdate(l => l.Name, gen6);
            db.SaveChanges();

            Genre gen7 = new Genre();
            gen7.Name = "Family";
            db.Genres.AddOrUpdate(l => l.Name, gen7);
            db.SaveChanges();

            Genre gen8 = new Genre();
            gen8.Name = "Fantasy";
            db.Genres.AddOrUpdate(l => l.Name, gen8);
            db.SaveChanges();

            Genre gen9 = new Genre();
            gen9.Name = "History";
            db.Genres.AddOrUpdate(l => l.Name, gen9);
            db.SaveChanges();

            Genre gen10 = new Genre();
            gen10.Name = "Horror";
            db.Genres.AddOrUpdate(l => l.Name, gen10);
            db.SaveChanges();

            Genre gen11 = new Genre();
            gen11.Name = "Musical";
            db.Genres.AddOrUpdate(l => l.Name, gen11);
            db.SaveChanges();

            Genre gen12 = new Genre();
            gen12.Name = "Mystery";
            db.Genres.AddOrUpdate(l => l.Name, gen12);
            db.SaveChanges();

            Genre gen13 = new Genre();
            gen13.Name = "Romance";
            db.Genres.AddOrUpdate(l => l.Name, gen13);
            db.SaveChanges();

            Genre gen14 = new Genre();
            gen14.Name = "Science Fiction";
            db.Genres.AddOrUpdate(l => l.Name, gen14);
            db.SaveChanges();

            Genre gen15 = new Genre();
            gen15.Name = "Thriller";
            db.Genres.AddOrUpdate(l => l.Name, gen15);
            db.SaveChanges();

            Genre gen16 = new Genre();
            gen16.Name = "War";
            db.Genres.AddOrUpdate(l => l.Name, gen16);
            db.SaveChanges();

            Genre gen17 = new Genre();
            gen17.Name = "Western";
            db.Genres.AddOrUpdate(l => l.Name, gen17);
            db.SaveChanges();
        }
    }
}

