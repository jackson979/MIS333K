namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Link : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Orders", "CreditCard_CreditCardID", c => c.Int());
            CreateIndex("dbo.Orders", "CreditCard_CreditCardID");
            AddForeignKey("dbo.Orders", "CreditCard_CreditCardID", "dbo.CreditCards", "CreditCardID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Orders", "CreditCard_CreditCardID", "dbo.CreditCards");
            DropIndex("dbo.Orders", new[] { "CreditCard_CreditCardID" });
            DropColumn("dbo.Orders", "CreditCard_CreditCardID");
        }
    }
}
