namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class creditcarduser : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.AspNetUsers", "CreditCard_CreditCardID", "dbo.CreditCards");
            DropIndex("dbo.AspNetUsers", new[] { "CreditCard_CreditCardID" });
            CreateTable(
                "dbo.CreditCardAppUsers",
                c => new
                    {
                        CreditCard_CreditCardID = c.Int(nullable: false),
                        AppUser_Id = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.CreditCard_CreditCardID, t.AppUser_Id })
                .ForeignKey("dbo.CreditCards", t => t.CreditCard_CreditCardID, cascadeDelete: true)
                .ForeignKey("dbo.AspNetUsers", t => t.AppUser_Id, cascadeDelete: true)
                .Index(t => t.CreditCard_CreditCardID)
                .Index(t => t.AppUser_Id);
            
            DropColumn("dbo.AspNetUsers", "CreditCard_CreditCardID");
        }
        
        public override void Down()
        {
            AddColumn("dbo.AspNetUsers", "CreditCard_CreditCardID", c => c.Int());
            DropForeignKey("dbo.CreditCardAppUsers", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.CreditCardAppUsers", "CreditCard_CreditCardID", "dbo.CreditCards");
            DropIndex("dbo.CreditCardAppUsers", new[] { "AppUser_Id" });
            DropIndex("dbo.CreditCardAppUsers", new[] { "CreditCard_CreditCardID" });
            DropTable("dbo.CreditCardAppUsers");
            CreateIndex("dbo.AspNetUsers", "CreditCard_CreditCardID");
            AddForeignKey("dbo.AspNetUsers", "CreditCard_CreditCardID", "dbo.CreditCards", "CreditCardID");
        }
    }
}
