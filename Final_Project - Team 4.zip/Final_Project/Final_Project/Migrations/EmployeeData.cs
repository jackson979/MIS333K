using System.Data.Entity.Migrations;
using System;
using System.Linq;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Final_Project.DAL;
using Final_Project.Models;

namespace Final_Project.Migrations
{
    public class EmployeeData
    {
        public void SeedEmployees(AppDbContext db)
        {
            AppUserManager UserManager = new AppUserManager(new UserStore<AppUser>(db));


            AppUser manager1 = db.Users.FirstOrDefault(u => u.Email == "t.jacobs@longhorncinema.com");
            if (manager1 == null)
            {
                manager1 = new AppUser();
                manager1.Password = "society";
                manager1.LastName = "Jacobs";
                manager1.FirstName = "Todd";
                manager1.Birthday = new DateTime(1958, 4, 25);
                manager1.TypeOfEmployee = EmpType.Employee;
                manager1.Address = "4564 Elm St.";
                manager1.City = "Georgetown";
                manager1.State = "TX";
                manager1.Zip = "78628";
                manager1.PhoneNumber = "9074653365";
                manager1.Email = "t.jacobs@longhorncinema.com";
                manager1.UserName = "t.jacobs@longhorncinema.com";

                var result = UserManager.Create(manager1, "society");
                db.SaveChanges();
                manager1 = db.Users.First(u => u.UserName == "t.jacobs@longhorncinema.com");
            }

            AppUser manager2 = db.Users.FirstOrDefault(u => u.Email == "e.rice@longhorncinema.com");
            if (manager2 == null)
            {
                manager2 = new AppUser();
                manager2.Password = "ricearoni";
                manager2.LastName = "Rice";
                manager2.FirstName = "Eryn";
                manager2.Birthday = new DateTime(1959, 7, 2);
                manager2.TypeOfEmployee = EmpType.Manager;
                manager2.Address = "3405 Rio Grande";
                manager2.City = "Austin";
                manager2.State = "TX";
                manager2.Zip = "78746";
                manager2.PhoneNumber = "9073876657";
                manager2.Email = "e.rice@longhorncinema.com";
                manager2.UserName = "e.rice@longhorncinema.com";

                var result = UserManager.Create(manager2, "ricearoni");
                db.SaveChanges();
                manager2 = db.Users.First(u => u.UserName == "e.rice@longhorncinema.com");
            }

            AppUser manager3 = db.Users.FirstOrDefault(u => u.Email == "b.ingram@longhorncinema.com");
            if (manager3 == null)
            {
                manager3 = new AppUser();
                manager3.Password = "ingram45";
                manager3.LastName = "Ingram";
                manager3.FirstName = "Brad";
                manager3.Birthday = new DateTime(1962, 8, 25);
                manager3.TypeOfEmployee = EmpType.Employee;
                manager3.Address = "6548 La Posada Ct.";
                manager3.City = "Austin";
                manager3.State = "TX";
                manager3.Zip = "78705";
                manager3.PhoneNumber = "9074678821";
                manager3.Email = "b.ingram@longhorncinema.com";
                manager3.UserName = "b.ingram@longhorncinema.com";

                var result = UserManager.Create(manager3, "ingram45");
                db.SaveChanges();
                manager3 = db.Users.First(u => u.UserName == "b.ingram@longhorncinema.com");
            }

            AppUser manager4 = db.Users.FirstOrDefault(u => u.Email == "a.taylor@longhorncinema.com");
            if (manager4 == null)
            {
                manager4 = new AppUser();
                manager4.Password = "nostalgic";
                manager4.LastName = "Taylor";
                manager4.FirstName = "Allison";
                manager4.Birthday = new DateTime(1964, 9, 2);
                manager4.TypeOfEmployee = EmpType.Employee;
                manager4.Address = "467 Nueces St.";
                manager4.City = "Austin";
                manager4.State = "TX";
                manager4.Zip = "78727";
                manager4.PhoneNumber = "9074748452";
                manager4.Email = "a.taylor@longhorncinema.com";
                manager4.UserName = "a.taylor@longhorncinema.com";

                var result = UserManager.Create(manager4, "nostalgic");
                db.SaveChanges();
                manager4 = db.Users.First(u => u.UserName == "a.taylor@longhorncinema.com");
            }

            AppUser manager5 = db.Users.FirstOrDefault(u => u.Email == "g.martinez@longhorncinema.com");
            if (manager5 == null)
            {
                manager5 = new AppUser();
                manager5.Password = "fungus";
                manager5.LastName = "Martinez";
                manager5.FirstName = "Gregory";
                manager5.Birthday = new DateTime(1992, 3, 30);
                manager5.TypeOfEmployee = EmpType.Employee;
                manager5.Address = "8295 Sunset Blvd.";
                manager5.City = "Austin";
                manager5.State = "TX";
                manager5.Zip = "78712";
                manager5.PhoneNumber = "9078746718";
                manager5.Email = "g.martinez@longhorncinema.com";
                manager5.UserName = "g.martinez@longhorncinema.com";

                var result = UserManager.Create(manager5, "fungus");
                db.SaveChanges();
                manager5 = db.Users.First(u => u.UserName == "g.martinez@longhorncinema.com");
            }

            AppUser manager6 = db.Users.FirstOrDefault(u => u.Email == "m.sheffield@longhorncinema.com");
            if (manager6 == null)
            {
                manager6 = new AppUser();
                manager6.Password = "longhorns";
                manager6.LastName = "Sheffield";
                manager6.FirstName = "Martin";
                manager6.Birthday = new DateTime(1996, 12, 29);
                manager6.TypeOfEmployee = EmpType.Employee;
                manager6.Address = "3886 Avenue A";
                manager6.City = "San Marcos";
                manager6.State = "TX";
                manager6.Zip = "78666";
                manager6.PhoneNumber = "9075479167";
                manager6.Email = "m.sheffield@longhorncinema.com";
                manager6.UserName = "m.sheffield@longhorncinema.com";

                var result = UserManager.Create(manager6, "longhorns");
                db.SaveChanges();
                manager6 = db.Users.First(u => u.UserName == "m.sheffield@longhorncinema.com");
            }

            AppUser manager7 = db.Users.FirstOrDefault(u => u.Email == "j.macleod@longhorncinema.com");
            if (manager7 == null)
            {
                manager7 = new AppUser();
                manager7.Password = "smitty";
                manager7.LastName = "MacLeod";
                manager7.FirstName = "Jennifer";
                manager7.Birthday = new DateTime(1997, 6, 10);
                manager7.TypeOfEmployee = EmpType.Employee;
                manager7.Address = "2504 Far West Blvd.";
                manager7.City = "Austin";
                manager7.State = "TX";
                manager7.Zip = "78705";
                manager7.PhoneNumber = "9074748138";
                manager7.Email = "j.macleod@longhorncinema.com";
                manager7.UserName = "j.macleod@longhorncinema.com";

                var result = UserManager.Create(manager7, "smitty");
                db.SaveChanges();
                manager7 = db.Users.First(u => u.UserName == "j.macleod@longhorncinema.com");
            }

            AppUser manager8 = db.Users.FirstOrDefault(u => u.Email == "j.tanner@longhorncinema.com");
            if (manager8 == null)
            {
                manager8 = new AppUser();
                manager8.Password = "tanman";
                manager8.LastName = "Tanner";
                manager8.FirstName = "Jeremy";
                manager8.Birthday = new DateTime(1970, 8, 12);
                manager8.TypeOfEmployee = EmpType.Employee;
                manager8.Address = "4347 Almstead";
                manager8.City = "Austin";
                manager8.State = "TX";
                manager8.Zip = "78712";
                manager8.PhoneNumber = "9074590929";
                manager8.Email = "j.tanner@longhorncinema.com";
                manager8.UserName = "j.tanner@longhorncinema.com";

                var result = UserManager.Create(manager8, "tanman");
                db.SaveChanges();
                manager8 = db.Users.First(u => u.UserName == "j.tanner@longhorncinema.com");
            }

            AppUser manager9 = db.Users.FirstOrDefault(u => u.Email == "m.rhodes@longhorncinema.com");
            if (manager9 == null)
            {
                manager9 = new AppUser();
                manager9.Password = "countryrhodes";
                manager9.LastName = "Rhodes";
                manager9.FirstName = "Megan";
                manager9.Birthday = new DateTime(1970, 12, 18);
                manager9.TypeOfEmployee = EmpType.Employee;
                manager9.Address = "4587 Enfield Rd.";
                manager9.City = "Austin";
                manager9.State = "TX";
                manager9.Zip = "78729";
                manager9.PhoneNumber = "9073744746";
                manager9.Email = "m.rhodes@longhorncinema.com";
                manager9.UserName = "m.rhodes@longhorncinema.com";

                var result = UserManager.Create(manager9, "countryrhodes");
                db.SaveChanges();
                manager9 = db.Users.First(u => u.UserName == "m.rhodes@longhorncinema.com");
            }

            AppUser manager10 = db.Users.FirstOrDefault(u => u.Email == "e.stuart@longhorncinema.com");
            if (manager10 == null)
            {
                manager10 = new AppUser();
                manager10.Password = "stewboy";
                manager10.LastName = "Stuart";
                manager10.FirstName = "Eric";
                manager10.Birthday = new DateTime(1971, 3, 11);
                manager10.TypeOfEmployee = EmpType.Employee;
                manager10.Address = "5576 Toro Ring";
                manager10.City = "Austin";
                manager10.State = "TX";
                manager10.Zip = "78758";
                manager10.PhoneNumber = "9078178335";
                manager10.Email = "e.stuart@longhorncinema.com";
                manager10.UserName = "e.stuart@longhorncinema.com";

                var result = UserManager.Create(manager10, "stewboy");
                db.SaveChanges();
                manager10 = db.Users.First(u => u.UserName == "e.stuart@longhorncinema.com");
            }

            AppUser manager11 = db.Users.FirstOrDefault(u => u.Email == "c.miller@longhorncinema.com");
            if (manager11 == null)
            {
                manager11 = new AppUser();
                manager11.Password = "squirrel";
                manager11.LastName = "Miller";
                manager11.FirstName = "Charles";
                manager11.Birthday = new DateTime(1972, 7, 20);
                manager11.TypeOfEmployee = EmpType.Employee;
                manager11.Address = "8962 Main St.";
                manager11.City = "Austin";
                manager11.State = "TX";
                manager11.Zip = "78709";
                manager11.PhoneNumber = "9077458615";
                manager11.Email = "c.miller@longhorncinema.com";
                manager11.UserName = "c.miller@longhorncinema.com";

                var result = UserManager.Create(manager11, "squirrel");
                db.SaveChanges();
                manager11 = db.Users.First(u => u.UserName == "c.miller@longhorncinema.com");
            }

            AppUser manager12 = db.Users.FirstOrDefault(u => u.Email == "r.taylor@longhorncinema.com");
            if (manager12 == null)
            {
                manager12 = new AppUser();
                manager12.Password = "swansong";
                manager12.LastName = "Taylor";
                manager12.FirstName = "Rachel";
                manager12.Birthday = new DateTime(1972, 12, 20);
                manager12.TypeOfEmployee = EmpType.Manager;
                manager12.Address = "345 Longview Dr.";
                manager12.City = "Austin";
                manager12.State = "TX";
                manager12.Zip = "78746";
                manager12.PhoneNumber = "9074512631";
                manager12.Email = "r.taylor@longhorncinema.com";
                manager12.UserName = "r.taylor@longhorncinema.com";

                var result = UserManager.Create(manager12, "swansong");
                db.SaveChanges();
                manager12 = db.Users.First(u => u.UserName == "r.taylor@longhorncinema.com");
            }

            AppUser manager13 = db.Users.FirstOrDefault(u => u.Email == "v.lawrence@longhorncinema.com");
            if (manager13 == null)
            {
                manager13 = new AppUser();
                manager13.Password = "lottery";
                manager13.LastName = "Lawrence";
                manager13.FirstName = "Victoria";
                manager13.Birthday = new DateTime(1973, 4, 28);
                manager13.TypeOfEmployee = EmpType.Employee;
                manager13.Address = "6639 Butterfly Ln.";
                manager13.City = "Austin";
                manager13.State = "TX";
                manager13.Zip = "78712";
                manager13.PhoneNumber = "9079457399";
                manager13.Email = "v.lawrence@longhorncinema.com";
                manager13.UserName = "v.lawrence@longhorncinema.com";

                var result = UserManager.Create(manager13, "lottery");
                db.SaveChanges();
                manager13 = db.Users.First(u => u.UserName == "v.lawrence@longhorncinema.com");
            }

            AppUser manager14 = db.Users.FirstOrDefault(u => u.Email == "a.rogers@longhorncinema.com");
            if (manager14 == null)
            {
                manager14 = new AppUser();
                manager14.Password = "evanescent";
                manager14.LastName = "Rogers";
                manager14.FirstName = "Allen";
                manager14.Birthday = new DateTime(1978, 6, 21);
                manager14.TypeOfEmployee = EmpType.Manager;
                manager14.Address = "4965 Oak Hill";
                manager14.City = "Austin";
                manager14.State = "TX";
                manager14.Zip = "78705";
                manager14.PhoneNumber = "9078752943";
                manager14.Email = "a.rogers@longhorncinema.com";
                manager14.UserName = "a.rogers@longhorncinema.com";

                var result = UserManager.Create(manager14, "evanescent");
                db.SaveChanges();
                manager14 = db.Users.First(u => u.UserName == "a.rogers@longhorncinema.com");
            }

            AppUser manager15 = db.Users.FirstOrDefault(u => u.Email == "e.markham@longhorncinema.com");
            if (manager15 == null)
            {
                manager15 = new AppUser();
                manager15.Password = "monty3";
                manager15.LastName = "Markham";
                manager15.FirstName = "Elizabeth";
                manager15.Birthday = new DateTime(1990, 5, 21);
                manager15.TypeOfEmployee = EmpType.Employee;
                manager15.Address = "7861 Chevy Chase";
                manager15.City = "Austin";
                manager15.State = "TX";
                manager15.Zip = "78785";
                manager15.PhoneNumber = "9074579845";
                manager15.Email = "e.markham@longhorncinema.com";
                manager15.UserName = "e.markham@longhorncinema.com";

                var result = UserManager.Create(manager15, "monty3");
                db.SaveChanges();
                manager15 = db.Users.First(u => u.UserName == "e.markham@longhorncinema.com");
            }

            AppUser manager16 = db.Users.FirstOrDefault(u => u.Email == "c.baker@longhorncinema.com");
            if (manager16 == null)
            {
                manager16 = new AppUser();
                manager16.Password = "hecktour";
                manager16.LastName = "Baker";
                manager16.FirstName = "Christopher";
                manager16.Birthday = new DateTime(1993, 3, 16);
                manager16.TypeOfEmployee = EmpType.Employee;
                manager16.Address = "1245 Lake Anchorage Blvd.";
                manager16.City = "Cedar Park";
                manager16.State = "TX";
                manager16.Zip = "78613";
                manager16.PhoneNumber = "9075571146";
                manager16.Email = "c.baker@longhorncinema.com";
                manager16.UserName = "c.baker@longhorncinema.com";

                var result = UserManager.Create(manager16, "hecktour");
                db.SaveChanges();
                manager16 = db.Users.First(u => u.UserName == "c.baker@longhorncinema.com");
            }

            AppUser manager17 = db.Users.FirstOrDefault(u => u.Email == "s.saunders@longhorncinema.com");
            if (manager17 == null)
            {
                manager17 = new AppUser();
                manager17.Password = "rankmary";
                manager17.LastName = "Saunders";
                manager17.FirstName = "Sarah";
                manager17.Birthday = new DateTime(1997, 1, 5);
                manager17.TypeOfEmployee = EmpType.Employee;
                manager17.Address = "332 Avenue C";
                manager17.City = "Austin";
                manager17.State = "TX";
                manager17.Zip = "78733";
                manager17.PhoneNumber = "9073497810";
                manager17.Email = "s.saunders@longhorncinema.com";
                manager17.UserName = "s.saunders@longhorncinema.com";

                var result = UserManager.Create(manager17, "rankmary");
                db.SaveChanges();
                manager17 = db.Users.First(u => u.UserName == "s.saunders@longhorncinema.com");
            }

            AppUser manager18 = db.Users.FirstOrDefault(u => u.Email == "w.sewell@longhorncinema.com");
            if (manager18 == null)
            {
                manager18 = new AppUser();
                manager18.Password = "walkamile";
                manager18.LastName = "Sewell";
                manager18.FirstName = "William";
                manager18.Birthday = new DateTime(1986, 5, 25);
                manager18.TypeOfEmployee = EmpType.Manager;
                manager18.Address = "2365 51st St.";
                manager18.City = "Austin";
                manager18.State = "TX";
                manager18.Zip = "78755";
                manager18.PhoneNumber = "9074510084";
                manager18.Email = "w.sewell@longhorncinema.com";
                manager18.UserName = "w.sewell@longhorncinema.com";

                var result = UserManager.Create(manager18, "walkamile");
                db.SaveChanges();
                manager18 = db.Users.First(u => u.UserName == "w.sewell@longhorncinema.com");
            }

            AppUser manager19 = db.Users.FirstOrDefault(u => u.Email == "j.mason@longhorncinema.com");
            if (manager19 == null)
            {
                manager19 = new AppUser();
                manager19.Password = "changalang";
                manager19.LastName = "Mason";
                manager19.FirstName = "Jack";
                manager19.Birthday = new DateTime(1986, 6, 6);
                manager19.TypeOfEmployee = EmpType.Employee;
                manager19.Address = "444 45th St";
                manager19.City = "Austin";
                manager19.State = "TX";
                manager19.Zip = "78701";
                manager19.PhoneNumber = "9018833432";
                manager19.Email = "j.mason@longhorncinema.com";
                manager19.UserName = "j.mason@longhorncinema.com";

                var result = UserManager.Create(manager19, "changalang");
                db.SaveChanges();
                manager19 = db.Users.First(u => u.UserName == "j.mason@longhorncinema.com");
            }

            AppUser manager20 = db.Users.FirstOrDefault(u => u.Email == "j.jackson@longhorncinema.com");
            if (manager20 == null)
            {
                manager20 = new AppUser();
                manager20.Password = "offbeat";
                manager20.LastName = "Jackson";
                manager20.FirstName = "Jack";
                manager20.Birthday = new DateTime(1986, 10, 16);
                manager20.TypeOfEmployee = EmpType.Employee;
                manager20.Address = "222 Main";
                manager20.City = "Austin";
                manager20.State = "TX";
                manager20.Zip = "78760";
                manager20.PhoneNumber = "9075554545";
                manager20.Email = "j.jackson@longhorncinema.com";
                manager20.UserName = "j.jackson@longhorncinema.com";

                var result = UserManager.Create(manager20, "offbeat");
                db.SaveChanges();
                manager20 = db.Users.First(u => u.UserName == "j.jackson@longhorncinema.com");
            }

            AppUser manager21 = db.Users.FirstOrDefault(u => u.Email == "m.nguyen@longhorncinema.com");
            if (manager21 == null)
            {
                manager21 = new AppUser();
                manager21.Password = "landus";
                manager21.LastName = "Nguyen";
                manager21.FirstName = "Mary";
                manager21.Birthday = new DateTime(1988, 4, 5);
                manager21.TypeOfEmployee = EmpType.Employee;
                manager21.Address = "465 N. Bear Cub";
                manager21.City = "Austin";
                manager21.State = "TX";
                manager21.Zip = "78734";
                manager21.PhoneNumber = "9075524141";
                manager21.Email = "m.nguyen@longhorncinema.com";
                manager21.UserName = "m.nguyen@longhorncinema.com";

                var result = UserManager.Create(manager21, "landus");
                db.SaveChanges();
                manager21 = db.Users.First(u => u.UserName == "m.nguyen@longhorncinema.com");
            }

            AppUser manager22 = db.Users.FirstOrDefault(u => u.Email == "s.barnes@longhorncinema.com");
            if (manager22 == null)
            {
                manager22 = new AppUser();
                manager22.Password = "rhythm";
                manager22.LastName = "Barnes";
                manager22.FirstName = "Susan";
                manager22.Birthday = new DateTime(1993, 2, 22);
                manager22.TypeOfEmployee = EmpType.Employee;
                manager22.Address = "888 S. Main";
                manager22.City = "Kyle";
                manager22.State = "TX";
                manager22.Zip = "78640";
                manager22.PhoneNumber = "9556662323";
                manager22.Email = "s.barnes@longhorncinema.com";
                manager22.UserName = "s.barnes@longhorncinema.com";

                var result = UserManager.Create(manager22, "rhythm");
                db.SaveChanges();
                manager22 = db.Users.First(u => u.UserName == "s.barnes@longhorncinema.com");
            }

            AppUser manager23 = db.Users.FirstOrDefault(u => u.Email == "l.jones@longhorncinema.com");
            if (manager23 == null)
            {
                manager23 = new AppUser();
                manager23.Password = "kindly";
                manager23.LastName = "Jones";
                manager23.FirstName = "Lester";
                manager23.Birthday = new DateTime(1996, 6, 29);
                manager23.TypeOfEmployee = EmpType.Employee;
                manager23.Address = "999 LeBlat";
                manager23.City = "Austin";
                manager23.State = "TX";
                manager23.Zip = "78747";
                manager23.PhoneNumber = "9886662222";
                manager23.Email = "l.jones@longhorncinema.com";
                manager23.UserName = "l.jones@longhorncinema.com";

                var result = UserManager.Create(manager23, "kindly");
                db.SaveChanges();
                manager23 = db.Users.First(u => u.UserName == "l.jones@longhorncinema.com");
            }

            AppUser manager24 = db.Users.FirstOrDefault(u => u.Email == "h.garcia@longhorncinema.com");
            if (manager24 == null)
            {
                manager24 = new AppUser();
                manager24.Password = "instrument";
                manager24.LastName = "Garcia";
                manager24.FirstName = "Hector";
                manager24.Birthday = new DateTime(1997, 5, 13);
                manager24.TypeOfEmployee = EmpType.Employee;
                manager24.Address = "777 PBR Drive";
                manager24.City = "Austin";
                manager24.State = "TX";
                manager24.Zip = "78712";
                manager24.PhoneNumber = "9221114444";
                manager24.Email = "h.garcia@longhorncinema.com";
                manager24.UserName = "h.garcia@longhorncinema.com";

                var result = UserManager.Create(manager24, "instrument");
                db.SaveChanges();
                manager24 = db.Users.First(u => u.UserName == "h.garcia@longhorncinema.com");
            }

            AppUser manager25 = db.Users.FirstOrDefault(u => u.Email == "c.silva@longhorncinema.com");
            if (manager25 == null)
            {
                manager25 = new AppUser();
                manager25.Password = "arched";
                manager25.LastName = "Silva";
                manager25.FirstName = "Cindy";
                manager25.Birthday = new DateTime(1997, 12, 29);
                manager25.TypeOfEmployee = EmpType.Employee;
                manager25.Address = "900 4th St";
                manager25.City = "Austin";
                manager25.State = "TX";
                manager25.Zip = "78758";
                manager25.PhoneNumber = "9221113333";
                manager25.Email = "c.silva@longhorncinema.com";
                manager25.UserName = "c.silva@longhorncinema.com";

                var result = UserManager.Create(manager25, "arched");
                db.SaveChanges();
                manager25 = db.Users.First(u => u.UserName == "c.silva@longhorncinema.com");
            }

            AppUser manager26 = db.Users.FirstOrDefault(u => u.Email == "m.lopez@longhorncinema.com");
            if (manager26 == null)
            {
                manager26 = new AppUser();
                manager26.Password = "median";
                manager26.LastName = "Lopez";
                manager26.FirstName = "Marshall";
                manager26.Birthday = new DateTime(1996, 11, 4);
                manager26.TypeOfEmployee = EmpType.Employee;
                manager26.Address = "90 SW North St";
                manager26.City = "Austin";
                manager26.State = "TX";
                manager26.Zip = "78729";
                manager26.PhoneNumber = "9234442222";
                manager26.Email = "m.lopez@longhorncinema.com";
                manager26.UserName = "m.lopez@longhorncinema.com";

                var result = UserManager.Create(manager26, "median");
                db.SaveChanges();
                manager26 = db.Users.First(u => u.UserName == "m.lopez@longhorncinema.com");
            }

            AppUser manager27 = db.Users.FirstOrDefault(u => u.Email == "b.larson@longhorncinema.com");
            if (manager27 == null)
            {
                manager27 = new AppUser();
                manager27.Password = "approval";
                manager27.LastName = "Larson";
                manager27.FirstName = "Bill";
                manager27.Birthday = new DateTime(1999, 11, 14);
                manager27.TypeOfEmployee = EmpType.Employee;
                manager27.Address = "1212 N. First Ave";
                manager27.City = "Round Rock";
                manager27.State = "TX";
                manager27.Zip = "78665";
                manager27.PhoneNumber = "9795554444";
                manager27.Email = "b.larson@longhorncinema.com";
                manager27.UserName = "b.larson@longhorncinema.com";

                var result = UserManager.Create(manager27, "approval");
                db.SaveChanges();
                manager27 = db.Users.First(u => u.UserName == "b.larson@longhorncinema.com");
            }

            AppUser manager28 = db.Users.FirstOrDefault(u => u.Email == "s.rankin@longhorncinema.com");
            if (manager28 == null)
            {
                manager28 = new AppUser();
                manager28.Password = "decorate";
                manager28.LastName = "Rankin";
                manager28.FirstName = "Suzie";
                manager28.Birthday = new DateTime(1999, 12, 17);
                manager28.TypeOfEmployee = EmpType.Employee;
                manager28.Address = "23 Polar Bear Road";
                manager28.City = "Austin";
                manager28.State = "TX";
                manager28.Zip = "78712";
                manager28.PhoneNumber = "9893336666";
                manager28.Email = "s.rankin@longhorncinema.com";
                manager28.UserName = "s.rankin@longhorncinema.com";

                var result = UserManager.Create(manager28, "decorate");
                db.SaveChanges();
                manager28 = db.Users.First(u => u.UserName == "s.rankin@longhorncinema.com");
            }
        }
    }
}

