namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class IdentityandCCinfo1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Customers", "AppUser_Id", "dbo.AspNetUsers");
            DropForeignKey("dbo.Movies", "Customer_CustomerID", "dbo.Customers");
            DropForeignKey("dbo.Employees", "AppUser_Id", "dbo.AspNetUsers");
            DropIndex("dbo.Movies", new[] { "Customer_CustomerID" });
            DropIndex("dbo.Customers", new[] { "AppUser_Id" });
            DropIndex("dbo.Employees", new[] { "AppUser_Id" });
            AddColumn("dbo.AspNetUsers", "Password", c => c.String(nullable: false));
            AddColumn("dbo.AspNetUsers", "MiddleInitial", c => c.String());
            AddColumn("dbo.AspNetUsers", "Birthday", c => c.DateTime(nullable: false));
            AddColumn("dbo.AspNetUsers", "Address", c => c.String());
            AddColumn("dbo.AspNetUsers", "City", c => c.String(nullable: false));
            AddColumn("dbo.AspNetUsers", "State", c => c.String(nullable: false));
            AddColumn("dbo.AspNetUsers", "Zip", c => c.String(nullable: false, maxLength: 5));
            AddColumn("dbo.AspNetUsers", "PopcornPoints", c => c.Int(nullable: false));
            AddColumn("dbo.AspNetUsers", "CreditCardNumber", c => c.String());
            AddColumn("dbo.AspNetUsers", "TypeOfEmployee", c => c.Int(nullable: false));
            DropColumn("dbo.Movies", "Customer_CustomerID");
            DropTable("dbo.Customers");
            DropTable("dbo.Employees");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        EmployeeID = c.Int(nullable: false, identity: true),
                        LastName = c.String(nullable: false),
                        FirstName = c.String(nullable: false),
                        Password = c.String(nullable: false),
                        SSN = c.String(nullable: false),
                        Address = c.String(nullable: false),
                        City = c.String(nullable: false),
                        State = c.String(nullable: false),
                        Zip = c.String(nullable: false),
                        Phone = c.String(nullable: false),
                        Email = c.String(nullable: false),
                        TypeOfEmployee = c.Int(nullable: false),
                        AppUser_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.EmployeeID);
            
            CreateTable(
                "dbo.Customers",
                c => new
                    {
                        CustomerID = c.Int(nullable: false, identity: true),
                        Password = c.String(nullable: false),
                        FirstName = c.String(nullable: false),
                        LastName = c.String(nullable: false),
                        MiddleInitial = c.String(nullable: false),
                        Birthday = c.String(nullable: false),
                        Street = c.String(nullable: false),
                        City = c.String(nullable: false),
                        State = c.String(nullable: false),
                        Zip = c.String(nullable: false),
                        SSN = c.String(nullable: false),
                        Email = c.String(nullable: false),
                        PopcornPoints = c.Int(nullable: false),
                        CreditCardNumber = c.String(),
                        AppUser_Id = c.String(maxLength: 128),
                    })
                .PrimaryKey(t => t.CustomerID);
            
            AddColumn("dbo.Movies", "Customer_CustomerID", c => c.Int());
            DropColumn("dbo.AspNetUsers", "TypeOfEmployee");
            DropColumn("dbo.AspNetUsers", "CreditCardNumber");
            DropColumn("dbo.AspNetUsers", "PopcornPoints");
            DropColumn("dbo.AspNetUsers", "Zip");
            DropColumn("dbo.AspNetUsers", "State");
            DropColumn("dbo.AspNetUsers", "City");
            DropColumn("dbo.AspNetUsers", "Address");
            DropColumn("dbo.AspNetUsers", "Birthday");
            DropColumn("dbo.AspNetUsers", "MiddleInitial");
            DropColumn("dbo.AspNetUsers", "Password");
            CreateIndex("dbo.Employees", "AppUser_Id");
            CreateIndex("dbo.Customers", "AppUser_Id");
            CreateIndex("dbo.Movies", "Customer_CustomerID");
            AddForeignKey("dbo.Employees", "AppUser_Id", "dbo.AspNetUsers", "Id");
            AddForeignKey("dbo.Movies", "Customer_CustomerID", "dbo.Customers", "CustomerID");
            AddForeignKey("dbo.Customers", "AppUser_Id", "dbo.AspNetUsers", "Id");
        }
    }
}
