namespace Final_Project.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DiscountModel : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Discounts",
                c => new
                    {
                        DiscountID = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false),
                        Amount = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.DiscountID);
            
            CreateTable(
                "dbo.DiscountTickets",
                c => new
                    {
                        Discount_DiscountID = c.Int(nullable: false),
                        Ticket_TicketID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Discount_DiscountID, t.Ticket_TicketID })
                .ForeignKey("dbo.Discounts", t => t.Discount_DiscountID, cascadeDelete: true)
                .ForeignKey("dbo.Tickets", t => t.Ticket_TicketID, cascadeDelete: true)
                .Index(t => t.Discount_DiscountID)
                .Index(t => t.Ticket_TicketID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.DiscountTickets", "Ticket_TicketID", "dbo.Tickets");
            DropForeignKey("dbo.DiscountTickets", "Discount_DiscountID", "dbo.Discounts");
            DropIndex("dbo.DiscountTickets", new[] { "Ticket_TicketID" });
            DropIndex("dbo.DiscountTickets", new[] { "Discount_DiscountID" });
            DropTable("dbo.DiscountTickets");
            DropTable("dbo.Discounts");
        }
    }
}
