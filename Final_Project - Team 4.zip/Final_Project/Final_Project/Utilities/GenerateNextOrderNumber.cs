﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Final_Project.DAL;

namespace Final_Project.Utilities
{
    public static class GenerateNextOrderNumber
    {
        public static Int32 GetNextOrderNumber()
        {
            AppDbContext db = new AppDbContext();

            Int32 intMaxOrderNumber;
            Int32 intNextOrderNumber;

            if(db.Orders.Count() == 0)
            {
                intMaxOrderNumber = 10000;
            }
            else
            {
                intMaxOrderNumber = db.Orders.Max(o => o.OrderNumber);
            }

            intNextOrderNumber = intMaxOrderNumber + 1;

            return intNextOrderNumber;
        }
    }
}