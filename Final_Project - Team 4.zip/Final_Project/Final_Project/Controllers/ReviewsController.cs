﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Final_Project.DAL;
using Final_Project.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;


namespace Final_Project.Controllers
{
   [Authorize]
    public class ReviewsController : Controller
    {
        private AppDbContext db = new AppDbContext();


        public ActionResult Manage()
        {
            return View(db.Reviews.ToList());
        }

        [HttpPost]
        public ActionResult Approve(int ReviewID)
        {
            Review review = db.Reviews.FirstOrDefault(r => r.ReviewID == ReviewID);

            review.Status = ReviewStatus.Confirmed;
            db.SaveChanges();

            return RedirectToAction("Manage", db.Reviews.ToList());
        }

        // GET: Reviews
        public ActionResult Index()
        {
            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);
            List<Review> userReviews = user.Reviews.ToList();

            return View(userReviews);
        }

        [Authorize]
        // GET: Reviews/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Review review = db.Reviews.Find(id);
            if (review == null)
            {
                return HttpNotFound();
            }
            return View(review);
        }

        [Authorize]
        // GET: Reviews/Create
        public ActionResult Create()
        {

            ViewBag.UserMovies = GetUserMovies();


            return View();


        }

        public SelectList GetUserMovies()
        {
            //TODO: uncomment this

            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);
            List<Movie> AllMovies = new List<Movie>();

            foreach (Order order in user.Orders)
            {
                foreach (Ticket t in order.Tickets)
                {
                    AllMovies.Add(t.Showing.Movie);
                }
            }

            //TODO: comment this
            // List<Movie> AllMovies = db.Movies.ToList();

            //foreach (Movie m in user.Orders.Ticket.Movies)
            //{
            //    if (AllMovies.Contains(m) == false)
            //    {
            //        AllMovies.Add(m);
            //    }
            //}
            SelectList UserMovies = new SelectList(AllMovies.OrderBy(m => m.Title), "MovieID", "Title");

            return UserMovies;

        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ReviewID,decStars,ReviewText")] Review review, int SelectedMovie)
        {
            review.Status = ReviewStatus.Pending;
            review.Movie = db.Movies.FirstOrDefault(m => m.MovieID == SelectedMovie);
            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);
            review.AppUser = user;

            if (ModelState.IsValid)
            {
                Movie movie = db.Movies.FirstOrDefault(m => m.MovieID == SelectedMovie);

                if (movie.TotalReviews == 0 && movie.TotalStars == 0)
                {
                    movie.TotalReviews = 1;
                    movie.TotalStars = review.decStars;
                }
                else
                {
                    movie.TotalReviews += 1;
                    movie.TotalStars += review.decStars;
                }
         

                db.SaveChanges();

                
                db.Reviews.Add(review);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.UserMovies = GetUserMovies();
            return View(review);
        }


        [Authorize]
        // GET: Reviews/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Review review = db.Reviews.Find(id);
            if (review == null)
            {
                return HttpNotFound();
            }
            Movie movie = review.Movie;

            movie.TotalStars -= review.decStars;

            return View(review);
        }

        [Authorize]
        // POST: Reviews/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ReviewID,decStars,ReviewText")] Review review)
        {
            if (ModelState.IsValid)
            {
                Movie movie = review.Movie;

                movie.TotalStars += review.decStars;

                db.Entry(review).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(review);
        }

        [Authorize]
        // GET: Reviews/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Review review = db.Reviews.Find(id);
            if (review == null)
            {
                return HttpNotFound();
            }
            return View(review);
        }

        [Authorize]
        // POST: Reviews/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Review review = db.Reviews.Find(id);
            Movie movie = review.Movie;

            movie.TotalStars -= review.decStars;
            movie.TotalReviews -= 1;


            db.Reviews.Remove(review);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
