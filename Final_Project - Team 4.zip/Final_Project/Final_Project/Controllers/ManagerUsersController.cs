﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Final_Project.DAL;
using Final_Project.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;

namespace Final_Project.Controllers
{
    public class ManagerUsersController : Controller
    {
        public UserManager<AppUser> UserManager { get; private set; }

        private AppDbContext db = new AppDbContext();

        // GET: ManagerUsers
        [Authorize(Roles = "Manager")]
        public ActionResult Index()
        {
            var users = db.Users.Where(x => x.TypeOfEmployee == EmpType.Employee);
            var query2 = users.Where(x => x.IsNotActive == false).ToList();

            //List < AppUser > newUsers = new List<AppUser> { };
            //foreach ( AppUser user in users)
            //{


            //    System.Diagnostics.Debug.WriteLine(user.Roles);

            //}

            return View(query2);
        }

        //[Authorize(Roles = "Employee")]
        //[Authorize(Roles = "Manager")]
        public ActionResult IndexCustomers()
        {
            var users = db.Users.Where(x => x.TypeOfEmployee == EmpType.Customer).ToList();
            return View(users);
        }


        public ActionResult IndexInactiveUsers()
        {
            var users = db.Users.Where(x => x.TypeOfEmployee == EmpType.Employee);
            var query2 = users.Where(x => x.IsNotActive == true).ToList();
            return View(query2);
        }


        // GET: ManagerUsers/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppUser appUser = db.Users.Find(id);
            if (appUser == null)
            {
                return HttpNotFound();
            }
            return View(appUser);
        }


        // GET: ManagerUsers/Details/5
        public ActionResult DetailsEmployee(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppUser appUser = db.Users.Find(id);
            if (appUser == null)
            {
                return HttpNotFound();
            }
            return View(appUser);
        }


        public ActionResult DetailsInactiveUsers(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppUser appUser = db.Users.Find(id);
            if (appUser == null)
            {
                return HttpNotFound();
            }
            return View(appUser);
        }



        //// GET: ManagerUsers/Create
        public ActionResult Create()
        {
            ViewBag.ErrorMessage = "";
            return View();
        }

        //// POST: ManagerUsers/Create
        //// To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        //// more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,FirstName,LastName,Password,MiddleInitial,Birthday,Address,City,State,Zip,PopcornPoints,TypeOfEmployee,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName")] AppUser appUser)
        {
            DateTime now = DateTime.Today;
            DateTime minimumDate = DateTime.Today.AddYears(-18);

            if (appUser.Birthday > minimumDate)
            {
                ViewBag.ErrorMessage = "Employee must be at least 18 to be hired.";
                return View(appUser);
            }

            else if (ModelState.IsValid)
            {
                AppUser manager1 = db.Users.FirstOrDefault(u => u.Email == appUser.Email);
                if (manager1 == null)
                {
                    manager1 = new AppUser();
                    manager1.Password = appUser.Password;
                    manager1.LastName = appUser.LastName;
                    manager1.FirstName = appUser.FirstName;
                    manager1.Birthday = appUser.Birthday;
                    manager1.TypeOfEmployee = EmpType.Employee;
                    manager1.PhoneNumber = appUser.PhoneNumber;
                    manager1.Email = appUser.Email;
                    manager1.UserName = appUser.Email;

                    var result = UserManager.Create(manager1, appUser.Password);
                    db.SaveChanges();
                    manager1 = db.Users.First(u => u.UserName == appUser.Email);
                }

                db.Users.Add(manager1);
                //await UserManager.AddToRoleAsync(appUser.Id, "Employee");
                appUser.IsNotActive = false;

                //db.Users.Add(appUser);
                db.SaveChanges();
                return RedirectToAction("Index");

            }

            else
            {
                
                var errors = ModelState.Select(x => x.Value.Errors)
                    .Where(y => y.Count > 0)
                    .ToList();

                //String errorString = "";

                //foreach (ModelError error in errors)
                //{
                //    errorString += error;
                //}

                System.Diagnostics.Debug.Write(ModelState.ToString());
            }


            appUser.IsNotActive = false;

            return RedirectToAction("IndexInactiveUsers");

        }
   


            // GET: ManagerUsers/Edit/5
            public ActionResult Edit(string id)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                AppUser appUser = db.Users.Find(id);
                if (appUser == null)
                {
                    return HttpNotFound();
                }
                return View(appUser);
            }

        // POST: ManagerUsers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,FirstName,LastName,Password,MiddleInitial,Birthday,Address,City,State,Zip,PopcornPoints,TypeOfEmployee,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName")] AppUser appUser)
        {
            //appUser.State = "TX";
            if (ModelState.IsValid)
            {
                db.Entry(appUser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(appUser);
        }




        public ActionResult Fire(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            AppUser appUser = db.Users.Find(id);
            if (appUser == null)
            {
                return HttpNotFound();
            }
            return View(appUser);
        }

        [HttpPost, ActionName("Fire")]
        [ValidateAntiForgeryToken]
        public ActionResult FireConfirmed(string id)
        {
            AppUser appUser = db.Users.Find(id);
            appUser.IsNotActive = true;
            //db.Users.Remove(appUser);
            db.SaveChanges();
            return RedirectToAction("Index");
        }


        public ActionResult Hire(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            AppUser appUser = db.Users.Find(id);
            if (appUser == null)
            {
                return HttpNotFound();
            }
            return View(appUser);
        }

        [HttpPost, ActionName("Hire")]
        [ValidateAntiForgeryToken]
        public ActionResult HireConfirmed(string id)
        {
            AppUser appUser = db.Users.Find(id);
            appUser.IsNotActive = false;
            //db.Users.Remove(appUser);
            db.SaveChanges();
            return RedirectToAction("Index");
        }




        public ActionResult PromoteEmployee(String id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            ViewBag.UserID = id;

            AppUser appUser = db.Users.Find(id);
            if (appUser == null)
            {
                return HttpNotFound();
            }
            return View(appUser);
        }


        //Promote Employee
        [HttpPost]
        [ValidateAntiForgeryToken]
          public ActionResult PromoteEmployeeConfirmed(String id)
          {

            AppUser appUser = db.Users.Find(id);
            //if (Roles.GetRolesForUser().Contains("Employee"))
            //{
                //AppRole role = RoleManager.FindById(id);
                //AppRoleManager.AddToRole(appUser.Id, "Manager");
                ViewBag.UserID = id;

                RoleModificationModel model = new RoleModificationModel();
                IdentityResult result = new IdentityResult();

                result = UserManager.AddToRole(appUser.Id, model.RoleName);

            //}
            db.Users.Remove(appUser);
            db.SaveChanges();
            ViewBag.UserID = id;

            return RedirectToAction("Index");
           }




    }
}
