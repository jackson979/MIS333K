﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Final_Project.DAL;
using Final_Project.Models;

namespace Final_Project.Controllers
{
    public class ReportsController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Reports
        [Authorize(Roles = "Manager")]
        public ActionResult Index(String displayStr)
        {

            if (displayStr != null)
            {
                List<String> FirstReportLst = displayStr.Split(' ').ToList();
                String FirstReport = "Total Seats: " + FirstReportLst[0] + " Total Revenue: " + FirstReportLst[1];
                ViewBag.displayStr = FirstReport;
            }

            return View();
        }



   
        public ActionResult DetailSearch( )
        {
            ViewBag.AllCustomers = GetAllCustomers();
            ViewBag.AllMovies = GetAllMovies();
            List<AppUser> usersList = new List<AppUser>();
            ViewBag.users = usersList;

            

            return View();
        }


        [HttpPost]
        public ActionResult DetailSearchPost(DateTime? SelectedStartTime, DateTime? SelectedEndTime, DateTime? DayStart, DateTime? DayEnd, int? SelectedMPAA, int? TotalSeats, int? TotalRevenue, int[]  SelectedMovies)
        {
            String returnedString = QueryBasedOnMovie( SelectedStartTime,  SelectedEndTime,  DayStart,  DayEnd, SelectedMPAA,  TotalSeats,  TotalRevenue, SelectedMovies);
            List<String> returnStringLst = returnedString.Split(' ').ToList();
            if (returnStringLst.Count > 2)
            {
                ViewBag.AllMovies = GetAllMovies();
                return RedirectToAction("DetailSearch");
            }
        
            return RedirectToAction("Index", new { displayStr = returnedString });
        }

        public String QueryBasedOnMovie(DateTime? SelectedStartTime, DateTime? SelectedEndTime, DateTime? DayStart, DateTime? DayEnd, int? SelectedMPAA, int? TotalSeats, int? TotalRevenue, int[] SelectedMovies)
        {
            
            List<Showing> Showings = new List<Showing>();

            var showingQuery = from r in db.Showings select r;
            List<Showing> newShowings = new List<Showing>();



            int StartDay;
            //Filter Based on StartDate
            if (SelectedStartTime != null)
            {
                //convert date to non-nullable type.  ?? means if the datSelectedDate is null, set it equal to Jan 1, 1900231                
                DateTime datSelected = SelectedStartTime ?? new DateTime(1900, 1, 1);

                // converting to sai time
                 StartDay = datSelected.Day - 3;
                showingQuery = showingQuery.Where(s => s.StartTime.Day > StartDay);
                if (showingQuery.ToList().Count == 0)
                {
                    return "Could not find any showing with the start time requirements";
                }
            }

        

            int EndDay;
            if (SelectedEndTime != null)
            {
                DateTime datSelected = SelectedEndTime ?? new DateTime(1900, 1, 1);


                //converting to sai time
                EndDay = datSelected.Day - 3;
                showingQuery = showingQuery.Where(s => s.StartTime.Day > EndDay);

                if (showingQuery.ToList().Count == 0)
                {
                    return "Could not find any showings try changing Ending Date Range";
                }
            }



            int DayStartHour;
            int DayStartMinutes;
            if (DayStart != null)
            {
                DateTime datSelected = DayStart ?? new DateTime(1900, 1, 1);


                DayStartHour = datSelected.Hour;
                DayStartMinutes = datSelected.Minute;

                showingQuery = showingQuery.Where(s => s.StartTime.Hour > DayStartHour && s.StartTime.Minute > DayStartMinutes);

                if (showingQuery.ToList().Count == 0)
                {
                    return "Could not find any showing that match your requirements try changing Start period of day";
                }
            }


            int DayEndHour;
            int DayEndMinutes;
            if (DayEnd != null)
            {

                DateTime datSelected = DayEnd ?? new DateTime(1900, 1, 1);

                DayEndHour = datSelected.Hour;
                DayEndMinutes = datSelected.Minute;

                showingQuery = showingQuery.Where(s => s.StartTime.Hour > DayEndHour && s.StartTime.Minute > DayEndMinutes);

                if (showingQuery.ToList().Count == 0)
                {
                    return "Could not find any showing that match your requirements try changing end period of day";
                }

            }

            //querying based on movies

            int[] list = {  };

            if (SelectedMovies != null)
            {
                List<Movie> Movies = new List<Movie>();
               
                var queryMovies = from r in db.Movies select r;

                foreach (int id in SelectedMovies)
                {
                    queryMovies = queryMovies.Where(m => m.MovieID == id);
                }

                Movies = queryMovies.ToList();

                foreach (Showing showing in showingQuery.ToList())
                {
                    foreach (Movie movie in Movies)
                    {
                        if (showing.Movie.MovieID == movie.MovieID)
                        {
                            newShowings.Add(showing);
                        }
                    }
                }


                if (newShowings.Count == 0)
                {
                    return "Could not find any showing that match your requirements trychanging movies";
                }
            } else
            {
                newShowings = showingQuery.ToList();
            }


            String toReturn = "";

            int totalSeats;
            if (TotalSeats != 0)
            {
                totalSeats = TotalSeatss(newShowings);
                toReturn += totalSeats.ToString() + " "; 
            } else
            {
                toReturn += "didn'tQuery ";
            }


            decimal totalRevenue;
            if (TotalRevenue != 0)
            {
                totalRevenue = TotalRevenues(newShowings);
                toReturn += totalRevenue.ToString();
            }
            else
            {
                toReturn += "didn'tQuery";
            }

            

            return toReturn;
        }

        
        public int TotalSeatss( List<Showing> showings)
        {
            decimal totalReveneue = 0.0M;
            int totalSeats = 0;

            foreach (Showing showing in showings)
            {
                foreach (Ticket ticket in showing.Tickets)
                {
                    totalReveneue += ticket.TotalPrice;
                    totalSeats += 1;
                    System.Diagnostics.Debug.WriteLine(totalSeats);
                }
            }
            Decimal tax = 1.0825M;
            totalReveneue = totalReveneue * tax;
            return totalSeats;
        }

        public decimal TotalRevenues(List<Showing> showings)
        {
             decimal totalReveneue  = 0.0M;
            int totalSeats = 0;

            foreach (Showing showing in showings)
            {
                foreach (Ticket ticket in showing.Tickets)
                {
                    totalReveneue += ticket.TotalPrice;
                    totalSeats += 1;
                    System.Diagnostics.Debug.WriteLine(totalSeats);
                }
            }
            Decimal tax = 1.0825M;
            totalReveneue = totalReveneue * tax;
            return totalReveneue;
        }

        public MultiSelectList GetAllMovies()
        {
            List<Movie> Movies = db.Movies.ToList();

            MultiSelectList AllGenres = new MultiSelectList(Movies.OrderBy(g => g.Title), "MovieID", "Title");

            return AllGenres;
        }

        public MultiSelectList GetAllCustomers()
        {
            List<AppUser> Users = db.Users.ToList();

            MultiSelectList AllMovies = new MultiSelectList(Users.OrderBy(g => g.Email), "Id", "Email");

            return AllMovies;
        }

        [HttpPost]
        public ActionResult DetailSearchPost2(string[] SelectedCustomers)
        {

 


            List<String> newList = new List<String>();
            if (SelectedCustomers != null)
            {
                System.Diagnostics.Debug.Write(SelectedCustomers.ToList()[0]);
                System.Diagnostics.Debug.Write(SelectedCustomers.ToList().Count);

                List<AppUser> usersList = new List<AppUser>();
                foreach (string id in SelectedCustomers.ToList())
                {
                    System.Diagnostics.Debug.Write(id.ToString());
                    //AppUser user = db.Users.FirstOrDefault(u => u.Email == id);
                    AppUser user = db.Users.Find(id);
                    System.Diagnostics.Debug.Write(user.FirstName);
                    usersList.Add(user);
                }
                ViewBag.users = usersList;
                return View();
            }

            return View();
        }

        [HttpPost]
        public ActionResult DetailSearchPost3()
        {

            var query = from r in db.Tickets select r;
            query = query.Where(r => r.PaymentMethod == PaymentMethod.PopcornPoints);
            List<Ticket> AllShowings = new List<Ticket>();
            AllShowings = query.ToList();

            List<String> newList = new List<String>();
            if (AllShowings != null && AllShowings.Count != 0)
            {
               
                ViewBag.tickets = AllShowings;
               
                ViewBag.nope = "";
                return View();
            }
            ViewBag.nope = "no popcorn tickets";
            return View();
        }


    }
}