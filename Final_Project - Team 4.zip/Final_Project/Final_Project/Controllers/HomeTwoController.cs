﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Final_Project.DAL;
using Final_Project.Models;
using System.Net;
using System.Data.Entity;
using Microsoft.AspNet.Identity;

namespace Final_Project.Controllers
{
    public class HomeTwoController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: HomeTwo
        public ActionResult Index()
        {
            var query = from r in db.Showings select r;
            List<Showing> showingList = query.Where(s => s.StartTime.Day == 1).ToList();
            return View(showingList);
        }
    }
}