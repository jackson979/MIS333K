﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Final_Project.DAL;
using Final_Project.Models;

namespace Final_Project.Controllers
{
    public class SellTicketsController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: SellTickets
        [Authorize]
        public ActionResult Index()
        {


            var users = db.Users.Where(x => x.TypeOfEmployee == EmpType.Customer).ToList();
            //AppUser user = db.Users.FirstOrDefault(m => m.UserID == SelectedUser);


            //AppUser UserToDisplay = db.Users.Find(SelectedUser);
            //ViewBag.SelectedLanguage = "The selected language is " + LanguageToDisplay.LanguageID;

            //var repos = SelectedRepositories
            //.Where(r => r.Language == LanguageToDisplay);

            //query = query.Where(r => r.Language.LanguageID == SelectedLanguage);



            //db.Repositories.Include("Language").ToList();

            //ViewBag.TotalRepositories = db.Repositories.Count();
            //ViewBag.SelectedRepositories = SelectedRepositories.Count();

            return View(users);
        }

        //// GET: SellTickets/Details/5
        //public ActionResult Details(string id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    AppUser appUser = db.AppUsers.Find(id);
        //    if (appUser == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(appUser);
        //}

        // GET: SellTickets/Create
        public ActionResult Create()
        {
            return View();
        }

        //// POST: SellTickets/Create
        //// To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        //// more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Id,FirstName,LastName,Password,MiddleInitial,Birthday,Address,IsNotActive,City,State,Zip,PopcornPoints,TypeOfEmployee,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName")] AppUser appUser)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.AppUsers.Add(appUser);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }

        //    return View(appUser);
        //}

        // GET: SellTickets/Edit/5
        //public ActionResult Edit(string id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    AppUser appUser = db.AppUsers.Find(id);
        //    if (appUser == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(appUser);
        //}

        //// POST: SellTickets/Edit/5
        //// To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        //// more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Edit([Bind(Include = "Id,FirstName,LastName,Password,MiddleInitial,Birthday,Address,IsNotActive,City,State,Zip,PopcornPoints,TypeOfEmployee,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName")] AppUser appUser)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Entry(appUser).State = EntityState.Modified;
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(appUser);
        //}

        //// GET: SellTickets/Delete/5
        //public ActionResult Delete(string id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    AppUser appUser = db.AppUsers.Find(id);
        //    if (appUser == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(appUser);
        //}

        //// POST: SellTickets/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(string id)
        //{
        //    AppUser appUser = db.AppUsers.Find(id);
        //    db.AppUsers.Remove(appUser);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing)
        //    {
        //        db.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}
    }
}
