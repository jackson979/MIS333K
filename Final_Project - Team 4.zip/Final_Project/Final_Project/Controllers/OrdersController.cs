﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using Final_Project.DAL;
using Final_Project.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;

namespace Final_Project.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private AppDbContext db = new AppDbContext();


        
        public ActionResult FinalConfirmOrder(int? OrderID)
        {

            Order order = db.Orders.Find(OrderID);
            ViewBag.OrderNum = order.OrderNumber;
            ViewBag.OrderID = OrderID;

            return View();
        }

        [HttpPost]
        public ActionResult FinalConfirmOrderPost(int? OrderID)
        {


            return RedirectToAction("Index", "Orders");
        }

        // GET: Orders
        public ActionResult Index()
        {
            //String UserID = User.Identity.GetUserId();
            //AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);
            //List<Order> userOrders = user.Orders.ToList();


            return View(db.Orders.ToList());
        }

        // GET: Orders/Details/5
        public ActionResult Details(int? id, String str)
        {
            ViewBag.GiftError = str;

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }

            List<Ticket> newTicketList = order.Tickets.ToList();

            List<Showing> newShowings = new List<Showing>();

            foreach (Ticket t in newTicketList)
            {
                newShowings.Add(t.Showing);
            }


            newShowings.Sort((x, y) => x.StartTime.CompareTo(y.StartTime));

            if (newShowings.Count == 0 || newShowings == null)
            {
                ViewBag.Confirm = false;
                ViewBag.DisplayCancel = false;
            }
            else
            {
                if ((newShowings[0].StartTime - DateTime.Now.AddDays(-3)).TotalMinutes < 60)
                {
                    ViewBag.DisplayCancel = false;
                }
                else
                {
                    ViewBag.DisplayCancel = true;
                }

                if ((newShowings[0].StartTime - DateTime.Now.AddDays(-3)).TotalMinutes < 0)
                {
                    ViewBag.Confirm = false;
                }
                else
                {
                    ViewBag.Confirm = true;
                }
            }

            


            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);

            List<CreditCard> userCards = user.CreditCards;

            SelectList Cards = new SelectList(userCards.OrderBy(u => u.CreditCardID), "CreditCardID", "CreditCardNumber");

            ViewBag.UserCards = Cards;
            ViewBag.orderID = id;
            return View(order);
        }

        [HttpPost]
        public ActionResult AddGift(int? orderID, bool isGift , String Email)
        {
            if(isGift == false)
            {
                String GiftError = "You must check the box and enter a valid email.";
                return RedirectToAction("Details", new { id = orderID, str = GiftError });
            }

            Order order = db.Orders.Find(orderID);

            List<AppUser> users = db.Users.ToList();
            List<String> emails = new List<String>();

            foreach(AppUser u in users)
            {
                emails.Add(u.Email);
            }

            if(isGift == true && emails.Contains(Email) == false)
            {
                String GiftError = "That user could not be found.";
                return RedirectToAction("Details", new { id = orderID, str = GiftError});
            }

            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Email == Email);

            DateTime now = DateTime.Today;
            DateTime minimumDate = DateTime.Today.AddYears(-18);

            if (isGift == true && user.Birthday > minimumDate)
            {
                List<RatingType> ratings = new List<RatingType>();

                foreach(Ticket t in order.Tickets)
                {
                    ratings.Add(t.Showing.Movie.MPAARating);
                }

                if(ratings.Contains(RatingType.R) || ratings.Contains(RatingType.NC17))
                {
                    String GiftError = "You may not gift R or NC17 tickets to someone younger than 18.";
                    return RedirectToAction("Details", new { id = orderID, str = GiftError });
                }
            }

            order.Gift = isGift;
            order.GiftEmail = Email;

            if (ModelState.IsValid)
            {
                db.SaveChanges();
               // return View("Details", new { id = orderID });
                return RedirectToAction("Details", new { id = orderID });

            }

            return View("Details", new { id = orderID });
        }

        // GET: Orders/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Orders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "OrderID,OrderNumber,OrderDate,Gift,GiftEmail")] Order order)
        {
            order.OrderNumber = Utilities.GenerateNextOrderNumber.GetNextOrderNumber();

            order.OrderDate = DateTime.Today;

            order.Status = OrderStatus.Pending;

            if (ModelState.IsValid)
            {

                db.Orders.Add(order);
                String UserID = User.Identity.GetUserId();
                AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);
                user.Orders.Add(order);


                db.SaveChanges();
                return RedirectToAction("AddToOrder", new { OrderID = order.OrderID });
            }

            return View(order);
        }

        //public ActionResult AddToOrder(int OrderID, int? Day, int? Theater)
        //{
        //    //
        //    ViewData["orderID"] = OrderID;

        //    if (Day != null)
        //    {
        //        ViewData["dayBool"] = Day;
        //        ViewData["theaterBool"] = Theater;
        //        ViewBag.AllShowings = GetAllShowings(Day, Theater);
        //    }
        //    else if (Day == null)
        //    {
        //        ViewData["dayBool"] = 1;
        //        ViewData["theaterBool"] = 1;
        //        ViewBag.AllShowings = GetAllShowings(1, 1);
        //    }

        //    Ticket t = new Ticket();

        //    Order order = db.Orders.Find(OrderID);

        //    t.Order = order;

        //    // check if showings was finalised
        //    var queryFinalised = from r in db.Showings select r;
        //    List<Showing> unfilteredShowings = queryFinalised.ToList();
        //    bool finalised = false;
        //    foreach (Showing showing in unfilteredShowings)
        //    {
        //        if (showing.Theater == 3)
        //        {
        //            finalised = true;
        //        }
        //    }
        //    ViewBag.isFinalised = finalised;

        //    return View(t);
        //}


        // GET: Orders/AddToOrder
        public ActionResult AddToOrder(int OrderID, int? Day, int? Theater)
        {
            //
            ViewData["orderID"] = OrderID;

            if (Day != null)
            {
                ViewData["dayBool"] = Day;
                ViewData["theaterBool"] = Theater;
                ViewBag.AllShowings = GetAllShowings(OrderID,Day, Theater);
            }
            else if (Day == null)
            {
                ViewData["dayBool"] = 1;
                ViewData["theaterBool"] = 1;
                ViewBag.AllShowings = GetAllShowings(OrderID,1,1);
            }

            Ticket t = new Ticket();

            Order order = db.Orders.Find(OrderID);

            t.Order = order;

            // check if showings was finalised
            var queryFinalised = from r in db.Showings select r;
            List<Showing> unfilteredShowings = queryFinalised.ToList();
            bool finalised = false;
            foreach (Showing showing in unfilteredShowings)
            {
                if (showing.Theater == 3)
                {
                    finalised = true;
                }
            }
            ViewBag.isFinalised = finalised;

            return View(t);
        }

        public SelectList GetAllShowings(int OrderID, int? Day, int? Theater)
        {
            List<Showing> Showings = db.Showings.ToList();

            //query all
            var query = from r in db.Showings select r;
            var queryFrom = query.Where(r => r.StartTime.Day == Day);
            queryFrom = queryFrom.Where(r => r.Theater == Theater);

            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);

            DateTime now = DateTime.Today;
            DateTime minimumDate = DateTime.Today.AddYears(-18);

            if(user.Birthday > minimumDate)
            {
                queryFrom = queryFrom.Where(r => r.Movie.MPAARating != RatingType.R);
                queryFrom = queryFrom.Where(r => r.Movie.MPAARating != RatingType.NC17);
            }

            Order order = db.Orders.Find(OrderID);
            List<Showing> currentshowings = new List<Showing>();


            foreach(Ticket t in order.Tickets)
            {
                //TODO: Do querying
                //queryFrom = queryFrom.Where(r => r.Movie.MovieID != t.Showing.Movie.MovieID ||(r.Movie.MovieID == t.Showing.Movie.MovieID && r.ShowingID != t.Showing.ShowingID));
                
            }

            //query for the showings in from and make it list

            Showings = queryFrom.ToList();

            //convert list to select list
            SelectList AllShowings = new SelectList(Showings.OrderBy(s => s.ShowingID), "ShowingID", "DisplayName");

            //return the select list
            return AllShowings;
        }

        //POST: Orders/AddToOrder
        [HttpPost]
        //TODO: add selector to view so we can get SelectedShowing
        public ActionResult AddToOrder(Ticket t, int SelectedShowing)
        {
            Showing showing = db.Showings.Find(SelectedShowing);

            t.Showing = showing;

            Order order = db.Orders.Find(t.Order.OrderID);

            t.Order = order;


            //
            //
            //
            //
            //Start pricing
            if (t.Showing.StartTime.Day == 2 || t.Showing.StartTime.Day == 3 || t.Showing.StartTime.Day == 12 || t.Showing.StartTime.Day == 13)
            {
                Price tempPrice = db.Prices.FirstOrDefault(p => p.PriceID == 3);
                t.Price = tempPrice.Amount;
            }
            else if (t.Showing.StartTime.Day == 1 || t.Showing.StartTime.Day == 11)
            {
                if (t.Showing.StartTime.Hour < 12)
                {
                    Price tempPrice = db.Prices.FirstOrDefault(p => p.PriceID == 1);
                    t.Price = tempPrice.Amount;
                }
                else
                {
                    Price tempPrice = db.Prices.FirstOrDefault(p => p.PriceID == 3);
                    t.Price = tempPrice.Amount;
                }
            }
            else if (t.Showing.StartTime.Day == 5 || t.Showing.StartTime.Day == 15)
            {
                if (t.Showing.StartTime.Hour < 12)
                {
                    Price tempPrice = db.Prices.FirstOrDefault(p => p.PriceID == 1);
                    t.Price = tempPrice.Amount;
                }
                else if (t.Showing.StartTime.Hour < 5)
                {
                    Price tempPrice = db.Prices.FirstOrDefault(p => p.PriceID == 4);
                    t.Price = tempPrice.Amount;
                }
                else
                {
                    Price tempPrice = db.Prices.FirstOrDefault(p => p.PriceID == 2);
                    t.Price = tempPrice.Amount;
                }
            }
            else
            {
                if (t.Showing.StartTime.Hour < 12)
                {
                    Price tempPrice = db.Prices.FirstOrDefault(p => p.PriceID == 1);
                    t.Price = tempPrice.Amount;
                }
                else
                {
                    Price tempPrice = db.Prices.FirstOrDefault(p => p.PriceID == 2);
                    t.Price = tempPrice.Amount;
                }
            }

            if (t.Showing.SpecialEvent == false)
            {
                DateTime now = DateTime.Today;
                DateTime discountDate = DateTime.Today.AddYears(-60);

                String UserID = User.Identity.GetUserId();
                AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);

                if (user.Birthday <= discountDate)
                {
                    Int32 seniorcount = 0;
                    Discount d1 = db.Discounts.FirstOrDefault(a => a.Name == "Senior Citizen");

                    foreach (Ticket t1 in order.Tickets)
                    {
                        if (t1.Discounts.Contains(d1))
                        {
                            seniorcount += 1;
                        }
                    }

                    if (seniorcount < 2)
                    {
                        Discount d = db.Discounts.FirstOrDefault(a => a.Name == "Senior Citizen");
                        t.Discounts.Add(d);
                    }
                }

                DateTime Now = DateTime.Now;

                Now = Now.AddDays(-3);

                DateTime ShowTime = t.Showing.StartTime;

                //TODO: fix movies to fit proper timeframe
                TimeSpan Span = ShowTime - Now;
               // DateTime diff = ShowTime - Now;
                System.Diagnostics.Debug.WriteLine(Now);
                System.Diagnostics.Debug.WriteLine(ShowTime);
                System.Diagnostics.Debug.WriteLine(ShowTime - Now);
                System.Diagnostics.Debug.WriteLine(ShowTime.Day - Now.Day);
                if ( Span.TotalHours >= 48)
                {
                    System.Diagnostics.Debug.WriteLine("DISCOUNT!!!!");
                    Discount d = db.Discounts.FirstOrDefault(a => a.Name == "48 Hours in Advance");
                    t.Discounts.Add(d);
                }
            }
            else
            {
                t.Discounts = new List<Discount>();
            }

            t.TotalPrice = t.Price;

            foreach (Discount d in t.Discounts)
            {
                t.TotalPrice -= d.Amount;
            }
            //End Pricing
            //
            //
            //
            //


            if (ModelState.IsValid)
            {
                db.Tickets.Add(t);
                db.SaveChanges();
                //return RedirectToAction("Details", "Orders", new { id = order.OrderID });
                return RedirectToAction("SelectSeat", "Orders", new { orderID = order.OrderID, ticketID = t.TicketID });
            }

            //ViewBag.AllShowings = GetAllShowings(1);

            return View(t);

        }

        public ActionResult SelectSeat(int orderID, int ticketID)
        {
        

            Ticket ticket = db.Tickets.Find(ticketID);
            ViewBag.Seats = AllTheaterSeats(ticket.Showing.ShowingID);
            ViewBag.OrderID = orderID;
            ViewBag.ticketID = ticketID;


            return View();
        }

        [HttpPost]
        public ActionResult SelectedSeat(int orderID, int ticketID, String seat)
        {
            Ticket ticket = db.Tickets.Find(ticketID);
            ticket.Seat = seat;

            if (ModelState.IsValid)
            {
                db.SaveChanges();
                //return RedirectToAction("Details", "Orders", new { id = order.OrderID });
                return RedirectToAction("Details", "Orders", new { id = orderID });
            }

            ViewBag.Seats = AllTheaterSeats(ticket.Showing.ShowingID);
            ViewBag.OrderID = orderID;
            ViewBag.ticketID = ticketID;


            return View();
        }

        public SelectList AllTheaterSeats(int showingID)
        {

            //need to query tickets on showing.
            //get showing id then where ticket.showing.id == showingID

            List<Ticket> Tickets = new List<Ticket>();
            
            //query all
            var query = from r in db.Tickets select r;
            var queryFrom = query.Where(r => r.Showing.ShowingID == showingID);

            //query for the showings in from and make it list

            Tickets = queryFrom.ToList();

            List<int> seatsList = new List<int>();

            List<String> allSeats = new List<String>();
            for (int i = 1; i <= 4; i++)
            {
                int a = 64;
                char c = Convert.ToChar(i + a);

                for (int j = 1; j <= 8; j++)
                {
                    String seat = c + j.ToString();
                    allSeats.Add(seat);
                }
            }

            for (int i = 0; i < Tickets.Count; i++)
            {
                allSeats.Remove(Tickets[i].Seat);
            }

            //convert list to select list
            SelectList AllShowings = new SelectList(allSeats);

            //return the select list
            return AllShowings;
        }

        [HttpPost]
        public ActionResult ApplyPoints(int OrderID)
        {
            Order order = db.Orders.Find(OrderID);
            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);

            List<Ticket> Tickets = new List<Ticket>();

            foreach(Ticket t in order.Tickets)
            {
                if (t.Showing.SpecialEvent == false)
                {
                    Tickets.Add(t);
                }
            }

            Tickets.Sort((x, y) => x.TotalPrice.CompareTo(y.TotalPrice));

            Ticket maxTicket = Tickets[Tickets.Count() - 1];

            user.PopcornPoints -= 100;
            maxTicket.TotalPrice = 0;
            maxTicket.PaymentMethod = PaymentMethod.PopcornPoints;
            db.SaveChanges();

            return RedirectToAction("Details", "Orders", new { id = order.OrderID });
        }


        [HttpPost]
        public ActionResult ConfirmOrder(int OrderID, int SelectedCard, EmailFormModel model1)
        {
            Order order = db.Orders.Find(OrderID);

            CreditCard card = db.CreditCards.Find(SelectedCard);

            order.Status = OrderStatus.Confirmed;

            order.CreditCard = card;

            Int32 points = Decimal.ToInt32(order.OrderTotal); 

            AppUser user = order.AppUser;
            if (user.PopcornPoints == 0)
            {
                user.PopcornPoints = points;

            }
            else
            {
                user.PopcornPoints += points; 
            }

            foreach(Ticket t in order.Tickets)
            {
                if(t.PaymentMethod != PaymentMethod.PopcornPoints)
                {
                    t.PaymentMethod = PaymentMethod.CreditCard;
                }
            }

            db.SaveChanges();

            String UserID = User.Identity.GetUserId();
            AppUser user1 = db.Users.FirstOrDefault(u => u.FirstName == UserID);

            var username = User.Identity.Name;

            var fromAddress = new MailAddress("MIS333kTeam4@gmail.com", "Longhorn Cinema");
            var toAddress = new MailAddress("MIS333kTeam4@gmail.com", "To Name");
            const string fromPassword = "Password12345!";
            const string subject = "Team 4: Order Confirmation";
            const string WelcomeMessage = "Thank you for placing an order!";
            string NameString = Convert.ToString(user1);
            string body = string.Concat(new string[] { WelcomeMessage, " ", NameString });


            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                Credentials = new NetworkCredential(fromAddress.Address, fromPassword),
                Timeout = 20000
            };
            using (var message = new MailMessage(fromAddress, toAddress)
            {
                Subject = subject,
                Body = body
            })
            {
                smtp.Send(message);
            }



            //  return View();

            return RedirectToAction("Details", "Orders", new { id = order.OrderID });
        }


        public ActionResult RemoveFromOrder(int OrderID)
        {
            Order order = db.Orders.Find(OrderID);

            if(order == null)
            {
                return RedirectToAction("Details", new { id = OrderID });
            }
            if(order.Tickets.Count == 0)
            {
                return RedirectToAction("Details", new { id = OrderID });
            }

            return View(order.Tickets);
        }

        // GET: Orders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        // POST: Orders/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "OrderID,OrderNumber,OrderDate,Gift,GiftEmail")] Order order)
        {
            if (ModelState.IsValid)
            {
                db.Entry(order).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(order);
        }

        public ActionResult CreditCardView(int? OrderID)
        {
            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);

            user.CreditCards.ToList();


            return View();

        }

        public ActionResult Cancel(int? OrderID)
        {
            if (OrderID == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(OrderID);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        [HttpPost, ActionName("Cancel")]
        [ValidateAntiForgeryToken]
        public ActionResult CancelConfirmed(int OrderID)
        {
            Order order = db.Orders.Find(OrderID);

            List<Ticket> OrderTickets = order.Tickets.ToList();

            Int32 PopcornCount = 0;

            foreach(Ticket t in OrderTickets)
            {
                if(t.PaymentMethod == PaymentMethod.PopcornPoints)
                {
                    PopcornCount += 1;
                }

                t.Seat = "A0";
            }

            Int32 RefundPoints = PopcornCount * 100;

            AppUser user = order.AppUser;

            user.PopcornPoints += RefundPoints;

            db.SaveChanges();

            order.Status = OrderStatus.Cancelled;

            db.SaveChanges();
            return RedirectToAction("Index");
        }


        // GET: Orders/Delete/5
        public ActionResult Delete(int? OrderID)
        {
            if (OrderID == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(OrderID);
            if (order == null)
            {
                return HttpNotFound();
            }
            return View(order);
        }

        // POST: Orders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int OrderID)
        {
            Order order = db.Orders.Find(OrderID);

            List<Ticket> OrderTickets = order.Tickets.ToList();

            foreach (Ticket t in OrderTickets)
            {
                db.Tickets.Remove(t);
                
            }
            db.SaveChanges();

            db.Orders.Remove(order);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }




    }
}
