﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Final_Project.DAL;
using Final_Project.Models;
using System.Net;
using System.Data.Entity;
using Microsoft.AspNet.Identity;
using System.Net.Mail;
using System.Threading.Tasks;

namespace Final_Project.Controllers
{
    public class HomeController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Home
        public ActionResult Index(String SearchString)
        {
            List<Movie> SelectedMovies = new List<Movie>();

            var query = from r in db.Movies select r;

            if (SearchString != null)
            {
                query = query.Where(r => r.Title.Contains(SearchString) || r.Overview.Contains(SearchString));
            }

            SelectedMovies = query.ToList();

            ViewBag.TotalMovies = db.Movies.Count();
            ViewBag.SelectedMovies = SelectedMovies.Count();

            return View(SelectedMovies.OrderByDescending(r => r.Title));
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Movie movie = db.Movies.Find(id);
            if (movie == null)
            {
                return HttpNotFound();
            }
            return View(movie);
        }

        public ActionResult Reviews(int? id)
        {
            Movie movie = db.Movies.Find(id);

            var query = from r in db.Reviews select r;
            query = query.Where(r => r.Movie.MovieID == id);

            return View(query.ToList());
        }

        public ActionResult DetailedSearch()
        {
            ViewBag.AllGenres = GetAllGenres();

            return View();

        }

        public ActionResult DisplaySearchResults(String SearchTitle, String SearchTag, String SearchOverview, int[] SelectedGenres, RatingType SelectedMPAA, String SearchRating, String SelectedOperator, DateTime? SelectedDate, String SearchActors)
        {
            var query = from r in db.Movies select r;

            if (SearchTitle != null)
            {
                query = query.Where(r => r.Title.Contains(SearchTitle));
            }

            if (SearchTag != null)
            {
                query = query.Where(r => r.Tagline.Contains(SearchTag));
            }

            if (SearchOverview != null)
            {
                query = query.Where(r => r.Overview.Contains(SearchOverview));
            }

            if(SelectedGenres != null)
            {
                foreach (int i in SelectedGenres)
                {
                    query = query.Where(r => r.Genres.Any(g => g.GenreID == i));
                }
            }


            if (SelectedMPAA != RatingType.None)
            {
                query = query.Where(r => r.MPAARating == SelectedMPAA);
            }

            //
            if (SearchRating != null && SearchRating != "")
            {
                Decimal decRating;
                try
                {
                    decRating = Convert.ToDecimal(SearchRating);

                    query = query.Where(r => r.TotalReviews != 0);


                    if (SelectedOperator == "Greater")
                    {
                        query = query.Where(r => (r.TotalStars/r.TotalReviews) >= decRating);
                    }
                    else
                    {
                        query = query.Where(r => (r.TotalStars/r.TotalReviews) <= decRating);
                    }
                }
                catch
                {
                    ViewBag.AllGenres = GetAllGenres();
                    return View("DetailedSearch");
                }
            }

            if (SelectedDate != null)
            {
                DateTime selDate = SelectedDate ?? new DateTime(1900, 1, 1); 
                query = query.Where(r => r.ReleaseDate.Year == selDate.Year);
            }


            List<Movie> MoviesToDisplay = query.ToList();
            MoviesToDisplay.OrderByDescending(r => r.Title);

            ViewBag.TotalMovies = db.Movies.Count();
            ViewBag.SelectedMovies = MoviesToDisplay.Count();

            return View("Index", MoviesToDisplay);
        }

        public MultiSelectList GetAllGenres()
        {
            List<Genre> Genres = db.Genres.ToList();

            MultiSelectList AllGenres = new MultiSelectList(Genres.OrderBy(g => g.GenreID), "GenreID", "Name");

            return AllGenres;
        }


        // GET: ManagerUsers
        public ActionResult CustomerHome()
        {
            //String UserID = User.Identity.GetUserId();
            //List<Order> Orders = db.Orders.Where(o => o.AppUser.Id == UserID).ToList();
            //return View(Orders);

            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);

            return View(user);
        }


        // GET: CustomerProfile edit
        public ActionResult CustomerHomeEdit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppUser appUser = db.Users.Find(id);
            if (appUser == null)
            {
                return HttpNotFound();
            }
            return View(appUser);
        }

        // POST: CustomerProfile edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CustomerHomeEdit([Bind(Include = "Id,FirstName,LastName,Password,MiddleInitial,Birthday,Address,City,State,Zip,PopcornPoints,CreditCardNumber,TypeOfEmployee,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName")] AppUser appUser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(appUser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(appUser);
        }



        // GET: EmployeeProfile
        public ActionResult EmployeeHome()
        {
            //String UserID = User.Identity.GetUserId();
            //List<Order> Orders = db.Orders.Where(o => o.AppUser.Id == UserID).ToList();
            //return View(Orders);

            String UserID = User.Identity.GetUserId();
            AppUser user = db.Users.FirstOrDefault(u => u.Id == UserID);

            return View(user);
        }


        // GET: EmployeeProfile edit
        public ActionResult EmployeeHomeEdit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AppUser appUser = db.Users.Find(id);
            if (appUser == null)
            {
                return HttpNotFound();
            }
            return View(appUser);
        }

        // POST: EmployeeProfile edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EmployeeHomeEdit([Bind(Include = "Id,FirstName,LastName,Password,MiddleInitial,Birthday,Address,City,State,Zip,PopcornPoints,CreditCardNumber,TypeOfEmployee,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName")] AppUser appUser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(appUser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(appUser);
        }




    }
}