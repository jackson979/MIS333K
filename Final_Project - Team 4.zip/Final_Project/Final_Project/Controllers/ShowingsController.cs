﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Final_Project.DAL;
using Final_Project.Models;
using Newtonsoft.Json;

namespace Final_Project.Controllers
{
    public class JsonData
    {
        public string type { get; set; }
        public string label { get; set; }
        public string backgroundColor { get; set; }
        public IList<double> data { get; set; }
    }

    public enum Theater { TheaterOne, TheaterTwo }

    public class ShowingsController : Controller
    {
        private AppDbContext db = new AppDbContext();

        public String QueryMovieNames(int? day)
        {
            List<Showing> TheaterOneShowings = new List<Showing>();
            List<Showing> TheaterTwoShowings = new List<Showing>();

            var query = from r in db.Showings select r;

            var oneQuery = query.Where(r => r.Theater == 1);
            TheaterOneShowings = oneQuery.Where(r => r.StartTime.Day == day).ToList();

            var twoQuery = query.Where(r => r.Theater == 2);
            TheaterTwoShowings = twoQuery.Where(r => r.StartTime.Day == day).ToList();

            TheaterOneShowings.OrderBy(r => r.StartTime);
            TheaterTwoShowings.OrderBy(r => r.StartTime);

            List<String> TheaterMovieOne = new List<String>();
            List<String> TheaterMovieTwo = new List<String>();
            List<List<String>> AllMovies = new List<List<String>>();

            for (int i = 0; i < TheaterOneShowings.Count; i++)
            {
                TheaterMovieOne.Add(" ");
                TheaterMovieOne.Add(TheaterOneShowings[i].Movie.Title);
                
            }
            for (int i = 0; i < TheaterTwoShowings.Count; i++)
            {
                TheaterMovieTwo.Add(" ");
                TheaterMovieTwo.Add(TheaterTwoShowings[i].Movie.Title);
            }
            AllMovies.Add(TheaterMovieOne);
            AllMovies.Add(TheaterMovieTwo);

            var jsonDatas = JsonConvert.SerializeObject(AllMovies);
            System.Diagnostics.Debug.WriteLine(jsonDatas);

            return jsonDatas;
        }

        public String querymovies(int? day)
        {

            List<Showing> AllShowings = new List<Showing>();
            List<Showing> TheaterOneShowings = new List<Showing>();
            List<Showing> TheaterTwoShowings = new List<Showing>();
            System.Diagnostics.Debug.WriteLine("days");
            System.Diagnostics.Debug.WriteLine(day);

            var query = from r in db.Showings select r;
            query = query.Where(r => r.StartTime.Day == day);
            AllShowings = query.ToList();
            AllShowings.Sort((x, y) => x.StartTime.CompareTo(y.StartTime));

            /*for (int i = 0; i < 3; i++)
            {
                System.Diagnostics.Debug.WriteLine(AllShowings[i].StartTime);
            }*/

            if (AllShowings.Count != 0)
            {



                TheaterOneShowings = query.Where(r => r.Theater == 1).ToList();
                TheaterOneShowings.Sort((x, y) => x.StartTime.CompareTo(y.StartTime));
                TheaterTwoShowings = query.Where(r => r.Theater == 2).ToList();
                TheaterTwoShowings.Sort((x, y) => x.StartTime.CompareTo(y.StartTime));
                


                Theater LargerTheater = Theater.TheaterOne;
                int LargerTheaterCount = TheaterOneShowings.Count;
                int SmallerTheaterCount = TheaterOneShowings.Count;

                if (TheaterOneShowings.Count >= TheaterTwoShowings.Count)
                {
                    LargerTheater = Theater.TheaterOne;
                    LargerTheaterCount = TheaterOneShowings.Count;
                    SmallerTheaterCount = TheaterTwoShowings.Count;
                }
                else if (TheaterTwoShowings.Count > TheaterOneShowings.Count)
                {
                    LargerTheater = Theater.TheaterTwo;
                    LargerTheaterCount = TheaterTwoShowings.Count;
                    SmallerTheaterCount = TheaterOneShowings.Count;
                }





                List<JsonData> jsonList = new List<JsonData>();

                DateTime TOnePrevShowing = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);
                DateTime TTwoPrevShowing = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);

                for (int i = 0; i < SmallerTheaterCount; i++)
                {
                    //calculate white for theater 1
                    int TOneHours = (TheaterOneShowings[i].StartTime.Hour - TOnePrevShowing.Hour);
                    int TOneMinutes = TheaterOneShowings[i].StartTime.Minute - TOnePrevShowing.Minute;

                    double TOneTotalWhite = TOneMinutes / 60.0 + TOneHours;

                    //calculate white for theater 2
                    int TTwoHours = (TheaterTwoShowings[i].StartTime.Hour - TTwoPrevShowing.Hour);
                    int TTwoMinutes = TheaterTwoShowings[i].StartTime.Minute - TTwoPrevShowing.Minute;

                    double TTwoTotalWhite = TTwoMinutes / 60.0 + TTwoHours;


                    //add white
                    JsonData barData = new JsonData
                    {
                        type = "bar",
                        label = "Dataset " + (i + 1).ToString(),
                        backgroundColor = "rgba(255, 255, 255, 0.0)",
                        data = new List<double>
                    {
                        TOneTotalWhite , TTwoTotalWhite
                    }
                    };

                    jsonList.Add(barData);

                    //add movie
                    JsonData barData2 = new JsonData
                    {
                        type = "bar",
                        label = "Dataset " + (i + 1).ToString(),
                        backgroundColor = "rgba(255, 99, 132, 1.0)",
                        data = new List<double>
                    {
                        TheaterOneShowings[i].Movie.Duration / 60.0  , TheaterTwoShowings[i].Movie.Duration / 60.0
                    }
                    };

                    jsonList.Add(barData2);

                    //setting next PrevShowing
                    TOnePrevShowing = TheaterOneShowings[i].StartTime.AddMinutes(TheaterOneShowings[i].Movie.Duration);
                    TTwoPrevShowing = TheaterTwoShowings[i].StartTime.AddMinutes(TheaterOneShowings[i].Movie.Duration);
                }



                List<Showing> TheaterShowings = new List<Showing>();
                if (LargerTheater == Theater.TheaterOne)
                {
                   TheaterShowings = TheaterOneShowings;
                }
                else
                {
                    TheaterShowings = TheaterTwoShowings;
                }


                int PrevCount = SmallerTheaterCount;

                DateTime PrevShowing;

                if (SmallerTheaterCount == 0)
                {
                    PrevCount = 1;
                    PrevShowing = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 0, 0);

                }
                else
                {
                    PrevShowing = TheaterShowings[PrevCount - 1].StartTime.AddMinutes(TheaterShowings[PrevCount - 1].Movie.Duration);

                }
                System.Diagnostics.Debug.WriteLine("check " + SmallerTheaterCount.ToString() + LargerTheaterCount.ToString() + TheaterShowings.Count.ToString());
                

                for (int i = SmallerTheaterCount; i < LargerTheaterCount; i++)
                {
                    
                    //calculate white for theater 1
                    int WhiteeHours = (TheaterShowings[i].StartTime.Hour - PrevShowing.Hour);
                    int WhiteMinutes = TheaterShowings[i].StartTime.Minute - PrevShowing.Minute;
                    double TotalWhite = WhiteMinutes / 60.0 + WhiteeHours;
                    System.Diagnostics.Debug.WriteLine(i.ToString() + " " + TotalWhite.ToString());

                    //add white
                    if (LargerTheater == Theater.TheaterOne)
                    {
                        JsonData barData = new JsonData
                        {
                            type = "bar",
                            label = "Dataset " + (i + 1).ToString(),
                            backgroundColor = "rgba(255, 255, 255, 0.0)",
                            data = new List<double>
                             {
                                  TotalWhite , 0
                             }
                        };
                        jsonList.Add(barData);

                        //add movie
                        JsonData barData2 = new JsonData
                        {
                            type = "bar",
                            label = "Dataset " + (i + 1).ToString(),
                            backgroundColor = "rgba(255, 99, 132, 1.0)",
                            data = new List<double>
                             {
                                  TheaterShowings[i].Movie.Duration / 60.0  , 0
                              }
                        };

                        jsonList.Add(barData2);
                        PrevShowing = TheaterShowings[i].StartTime.AddMinutes(TheaterShowings[i].Movie.Duration);
                    }
                    else
                    {
                        JsonData barData = new JsonData
                        {
                            type = "bar",
                            label = "Dataset " + (i + 1).ToString(),
                            backgroundColor = "rgba(255, 255, 255, 0.0)",
                            data = new List<double>
                    {
                         0 , TotalWhite
                    }
                        };
                        jsonList.Add(barData);

                        //add movie
                        JsonData barData2 = new JsonData
                        {
                            type = "bar",
                            label = "Dataset " + (i + 1).ToString(),
                            backgroundColor = "rgba(255, 99, 132, 1.0)",
                            data = new List<double>
                    {
                        0 , TheaterShowings[i].Movie.Duration / 60.0
                    }
                        };

                        jsonList.Add(barData2);
                        PrevShowing = TheaterShowings[i].StartTime.AddMinutes(TheaterShowings[i].Movie.Duration);
                    }


                }
                var jsonData = JsonConvert.SerializeObject(jsonList);
                System.Diagnostics.Debug.WriteLine(jsonData);
                return jsonData;
            }
            var jsonDatas = JsonConvert.SerializeObject("[{ }]");
            System.Diagnostics.Debug.WriteLine(jsonDatas);
            return jsonDatas;

        }

        public ActionResult Manage(int? day)
        {
            if (day <= 7)
            {
                ViewData["weekBool"] = 1;
                ViewData["dayBool"] = day;
                ViewData["MoviesList"] = QueryMovieNames(day);
                System.Diagnostics.Debug.WriteLine("less");
                System.Diagnostics.Debug.WriteLine(day);
            }
            else if (day > 7)
            {
                ViewData["weekBool"] = 2;
                ViewData["dayBool"] = day - 10;
                ViewData["MoviesList"] = QueryMovieNames(day);
                System.Diagnostics.Debug.WriteLine("greater");
                System.Diagnostics.Debug.WriteLine(day);
            }
            else if (day == null)
            {
                ViewData["weekBool"] = 2;
                ViewData["dayBool"] = 1;
                ViewData["MoviesList"] = QueryMovieNames(11);
                System.Diagnostics.Debug.WriteLine("null");
                System.Diagnostics.Debug.WriteLine(day);
            }


            ViewBag.AllMovies = GetAllMovies();
            ViewBag.AllTheaterDays = GetAllTheaterDays();
            
            if (day == null)
            {
                day = 11;
            }

            ViewData["FieldsList"] = querymovies(day);
            

            return View();
        }

        [HttpPost]
        public ActionResult AddMovie(Showing showing, Theater SelectedTheater, int SelectedM, DateTime SelectedStartTime, int SelectedDay, int SelectedWeek, Boolean SelectedSpecialEvent)
        {
            
            System.Diagnostics.Debug.WriteLine(SelectedStartTime.ToString() + " " + SelectedDay.ToString());

            int calculatedDay = 29;
            if (SelectedWeek == 1)
            {
                calculatedDay = SelectedDay;
            } 

            else if (SelectedWeek == 2)
            {
                calculatedDay = SelectedDay + 10;
            }

            DateTime CalculatedTime = new DateTime(SelectedStartTime.Year, SelectedStartTime.Month, calculatedDay , SelectedStartTime.Hour, SelectedStartTime.Minute,0);

            //adding special events

            showing.SpecialEvent = SelectedSpecialEvent;

            showing.StartTime = CalculatedTime;
            int theaterInt = 0;
            if (SelectedTheater == Theater.TheaterOne)
            {
                showing.Theater = 1;
                theaterInt = 1;
            }
            else if (SelectedTheater == Theater.TheaterTwo)
            {
                showing.Theater = 2;
                theaterInt = 2;
            }


            Movie movie = db.Movies.Find(SelectedM);
            showing.Movie = movie;


            //check if showing has a valid startTime

            String errorString = CheckValidMovieTime(calculatedDay, theaterInt, showing);

            if (errorString.Length == 0)
            {
                if (ModelState.IsValid)
                {
                    db.Showings.Add(showing);
                    db.SaveChanges();
                }
                else
                {
                    var errors = ModelState.Where(x => x.Value.Errors.Any())

                    .Select(x => new { x.Key, x.Value.Errors });

                    System.Diagnostics.Debug.WriteLine(errors);
                }
            }



            //after model is saved display it
            ViewBag.errorStr = errorString;
            System.Diagnostics.Debug.WriteLine("error");
            System.Diagnostics.Debug.WriteLine(errorString);

            int day = calculatedDay;
            if (day <= 7)
            {
                ViewData["weekBool"] = 1;
                ViewData["dayBool"] = day;
                System.Diagnostics.Debug.WriteLine("less");
                System.Diagnostics.Debug.WriteLine(day);
            }
            else if (day > 7)
            {
                ViewData["weekBool"] = 2;
                ViewData["dayBool"] = day - 10;
                System.Diagnostics.Debug.WriteLine("greater");
                System.Diagnostics.Debug.WriteLine(day);
            }
        

            ViewBag.AllMovies = GetAllMovies();
            ViewBag.AllTheaterDays = GetAllTheaterDays();
            ViewData["FieldsList"] = querymovies(calculatedDay);
            ViewData["MoviesList"] = QueryMovieNames(day);
            return View("~/Views/Showings/Manage.cshtml");
        }

        [HttpPost]
        public ActionResult CopyTheaterDay(Showing showing, String FromTheater, String ToTheater)
        {
            System.Diagnostics.Debug.WriteLine("copy test");
            System.Diagnostics.Debug.WriteLine(FromTheater);
            System.Diagnostics.Debug.WriteLine(ToTheater);

            //convert String to custom days -  1 to 7 for current week and 11 to 17 for next week. Only need next week

            List<String> TheaterDay = new List<String> { "Friday Theater One", "Saturday Theater One", "Sunday Theater One", "Monday Theater One", "Tuesday Theater One", "Wednesday Theater One", "Thursday Theater One", "Friday Theater Two", "Saturday Theater Two", "Sunday Theater Two", "Monday Theater Two", "Tuesday Theater Two", "Wednesday Theater Two", "Thursday Theater Two" };

            int FromDay = 0;
            int ToDay = 0;
            int TheaterF = 0;
            int TheaterT = 0;

            for (int i = 0; i < TheaterDay.Count; i++)
            {
                if ( FromTheater == TheaterDay[i])
                {
                    FromDay = i;
                    if (FromDay > 6)
                    {
                        TheaterF = 2;
                    }
                    else
                    {
                        TheaterF = 1;
                    }
                    //converting to custom days
                    if (FromDay + 1 < 8)
                    {
                        FromDay = (FromDay + 1) + 10;
                    }
                    else
                    {
                        FromDay = FromDay + 1;
                        FromDay = (FromDay - 7) + 10;
                    }
                }

                if (ToTheater == TheaterDay[i])
                {
                    ToDay = i;
                    if (ToDay > 6)
                    {
                        TheaterT = 2;
                    }
                    else
                    {
                        TheaterT = 1;
                    }
                    //converting to custom days
                    if (ToDay + 1 < 8)
                    {
                        ToDay = (ToDay + 1) + 10;
                    }
                    else
                    {
                        ToDay = ToDay + 1;
                        ToDay = (ToDay - 7) + 10;
                    }
                }
            }

            System.Diagnostics.Debug.WriteLine(FromDay);
            System.Diagnostics.Debug.WriteLine(ToDay);
            System.Diagnostics.Debug.WriteLine(TheaterF);
            System.Diagnostics.Debug.WriteLine(TheaterT);


            //query all
            var query = from r in db.Showings select r;
            var queryFrom = query.Where(r => r.StartTime.Day == FromDay);

            //query for the showings in from and make it list
            List<Showing> FromShowings = new List<Showing>();

            FromShowings = queryFrom.Where(r => r.Theater == TheaterF ).ToList();

            //sort showing
            FromShowings.Sort((x, y) => x.StartTime.CompareTo(y.StartTime));


            //query for the showings in from and make it list
            List<Showing> ToShowings = new List<Showing>();
            var queryTo = query.Where(r => r.StartTime.Day == ToDay);

            ToShowings = queryTo.Where(r => r.Theater == TheaterT).ToList();

            //sort showing
            ToShowings.Sort((x, y) => x.StartTime.CompareTo(y.StartTime));

            // Delete all ToShowings
            for (int i = 0; i < ToShowings.Count; i++)
            {
                Showing showings = db.Showings.Find(ToShowings[i].ShowingID);
                db.Showings.Remove(showings);
                db.SaveChanges();
            }

            //copy From Showings To Showing
            for (int i = 0; i < FromShowings.Count; i++)
            {
                //get from showing
                Showing fromShowing = db.Showings.Find(FromShowings[i].ShowingID);

                //ading theater to showing model
                showing.Theater = TheaterT;

                DateTime fromDate = fromShowing.StartTime;

                DateTime toDate  = new DateTime(fromDate.Year, fromDate.Month, ToDay, fromDate.Hour, fromDate.Minute, 0);

                //adding date to showing model
                showing.StartTime = toDate;

                //adding movie to startTIme
                showing.Movie = fromShowing.Movie;

                //adding special events
                showing.SpecialEvent = fromShowing.SpecialEvent;


                if (ModelState.IsValid)
                {
                    db.Showings.Add(showing);
                    db.SaveChanges();

                }
                else
                {
                    var errors = ModelState.Where(x => x.Value.Errors.Any())

                    .Select(x => new { x.Key, x.Value.Errors });

                    System.Diagnostics.Debug.WriteLine(errors);
                }
            }


            //repopulating view
            ViewData["FieldsList"] = querymovies(11);
            ViewData["MoviesList"] = QueryMovieNames(11);
            ViewData["weekBool"] = 2;
            ViewData["dayBool"] = 1;
            ViewBag.AllTheaterDays = GetAllTheaterDays();
            ViewBag.AllMovies = GetAllMovies();

            return View("~/Views/Showings/Manage.cshtml");
        }

        [HttpPost]
        public ActionResult FinalCheck(Showing showing)
        {
            

            //error ViewBag
            String finalError = FinalErrorCheck();
            ViewBag.FinalErrors = finalError;

            if (finalError == "")
            {
                showing.StartTime = DateTime.Now;
                showing.Theater = 3;
                showing.SpecialEvent = false;


                if (ModelState.IsValid)
                {
                    db.Showings.Add(showing);
                    db.SaveChanges();
                }
            }
            

            //repopulating view
            ViewData["FieldsList"] = querymovies(11);
            ViewData["MoviesList"] = QueryMovieNames(11);
            ViewData["weekBool"] = 2;
            ViewData["dayBool"] = 1;
            ViewBag.AllTheaterDays = GetAllTheaterDays();
            ViewBag.AllMovies = GetAllMovies();
            return View("~/Views/Showings/Manage.cshtml");
        }

        public String FinalErrorCheck()
        {
            List<List<String>> Weekdays = new List<List<String>> { };

            List<String> Weekdays1 = new List<String> { "Friday Theater One", "Saturday Theater One", "Sunday Theater One", "Monday Theater One", "Tuesday Theater One", "Wednesday Theater One", "Thursday Theater One" };
            List<String> Weekdays2 = new List<String> { "Friday Theater Two", "Saturday Theater Two", "Sunday Theater Two", "Monday Theater Two", "Tuesday Theater Two", "Wednesday Theater Two", "Thursday Theater Two" };

            Weekdays.Add(Weekdays1);
            Weekdays.Add(Weekdays2);



            //need for loop
            for (int i = 11; i < 18; i++)
            {
                var query = from r in db.Showings select r;
                //filter day
                query = query.Where(r => r.StartTime.Day == i);
                List<Showing> AllShowings = new List<Showing>();

                for (int j = 0; j < 2; j++)
                {
                    AllShowings = query.Where(r => r.Theater == j + 1).ToList();
                    //why am i sorting twice
                    AllShowings.OrderBy(r => r.StartTime);
                    AllShowings.Sort((x, y) => x.StartTime.CompareTo(y.StartTime));

                    //for index of weekdays
                    i -= 11;
                    if (AllShowings.Count == 0)
                    {
                        System.Diagnostics.Debug.WriteLine(Weekdays);
                        return Weekdays[j][i] + " had no movies in it. please add a movie";
                    }


                    //check for startTime
                    if (AllShowings[0].StartTime.Hour > 10)
                    {
                        return "error first movie of day: " + Weekdays[j][i] + " must not start after 10";
                    }
                    //check if the last showing is before 9:30
                    if (AllShowings[AllShowings.Count -1 ].StartTime.Hour < 21 && AllShowings[AllShowings.Count - 1].StartTime.Minute < 30)
                    {
                        return "you must schedule one more movie on: " + Weekdays[j][i];
                    } 
                    else
                    {
                        //get all movies after 9:30
                        var AllShowingsQ = query.Where(r => r.Theater == j);
                        AllShowingsQ = AllShowingsQ.Where(r => r.StartTime.Hour > 21);
                        AllShowingsQ = AllShowingsQ.Where(r => r.StartTime.Minute > 30);
                        List<Showing> showingsAfterNineThrity = AllShowingsQ.ToList();

                        if (showingsAfterNineThrity.Count > 1)
                        {
                            return "you can not have more than one movie past 9:30 pm, this error occured in: " + Weekdays[j][i];
                        }
                    }


                }
            }

            return "";
        }

        public String CheckValidMovieTime(int day, int Theater, Showing newShowing)
        {

            //checking for valid time
            if (newShowing.StartTime.Hour < 9)
            {
                return "cant not add movie before 9am";
            }
        

            var query = from r in db.Showings select r;
            //filter day
            query = query.Where(r => r.StartTime.Day == day);
            List<Showing> AllShowings = new List<Showing>();
            //filter theater
            AllShowings = query.Where(r => r.Theater == Theater).ToList();
            AllShowings.Add(newShowing);
            //why am i sorting twice
            AllShowings.OrderBy(r => r.StartTime);
            AllShowings.Sort((x, y) => x.StartTime.CompareTo(y.StartTime));


            //checking if other theater does not have the movie playing at the same time

            //get other theater list
            var query2 = from r in db.Showings select r;
            //filter day
            query2 = query2.Where(r => r.StartTime.Day == day);
            List<Showing> AllShowings2 = new List<Showing>();

            //get theater
            int newTheater = 0;
            if (Theater == 1)
            {
                newTheater = 2;
            }
            else
            {
                newTheater = 1;
            }

            //filter theater
            AllShowings2 = query.Where(r => r.Theater == newTheater).ToList();
            
            //why am i sorting twice
            AllShowings2.OrderBy(r => r.StartTime);
            AllShowings2.Sort((x, y) => x.StartTime.CompareTo(y.StartTime));

            //check if there is a movie of that time in the other theater
            foreach (Showing showing in AllShowings2)
            {
                if (showing.StartTime == newShowing.StartTime)
                {
                    if (showing.Movie.MovieNumber == newShowing.Movie.MovieNumber)
                    {
                        System.Diagnostics.Debug.WriteLine(showing.Movie.MovieNumber);
                        System.Diagnostics.Debug.WriteLine(newShowing.Theater);
                        return "You can not add this movie, this movie is playing at the same time in the other theater";
                    }
                }
            }





            DateTime minRange = newShowing.StartTime.AddMinutes(-25);
            DateTime maxRange = newShowing.StartTime.AddMinutes(45);

            //finding index of my new showing in sorted list
            int newShowingIndex = 0;
            for (int i = 0; i < AllShowings.Count; i++)
            {
                if (AllShowings[i].ShowingID == newShowing.ShowingID)
                {
                    newShowingIndex = i;
                }
            }


            System.Diagnostics.Debug.WriteLine("Showings Index");
            
            for (int i = 0; i < AllShowings.Count; i++)
            {
                System.Diagnostics.Debug.WriteLine(AllShowings[i].StartTime);
            }

            //change entire approach to checking
            // do based on one showing, not allowed to schedule another shoing thats further than 45 min

            
            if (AllShowings.Count > 1)
            {

                
                // if movie is bottom most movie check if the moive after this one starts after 25 min but not more than 45 min
                if (newShowingIndex == 0)
                {
                    DateTime bottomShowing = AllShowings[newShowingIndex + 1].StartTime;
                    DateTime minRangeAfter = newShowing.StartTime.AddMinutes(25);
                    DateTime maxRangeAfter = newShowing.StartTime.AddMinutes(45);
                    
                    if (maxRangeAfter < bottomShowing)
                    {
                        return "max time of 45 minutes between movies exceeded";
                    }
                    else if ( minRangeAfter > bottomShowing){
                        return "min time of 25 minutes in between movies not met";
                    } 
                }

                //if movue is last showing make sure the movie underneth is far enough away
                else if ( newShowingIndex == AllShowings.Count - 1)
                {
                    DateTime MovieUndernethEndingTime = AllShowings[newShowingIndex -1 ].StartTime.AddMinutes(AllShowings[newShowingIndex -1].Movie.Duration);
                    DateTime minRangeAfter = newShowing.StartTime.AddMinutes(-25);
                    DateTime maxRangeAfter = newShowing.StartTime.AddMinutes(-45);

                    if ( maxRangeAfter > MovieUndernethEndingTime)
                    {
                        return "movie can not be more than 45 min previous movie";
                    }
                    else if (minRangeAfter < MovieUndernethEndingTime)
                    {
                        return "movie can not play less than 25 minutes previous movie";
                    }

                }


                else if (AllShowings.Count > 2)
                {
                    //if someones deleted a movie or just trying to add it in an area of empty space

                    //get before and after movie
                    DateTime PrevMovie = AllShowings[newShowingIndex - 1].StartTime.AddMinutes(AllShowings[newShowingIndex - 1].Movie.Duration);
                    DateTime MovieAfter = AllShowings[newShowingIndex + 1].StartTime;

                    if (newShowing.StartTime.AddMinutes(45) < MovieAfter)
                    {
                        return "can not add movie here. Next movie must play less than 45 minutes than the movie you are trying to add";
                    }
                    if (newShowing.StartTime.AddMinutes(25) > MovieAfter)
                    {
                        return "can not add movie. Next movie must play more than 25 minutes after the movie you are currently trying to add";
                    }
                    if (newShowing.StartTime.AddMinutes(-45) < PrevMovie)
                    {
                        return "can not add movie, the movie before can not play more than 45 minutes before the movie you are trying to add";
                    }
                    if (newShowing.StartTime.AddMinutes(-25) > PrevMovie)
                    {
                        return "can not add movie, the movie before can not play less than 25 minutes before the movie you are trying to add";
                    }



                // if movie is not bottom most movie it must be the top most movie
                    if (newShowing.StartTime < AllShowings[AllShowings.Count - 1].StartTime.AddMinutes(AllShowings[AllShowings.Count - 1].Movie.Duration))
                    {
                        return "you can not add a movie here conflicts with previous ones";
                    }
                }
            }

    
            
            return "";
        }

        public SelectList GetAllMovies()
        {
            List<Movie> Movies = db.Movies.ToList();

            //add a record for all months
            Movie SelectNone = new Models.Movie() { MovieID = 0, Title = "All Movies" };
            Movies.Add(SelectNone);

            //convert list to select list
            SelectList AllMovies = new SelectList(Movies.OrderBy(m => m.Title), "MovieID", "Title");

            //return the select list
            return AllMovies;
        }

        public SelectList GetAllTheaterDays()
        {
            List<int> TheaterDays = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };
            List<String> TheaterDay = new List<String> { "Friday Theater One", "Saturday Theater One", "Sunday Theater One", "Monday Theater One", "Tuesday Theater One", "Wednesday Theater One", "Thursday Theater One", "Friday Theater Two", "Saturday Theater Two", "Sunday Theater Two", "Monday Theater Two", "Tuesday Theater Two", "Wednesday Theater Two", "Thursday Theater Two" };


            //convert list to select list
            SelectList AllTheaterDays = new SelectList(TheaterDay);

            //return the select list
            return AllTheaterDays;
        }
        // GET: Showings
        public ActionResult Index()
        {
            return View(db.Showings.ToList());
        }

        // GET: Showings/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Showing showing = db.Showings.Find(id);
            if (showing == null)
            {
                return HttpNotFound();
            }
            return View(showing);
        }

        // GET: Showings/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Showings/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ShowingID,StartTime,Theater")] Showing showing)
        {
            if (ModelState.IsValid)
            {
                db.Showings.Add(showing);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(showing);
        }

        // GET: Showings/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Showing showing = db.Showings.Find(id);
            if (showing == null)
            {
                return HttpNotFound();
            }
            return View(showing);
        }

        // POST: Showings/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ShowingID,StartTime,Theater")] Showing showing)
        {
            if (ModelState.IsValid)
            {
                db.Entry(showing).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(showing);
        }

        // GET: Showings/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Showing showing = db.Showings.Find(id);
            if (showing == null)
            {
                return HttpNotFound();
            }
            return View(showing);
        }

        // POST: Showings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Showing showing = db.Showings.Find(id);
            db.Showings.Remove(showing);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
