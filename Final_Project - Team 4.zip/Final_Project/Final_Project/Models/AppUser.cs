﻿using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Final_Project.Models
{
    public enum EmpType { Customer, Employee, Manager }
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.

    //NOTE: This is the class for users
    public class AppUser : IdentityUser
    {
        //TODO: Put any additional fields that you need for your user here
        //First name is here as an example
        [Required(ErrorMessage = "First name is required.")]
        [Display(Name = "First Name")]
        public String FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required.")]
        [Display(Name = "Last Name")]
        public String LastName { get; set; }

        public String Password { get; set; }

        public String MiddleInitial { get; set; }

        [Required(ErrorMessage = "Birthday is required.")]
        [DataType(DataType.Date, ErrorMessage = "Invalid date.")]
        [Display(Name = "Birthday")]
        public DateTime Birthday { get; set; }

        //[Required(ErrorMessage = "Address is required.")]
        public String Address { get; set; }

        public bool IsNotActive { get; set; }

        [Required(ErrorMessage = "City is required.")]
        public String City { get; set; }

        //[Required(ErrorMessage = "State is required.")]
        public String State { get; set; }

        [Required(ErrorMessage = "Zip code is required.")]
        [RegularExpression(@"([0-9]+)", ErrorMessage = "Invalid zipcode.")]
        [MaxLength(5), MinLength(5)]
        public String Zip { get; set; }

        //[Required(ErrorMessage = "Please enter your email address")]
        //[RegularExpression(".+\\@.+\\..+",
        //ErrorMessage = "Please enter a valid email address")]
        //public string Email { get; set; }

        //[Required(ErrorMessage = "Popcorn points are required.")]
        public Int32 PopcornPoints { get; set; }

        //[CreditCard(AcceptedCardTypes = CreditCardAttribute.CardType.Visa | CreditCardAttribute.CardType.MasterCard | CreditCardAttribute.CardType.Amex | CreditCardAttribute.CardType.Discover)]
        //public string CreditCardNumber { get; set; }

        [Display(Name = "Employee Type")]
        public EmpType TypeOfEmployee { get; set; }

        //TODO: Add any navigational properties needed for your user
        //Orders is here as an example
        //public virtual List<Order> Orders { get; set; }

        public virtual List<Movie> Movies { get; set; }
        public virtual List<Showing> Showings { get; set; }
        public virtual List<Review> Reviews { get; set; }
        public virtual List<Order> Orders { get; set; }
        public virtual List<CreditCard> CreditCards { get; set; }

        public AppUser()
        {
            if(Movies == null)
            {
                Movies = new List<Movie>();
            }
            if (Showings == null)
            {
                Showings = new List<Showing>();
            }
            if (Reviews == null)
            {
                Reviews = new List<Review>();
            }
            if (Orders == null)
            {
                Orders = new List<Order>();
            }
        }


        //This method allows you to create a new user
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<AppUser> manager)
        {
            // NOTE: The authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
    }
}