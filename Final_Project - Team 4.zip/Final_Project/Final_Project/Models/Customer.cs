﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace Final_Project.Models
{
    public class Customer
    {
        [Required(ErrorMessage = "Customer ID is required.")]
        public Int32 CustomerID { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        public String Password { get; set; }

        [Required(ErrorMessage = "First Name is required.")]
        public String FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required.")]
        public String LastName { get; set; }

        public String MiddleInitial { get; set; }

        [Required(ErrorMessage = "Birthday is required.")]
        [DataType(DataType.Date, ErrorMessage = "Invalid date.")]
        [Display(Name = "Birthday")]
        public DateTime Birthday { get; set; }

        //[Required(ErrorMessage = "Please enter the established date")]
        //[DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        //public DateTime Date { get; set; }

        [Required(ErrorMessage = "Street is required.")]
        public String Street { get; set; }

        [Required(ErrorMessage = "City is required.")]
        public String City { get; set; }

        [Required(ErrorMessage = "State is required.")]
        public String State { get; set; }

        [Required(ErrorMessage = "Zip code is required.")]
        public String Zip { get; set; }

        public String SSN { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [RegularExpression(".+\\@.+\\..+",
        ErrorMessage = "Please enter a valid email address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Popcorn points are required.")]
        public Int32 PopcornPoints { get; set; }

        public virtual List<Movie> Movies { get; set; }
        public virtual AppUser AppUser { get; set; }


    }


}