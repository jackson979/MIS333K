﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Final_Project.Models
{
    public class RoleEditModel
    {
        [Key]
        public Int32 RoleEditID { get; set; }

        public AppRole Role { get; set; }
        public IEnumerable<AppUser> Members { get; set; }
        public IEnumerable<AppUser> NonMembers { get; set; }

        public virtual AppUser AppUser { get; set; }
    }

    public class RoleModificationModel
    {
        [Key]
        public Int32 RoleModificationID { get; set; }

        [Required]
        public string RoleName { get; set; }
        public string[] IdsToAdd { get; set; }
        public string[] IdsToDelete { get; set; }

        public virtual AppUser AppUser { get; set; }
    }
}