﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Final_Project.Models
{
    //public enum VendorTypes { UNSPECIFIED, GENERAL, SPECIALTY, CUSTOM }
    public enum RatingType { None, Unrated, G, PG, PG13, R, NC17}


    public class Movie
    {
        [Required(ErrorMessage = "Movie ID is required.")]
        public Int32 MovieID { get; set; }

        public Int32 MovieNumber { get; set; }

        [Required(ErrorMessage = "Title is required.")]
        public String Title { get; set; }

        [Required(ErrorMessage = "Overview is required.")]
        public String Overview { get; set; }

        [Required(ErrorMessage = "Release date is required.")]
        [DataType(DataType.Date, ErrorMessage = "Invalid date.")]
        [Display(Name = "Release Date")]
        public DateTime ReleaseDate { get; set; }

        [Required(ErrorMessage ="Revenue is required.")]
        public Decimal Revenue { get; set; }

        [Required(ErrorMessage ="Duration is required.")]
        public Int32 Duration { get; set; }

        [Required(ErrorMessage ="Tagline is required.")]
        public String Tagline { get; set; }

        //[Required(ErrorMessage = "Rating is required.")]
        //[Display(Name = "MPAA Rating")]
        //public String Rating { get; set; }

        [Required(ErrorMessage = "Actors are required.")]
        public String Actors { get; set; }

        [Required(ErrorMessage = "Rating is required.")]
        [Display(Name = "MPAA Rating")]
        public RatingType MPAARating { get; set; }


        public Decimal TotalStars { get; set; }

        public Decimal TotalReviews { get; set; }

        //public Decimal AverageReviews
        //{
        //    get { return TotalStars/TotalReviews; }
        //}

        public virtual List<Genre> Genres { get; set; }

        public virtual List<Showing> Showings { get; set; }

        public virtual AppUser AppUser { get; set; }


        public Movie()
        {
            if (Genres == null)
            {
                Genres = new List<Genre>();
            }
            if (Showings == null)
            {
                Showings = new List<Showing>();
            }
        }
    }
}