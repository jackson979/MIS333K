﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Final_Project.Models
{
    public class Showing
    {
        [Required(ErrorMessage = "Showings ID is required.")]
        public Int32 ShowingID { get; set; }

        [Required(ErrorMessage = "Start Time is required.")]
        public DateTime StartTime { get; set; }

        [Required(ErrorMessage = "Theater is required.")]
        public Int32 Theater { get; set; }

        [Required(ErrorMessage = "Special Event is required.")]
        public Boolean SpecialEvent { get; set; }

        public String DisplayName
        {
            get
            {
                String name = Movie.Title;
                String hour = StartTime.Hour.ToString();
                String min = StartTime.Minute.ToString();

                if(min.Length == 1)
                {
                    min = "0" + min;
                }

                String display = name + "    " + hour + ":" + min;

                return display;
            }
        }

        public virtual Movie Movie { get; set; }

        public virtual AppUser AppUser { get; set; }

        public virtual List<Ticket> Tickets { get; set; }

        public Showing()
        {
            if (Tickets == null)
            {
                Tickets = new List<Ticket>();
            }
        }
    }
}