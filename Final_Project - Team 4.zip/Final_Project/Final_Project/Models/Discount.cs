﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Final_Project.Models
{
    public class Discount
    {
        public Int32 DiscountID { get; set; }

        [Required(ErrorMessage ="Discount name is required.")]
        public String Name { get; set; }

        [Required(ErrorMessage = "Discount amount is required.")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal Amount { get; set; }

        public virtual List<Ticket> Tickets { get; set; }

        public Discount()
        {
            if (Tickets == null)
            {
                Tickets = new List<Ticket>();
            }
        }
    }
}