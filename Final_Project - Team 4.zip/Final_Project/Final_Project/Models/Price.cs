﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Final_Project.Models
{
    public class Price
    {
        public Int32 PriceID { get; set; }

        [Required(ErrorMessage = "Description is required.")]
        public String Description { get; set; }

        [Required(ErrorMessage = "Discount amount is required.")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal Amount { get; set; }
    }
}