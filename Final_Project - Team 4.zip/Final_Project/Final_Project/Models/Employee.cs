﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace Final_Project.Models
{
    //public enum EmpType { Employee, Manager }

    public class Employee
    {
        [Required(ErrorMessage = "Employee ID is required.")]
        public Int32 EmployeeID { get; set; }

        [Required(ErrorMessage = "Last name is required.")]
        public String LastName { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        public String FirstName { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        public String Password { get; set; }

        [Required(ErrorMessage = "SSN is required.")]
        public String SSN { get; set; }

        [Required(ErrorMessage = "Address is required.")]
        public String Address { get; set; }

        [Required(ErrorMessage = "City is required.")]
        public String City { get; set; }

        [Required(ErrorMessage = "State is required.")]
        public String State { get; set; }

        [Required(ErrorMessage = "Zip is required.")]
        public String Zip { get; set; }

        [Required(ErrorMessage = "Please enter your phone number")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [RegularExpression(".+\\@.+\\..+",
        ErrorMessage = "Please enter a valid email address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Employee type is required.")]
        [Display(Name = "Employee Type")]
        public EmpType TypeOfEmployee { get; set; }

        public virtual AppUser AppUser { get; set; }
    }
}