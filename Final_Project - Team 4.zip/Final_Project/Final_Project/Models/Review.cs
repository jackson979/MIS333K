﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;


namespace Final_Project.Models
{
    public enum ReviewStatus { Pending, Confirmed, Cancelled }

    public class Review
    {
        public Int32 ReviewID { get; set; }

        [Display(Name = "Rating")]
        public Decimal decStars { get; set; }

        [Display(Name = "Review")]
        [StringLength(100, ErrorMessage = "Review cannot be longer than 100 characters.")]
        public String ReviewText { get; set; }

        public Boolean Approved { get; set; }

        public ReviewStatus Status { get; set; }

        public virtual Movie Movie { get; set; }

        public virtual AppUser AppUser { get; set; }
    }
}