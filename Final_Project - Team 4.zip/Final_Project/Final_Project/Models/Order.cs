using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Final_Project.Models
{
    public enum OrderStatus { Pending, Confirmed, Cancelled }

    public class Order
    {
        private const Decimal TAX_RATE = .0825m;

        public Int32 OrderID { get; set; }

        [Display(Name = "Order Number")]
        public Int32 OrderNumber { get; set; }

        [Display(Name = "Order Date")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime OrderDate { get; set; }
	
	    [Required]
        public Boolean Gift { get; set; }

	    [DataType(DataType.EmailAddress)]
	    public String GiftEmail {get; set; }

        [Display(Name = "Order Subtotal")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal OrderSubtotal
        {
            get { return Tickets.Sum(t => t.TotalPrice); }
        }

        [Display(Name = "Tax (8.25%)")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal Tax
        {
            get { return OrderSubtotal * TAX_RATE; }
        }

        [Display(Name = "Order Total")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal OrderTotal
        {
            get { return OrderSubtotal + Tax; }
        }

        public OrderStatus Status { get; set; }

        public virtual List<Ticket> Tickets { get; set; }
	 
	    public virtual AppUser AppUser { get; set; }

        public virtual CreditCard CreditCard { get; set; }


        public Order()
        {
            if (Tickets == null)
            {
                Tickets = new List<Ticket>();
            }
        }
    }
}