using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Final_Project.Models
{
    public enum PaymentMethod { CreditCard, PopcornPoints }

    public class Ticket
    {
        public Int32 TicketID { get; set; }

        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal Price { get; set; }

        [Display(Name = "Total Price")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal TotalPrice { get; set; }
        
	    public String Seat { get; set; }

        public PaymentMethod PaymentMethod { get; set; }

        public virtual Showing Showing { get; set; }
        public virtual Order Order { get; set; }
        public virtual List<Discount> Discounts { get; set; }

        public Ticket()
        {
            if(Discounts == null)
            {
                Discounts = new List<Discount>();
            }
        }
    }
}