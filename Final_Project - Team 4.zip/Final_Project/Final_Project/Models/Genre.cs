﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Final_Project.Models
{
    public class Genre
    {
        [Required(ErrorMessage = "Genre ID is required.")]
        public Int32 GenreID { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        public String Name { get; set; }

        public virtual List<Movie> Movies { get; set; }
        public virtual AppUser AppUser { get; set; }


        public Genre()
        {
            if(Movies == null)
            {
                Movies = new List<Movie>();
            }
        }
    }
}