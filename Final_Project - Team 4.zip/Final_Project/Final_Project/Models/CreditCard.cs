﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Final_Project.Models
{
    public enum CardType { Visa, MasterCard, Amex, Discover }

    public class CreditCard
    {
        public Int32 CreditCardID { get; set; }

        [Display(Name = "Card Number")]
        public string CreditCardNumber { get; set; }

        [Display(Name = "Card Type")]

        public CardType TypeOfCard { get; set; }

        public String CVV { get; set; }


        public virtual List<AppUser> AppUsers { get; set; }
        public virtual List<Order> Orders { get; set; }

        public CreditCard()
        {
            if (AppUsers == null)
            {
                AppUsers = new List<AppUser>();
            }
            if(Orders == null)
            {
                Orders = new List<Order>();
            }
        }
    }
}