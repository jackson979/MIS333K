﻿using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.Entity;

using Final_Project.Models;


namespace Final_Project.DAL
{
    // NOTE: Here's your db context for the project.  All of your db sets should go in here
    public class AppDbContext : IdentityDbContext<AppUser>
    {
        public AppDbContext()
            : base("MyDBConnection", throwIfV1Schema: false) { }

        public static AppDbContext Create()
        {
            return new AppDbContext();
        }

        // TODO: Add dbsets here. Remember, Identity adds a db set for users, 
        //so you shouldn't add that one - you will get an error
        //here's a sample for products
        public DbSet<Genre> Genres { get; set; }
        public DbSet<Movie> Movies { get; set; }
        //public DbSet<Customer> Customers { get; set; }
        //public DbSet<Employee> Employees { get; set; }
        public DbSet<Showing> Showings { get; set; }
        public DbSet<Ticket> Tickets { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Review> Reviews { get; set; }
        public DbSet<Discount> Discounts { get; set; }
        public DbSet<Price> Prices { get; set; }
        public DbSet<CreditCard> CreditCards { get; set; }


        //public DbSet<AppUser> AppUsers { get; set; }
        public DbSet<LoginViewModel> LoginViewModels { get; set; }
        public DbSet<RegisterViewModel> RegisterViewModels { get; set; }
        public DbSet<ChangePasswordViewModel> ChangePasswordViewModels { get; set; }
        public DbSet<IndexViewModel> IndexViewModels { get; set; }
        public DbSet<AppRole> AppRoles { get; set; }
        public DbSet<AppRoleManager> AppRoleManagers { get; set; }
        public DbSet<RoleModificationModel> RoleModificationModels { get; set; }
        public DbSet<RoleEditModel> RoleEditModels { get; set; }

        //public System.Data.Entity.DbSet<Final_Project.Models.AppUser> AppUsers { get; set; }

        //public System.Data.Entity.DbSet<Final_Project.Models.CreditCard> CreditCards { get; set; }

        //public System.Data.Entity.DbSet<Final_Project.Models.AppUser> AppUsers { get; set; }

        //NOTE: This is a dbSet that you need to make roles work
        //public DbSet<AppRole> AppRoles { get; set; }
    }
}





