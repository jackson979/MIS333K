﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ross_Jackson_HW7.DAL;
using Ross_Jackson_HW7.Models;

namespace Ross_Jackson_HW7.Utilities
{
    public static class GenerateProductNumber
    {
        public static Int32 GetNextProductNumber()
        {
            AppDbContext db = new AppDbContext();

            Int32 intMaxProductNumber;
            Int32 intNextProductNumber;

            if (db.Products.Count() == 0)
            {
                intMaxProductNumber = 5000;
            }
            else
            {
                intMaxProductNumber = db.Products.Max(p => p.ProductNumber);
            }

            intNextProductNumber = intMaxProductNumber + 1;

            return intNextProductNumber;

        }
    }
}