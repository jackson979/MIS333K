using Ross_Jackson_HW7.Migrations;

namespace Ross_Jackson_HW7.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Ross_Jackson_HW7.DAL.AppDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Ross_Jackson_HW7.DAL.AppDbContext context)
        {
            SeedIdentity si = new SeedIdentity();
            si.AddAdmin(context);
        }
    }
}
