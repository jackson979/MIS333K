﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Ross_Jackson_HW7.DAL;
using Ross_Jackson_HW7.Models;
using Microsoft.AspNet.Identity;

namespace Ross_Jackson_HW7.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Orders
        public ActionResult Index()
        {
            if (User.IsInRole("Manager"))
            {
                return View(db.Orders.ToList());
            }

            else
            {
                String UserID = User.Identity.GetUserId();

                List<Order> Orders = db.Orders.Where(o => o.AppUser.Id == UserID).ToList();

                return View(Orders);
            }
        }

        // GET: Orders/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }

            if (User.IsInRole("Manager") || order.AppUser.Id == User.Identity.GetUserId())
            {
                return View(order);
            }
            else
            {
                return View("Error", new string[] { "This is not your order!" });
            }
        }

        // GET: Orders/AddToOrder
        public ActionResult AddToOrder(int OrderID)
        {
            OrderDetail od = new OrderDetail();

            Order order = db.Orders.Find(OrderID);

            od.Order = order;

            ViewBag.AllProducts = GetProducts();
            return View(od);
        }

        //POST: Orders/AddToOrder
        [HttpPost]
        public ActionResult AddToOrder(OrderDetail od, int SelectedProduct)
        {
            Product product = db.Products.Find(SelectedProduct);

            od.Product = product;

            Order order = db.Orders.Find(od.Order.OrderID);

            od.Order = order;

            od.Price = product.Price;

            od.TotalPrice = od.Price * od.Quantity;

            if(ModelState.IsValid)
            {
                db.OrderDetails.Add(od);
                db.SaveChanges();
                return RedirectToAction("Details", "Orders", new { id = order.OrderID });
            }

            ViewBag.AllProducts = GetProducts();
            return View(od);

        }

        //GET: Orders/RemoveFromOrder
        public ActionResult RemoveFromOrder(int OrderID)
        {
            Order order = db.Orders.Find(OrderID);

            if (order == null)
            {
                return RedirectToAction("Details", new { id = OrderID });
            }
            if (order.OrderDetails.Count == 0)
            {
                return RedirectToAction("Details", new { id = OrderID });
            }

            return View(order.OrderDetails);
        }

        public SelectList GetProducts()
        {
            List<Product> allProducts = db.Products.OrderBy(p => p.ProductName).ToList();

            SelectList selProducts = new SelectList(allProducts, "ProductID", "ProductName");

            return selProducts;
        }

        // GET: Orders/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Orders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "OrderID,OrderNumber,OrderDate,Notes")] Order order)
        {
            order.OrderNumber = Utilities.GenerateNextOrderNumber.GetNextOrderNumber();
            String UserID = User.Identity.GetUserId();
            order.AppUser = db.Users.Where(u => u.Id == UserID).First();
            order.OrderDate = DateTime.Today;

            if (ModelState.IsValid)
            {
                db.Orders.Add(order);
                db.SaveChanges();
                return RedirectToAction("AddToOrder", new { OrderID = order.OrderID});
            }

            return View(order);
        }

        // GET: Orders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Order order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }
            if (User.IsInRole("Manager") || order.AppUser.Id == User.Identity.GetUserId())
            {
                return View(order);
            }
            else
            {
                return View("Error", new string[] { "This is not your order!" });
            }
        }

        // POST: Orders/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "OrderID,OrderNumber,OrderDate,Notes")] Order order)
        {
            if (ModelState.IsValid)
            {
                db.Entry(order).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(order);
        }

        //// GET: Orders/Delete/5
        //public ActionResult Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Order order = db.Orders.Find(id);
        //    if (order == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(order);
        //}

        //// POST: Orders/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    Order order = db.Orders.Find(id);
        //    db.Orders.Remove(order);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
