﻿//Author:       Jackson Ross (jrr4557)
//Date:         January 30, 2018
//Assignment:   Homework 1
//Description:  This program will take a customer code from the user and validate the input. After entering a successful code, the user can enter the number or puzzles and board games they would like to purchase. The program then prints them a bill, including service charge and subtotals.

//default imported libraries
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//create project namespace
namespace Ross_Jackson_HW1
{
    //define the main Program class
    class Program
    {
        //define the main method
        static void Main(string[] args)
        {
            //create str variables for user input
            String strCodeInput;
            String strPuzzleInput;
            String strGameInput;

            //create boolean variable to check customer code
            Boolean boolCodeCheck;

            //create int variables for the purchase quantities
            Int32 intPuzzles;
            Int32 intGames;
            Int32 intTotalItems;

            //create decimal variables for the totals and service charge
            Decimal decServiceCharge;
            Decimal decPuzzleSubtotal;
            Decimal decGameSubtotal;
            Decimal decSubtotal;
            Decimal decGrandTotal;
            
            //create constants for for the prices and service fee percentage
            const Decimal decPUZZLEPRICE = 8.00m;
            const Decimal decGAMEPRICE = 12.00m;
            const Decimal decSERVICEFEE = .0325m;

            //begin do-while loop that will run until CheckCode() returns true
            do
            {
                //prompt user to enter code and store the input
                Console.WriteLine("Enter a valid customer code.");
                strCodeInput = Console.ReadLine();
                Console.WriteLine();

                //call the CheckCode method, passing it the code from the user; stores returned value
                boolCodeCheck = CheckCode(strCodeInput);

            } while (boolCodeCheck == false);

            //begin do-while loop that will run until the user has purchased at least one item
            do
            {
                //begin do-while loop that will run until the user enters a non-negative value
                do
                {
                    //prompt user to enter a quantity and store the input
                    Console.WriteLine("Enter the number of puzzles you would like to purchase.");
                    strPuzzleInput = Console.ReadLine();
                    Console.WriteLine();

                    //call the CheckNum method, passing it the quantity from the user; stores the returned value
                    intPuzzles = CheckNum(strPuzzleInput);

                    //if the flag value has been returned, print an error message before re-prompting
                    if (intPuzzles == -1)
                    {
                        Console.WriteLine("Invalid number of puzzles. Please enter a positive integer or zero.");
                        Console.WriteLine();
                    }

                } while (intPuzzles == -1);

                //begin do-while loop that will run until the user enters a non-negative value
                do
                {
                    //prompt user to enter a quantity and store the input
                    Console.WriteLine("Enter the number of games you would like to purchase.");
                    strGameInput = Console.ReadLine();
                    Console.WriteLine();

                    //call the CheckNum method, passing it the quantity from the user; stores the returned value
                    intGames = CheckNum(strGameInput);

                    //if the flag value has been returned, print an error message before re-prompting
                    if (intGames == -1)
                    {
                        Console.WriteLine("Invalid number of board games. Please enter a positive integer or zero.");
                        Console.WriteLine();
                    }

                } while (intGames == -1);

                //calculate total items
                intTotalItems = intPuzzles + intGames;

                //if the user enters 0 for both items
                if (intTotalItems == 0)
                {
                    //print a message telling them to purchase at least one item
                    Console.WriteLine("Invalid number of items. Please purchase at least one item.");
                    Console.WriteLine();
                }
            } while (intTotalItems == 0);

            //convert customer code to all upper case
            strCodeInput = strCodeInput.ToUpper();

            //calculate the subtotals using the price constants
            decPuzzleSubtotal = intPuzzles * decPUZZLEPRICE;
            decGameSubtotal = intGames * decGAMEPRICE;

            //add up the smaller subtotals to get the real subtotal
            decSubtotal = decPuzzleSubtotal + decGameSubtotal;

            //calculate the service charge using the fee constant
            decServiceCharge = decSERVICEFEE * decSubtotal;

            //add the service charge to the subtotal to get the grand total
            decGrandTotal = decSubtotal + decServiceCharge;

            //convert all of the monetary values to strings using ToString(), using the 'C' format ($ and 2 decimals) so it can be printed
            String strPuzzleSubtotal = decPuzzleSubtotal.ToString("C");
            String strGameSubtotal = decGameSubtotal.ToString("C");
            String strSubtotal = decSubtotal.ToString("C");
            String strServiceCharge = decServiceCharge.ToString("C");
            String strGrandTotal = decGrandTotal.ToString("C");

            //print out the receipt (customer code, total items, subtotals, service charge, and grand total)
            Console.WriteLine("Customer Code:\t\t" + strCodeInput);
            Console.WriteLine("Total Items:\t\t" + intTotalItems);
            Console.WriteLine("Puzzle Subtotal:\t" + strPuzzleSubtotal);
            Console.WriteLine("Board Game Subtotal:\t" + strGameSubtotal);
            Console.WriteLine("Subtotal:\t\t" + strSubtotal);
            Console.WriteLine("Service Charge:\t\t" + strServiceCharge);
            Console.WriteLine("Grand Total:\t\t" + strGrandTotal);
            Console.WriteLine();

            //code to keep the window open at the end
            Console.WriteLine("Press any key to exit.");
            Console.Read();
        }

        //define the CheckCode method; will be passed a string from the main method and will return a boolean
        public static Boolean CheckCode(String strCodeInput)
        {
            //create a variable and define it as the length of the string (using .Length)
            Int32 intLength = strCodeInput.Length;

            //check to see if the code is shorter than 5 characters or longer than 7 characters; if it is, return false
            if (intLength < 5 || intLength > 7)
            {
                return false;
            }

            //for loop that will look at each individual character of the string
            foreach (char b in strCodeInput)
            {
                //if the character is not a letter, return false
                if (!Char.IsLetter(b))
                {
                    return false;
                }
            }

            //return true if there is no fault in the code
            return true;
        }

        //define the CheckNum method; will be passed a string from the main method and will return an int
        public static Int16 CheckNum(String strPurchaseInput)
        {
            //create int variable to store the converted number
            Int16 intResult;

            //try to convert the user's input into a number
            try
            {
                intResult = Convert.ToInt16(strPurchaseInput);
            }
            //if the try block fails, return -1 (the flag value for the input validation)
            catch
            {
                return -1;
            }

            //if the number the user entered was negative, return -1 (impossible to buy negative items)
            if (intResult < 0)
            {
                return -1;
            }
            //if the number is non-negative, return the converted int
            else
            {
                return intResult;
            }
        }
    }
}
