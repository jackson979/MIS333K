﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Ross_Jackson_HW6.DAL;
using Ross_Jackson_HW6.Models;

namespace Ross_Jackson_HW6.Controllers
{
    public class ProductsController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Products
        public ActionResult Index()
        {
            return View(db.Products.ToList());
        }

        // GET: Products/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // GET: Products/Create
        public ActionResult Create()
        {
            ViewBag.Vendors = GetVendors();
            return View();
        }

        public MultiSelectList GetVendors()
        {
            List<Vendor> allVendors = db.Vendors.OrderBy(v => v.Name).ToList();

            MultiSelectList selVendors = new MultiSelectList(allVendors, "VendorID", "Name");

            return selVendors;
        }

        public MultiSelectList GetVendors(Product product)
        {
            List<Vendor> allVendors = db.Vendors.OrderBy(v => v.Name).ToList();

            //convert list of selected departments to ints
            List<Int32> SelectedVendors = new List<Int32>();

            //loop through the course's departments and add the department id
            foreach (Vendor vendor in product.Vendors)
            {
                SelectedVendors.Add(vendor.VendorID);
            }

            //create the multiselect list
            MultiSelectList selVendors = new MultiSelectList(allVendors, "VendorID", "Name", SelectedVendors);

            //return the multiselect list
            return selVendors;
        }

        // POST: Products/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ProductID,ProductNumber,ProductName,Price,Description")] Product product, int[] SelectedVendors)
        {
            product.ProductNumber = Utilities.GenerateProductNumber.GetNextProductNumber();

            foreach (int i in SelectedVendors)
            {
                Vendor vendor = db.Vendors.Find(i);
                product.Vendors.Add(vendor);
            }


            if (ModelState.IsValid)
            {
                db.Products.Add(product);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Vendors = GetVendors();
            return View(product);
        }

        // GET: Products/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            ViewBag.Vendors = GetVendors(product);
            return View(product);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ProductID,ProductNumber,ProductName,Price,Description")] Product product, int[] SelectedVendors)
        {
            if (ModelState.IsValid)
            {
                Product productToChange = db.Products.Find(product.ProductID);

                productToChange.Vendors.Clear();

                foreach (int index in SelectedVendors)
                {
                    Vendor vendor = db.Vendors.Find(index);
                    productToChange.Vendors.Add(vendor);
                }

                productToChange.Price = product.Price;
                productToChange.ProductName = product.ProductName;
                productToChange.Description = product.Description;

                db.Entry(productToChange).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Vendors = GetVendors(product);
            return View(product);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
