﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ross_Jackson_HW6.Models;
using System.Data.Entity;

namespace Ross_Jackson_HW6.DAL
{
    public class AppDbContext : DbContext
    {
        //Constructor that invokes the base constructor
        public AppDbContext() : base("MyDBConnection") { }

        //Create the db set
        public DbSet<Vendor> Vendors { get; set; }

        public DbSet<Product> Products { get; set; }

        public DbSet<Order> Orders { get; set; }

        public DbSet<OrderDetail> OrderDetails { get; set; }
    }
}