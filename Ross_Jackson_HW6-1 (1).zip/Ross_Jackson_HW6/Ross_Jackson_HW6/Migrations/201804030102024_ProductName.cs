namespace Ross_Jackson_HW6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ProductName : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Products", "ProductName", c => c.String(nullable: false));
            DropColumn("dbo.Products", "CourseName");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Products", "CourseName", c => c.String(nullable: false));
            DropColumn("dbo.Products", "ProductName");
        }
    }
}
