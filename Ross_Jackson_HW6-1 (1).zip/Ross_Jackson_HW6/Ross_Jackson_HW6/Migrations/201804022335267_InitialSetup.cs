namespace Ross_Jackson_HW6.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialSetup : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.OrderDetails",
                c => new
                    {
                        OrderDetailID = c.Int(nullable: false, identity: true),
                        Quantity = c.Int(nullable: false),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        TotalPrice = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Order_OrderID = c.Int(),
                        Product_ProductID = c.Int(),
                    })
                .PrimaryKey(t => t.OrderDetailID)
                .ForeignKey("dbo.Orders", t => t.Order_OrderID)
                .ForeignKey("dbo.Products", t => t.Product_ProductID)
                .Index(t => t.Order_OrderID)
                .Index(t => t.Product_ProductID);
            
            CreateTable(
                "dbo.Orders",
                c => new
                    {
                        OrderID = c.Int(nullable: false, identity: true),
                        OrderNumber = c.Int(nullable: false),
                        OrderDate = c.DateTime(nullable: false),
                        Notes = c.String(),
                    })
                .PrimaryKey(t => t.OrderID);
            
            CreateTable(
                "dbo.Products",
                c => new
                    {
                        ProductID = c.Int(nullable: false, identity: true),
                        ProductNumber = c.Int(nullable: false),
                        CourseName = c.String(nullable: false),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Description = c.String(),
                    })
                .PrimaryKey(t => t.ProductID);
            
            //CreateTable(
            //    "dbo.Vendors",
            //    c => new
            //        {
            //            VendorID = c.Int(nullable: false, identity: true),
            //            Name = c.String(nullable: false),
            //            Email = c.String(nullable: false),
            //            PhoneNumber = c.String(nullable: false),
            //            EstablishedDate = c.String(nullable: false),
            //            PreferredVendor = c.Boolean(nullable: false),
            //            VendorType = c.Int(nullable: false),
            //            Notes = c.String(),
            //        })
            //    .PrimaryKey(t => t.VendorID);
            
            CreateTable(
                "dbo.VendorProducts",
                c => new
                    {
                        Vendor_VendorID = c.Int(nullable: false),
                        Product_ProductID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Vendor_VendorID, t.Product_ProductID })
                .ForeignKey("dbo.Vendors", t => t.Vendor_VendorID, cascadeDelete: true)
                .ForeignKey("dbo.Products", t => t.Product_ProductID, cascadeDelete: true)
                .Index(t => t.Vendor_VendorID)
                .Index(t => t.Product_ProductID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.VendorProducts", "Product_ProductID", "dbo.Products");
            DropForeignKey("dbo.VendorProducts", "Vendor_VendorID", "dbo.Vendors");
            DropForeignKey("dbo.OrderDetails", "Product_ProductID", "dbo.Products");
            DropForeignKey("dbo.OrderDetails", "Order_OrderID", "dbo.Orders");
            DropIndex("dbo.VendorProducts", new[] { "Product_ProductID" });
            DropIndex("dbo.VendorProducts", new[] { "Vendor_VendorID" });
            DropIndex("dbo.OrderDetails", new[] { "Product_ProductID" });
            DropIndex("dbo.OrderDetails", new[] { "Order_OrderID" });
            DropTable("dbo.VendorProducts");
            DropTable("dbo.Vendors");
            DropTable("dbo.Products");
            DropTable("dbo.Orders");
            DropTable("dbo.OrderDetails");
        }
    }
}
