﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Ross_Jackson_HW6.Models
{
    public enum VendorTypes { UNSPECIFIED, GENERAL, SPECIALTY, CUSTOM }

    public class Vendor
    {
        [Required (ErrorMessage = "Customer ID is required.")]
        [Display(Name = "Customer ID")]
        public Int32 VendorID { get; set; }

        [Required(ErrorMessage = "Name is required.")]
        [Display(Name = "Name")]
        public String Name { get; set; }

        [Required(ErrorMessage = "Email address is required.")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Invalid email format.")]
        [Display(Name = "Email Address")]
        public String Email { get; set; }

        [Required(ErrorMessage = "Phone number is required.")]
        [DataType(DataType.PhoneNumber, ErrorMessage = "Invalid phone number.")]
        [Display(Name = "Phone Number")]
        public String PhoneNumber { get; set; }

        [Required(ErrorMessage = "Established date is required.")]
        [DataType(DataType.Date, ErrorMessage = "Invalid date.")]
        [Display(Name = "Established Date")]
        public String EstablishedDate { get; set; }

        [Required(ErrorMessage = "Customer status is required.")]
        [Display(Name = "Preffered Customer")]
        public Boolean PreferredVendor { get; set; }

        [Required(ErrorMessage = "Vendor type is required.")]
        [Display(Name = "Vendor Type")]
        public VendorTypes VendorType { get; set; }

        [Display(Name = "Notes (Optional)")]
        public String Notes { get; set; }

        public virtual List<Product> Products { get; set; }

        public Vendor()
        {
            if (Products == null)
            {
                Products = new List<Product>();
            }
        }
    }
}