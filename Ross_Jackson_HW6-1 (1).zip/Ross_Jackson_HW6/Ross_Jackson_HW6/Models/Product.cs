﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Ross_Jackson_HW6.Models
{
    public class Product
    {
        public Int32 ProductID { get; set; }

        [Display(Name = "Product Number")]
        public Int32 ProductNumber { get; set; }

        [Required(ErrorMessage = "Product name is required.")]
        [Display(Name = "Product Name")]
        public String ProductName { get; set; }

        [Required(ErrorMessage = "Price is required.")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal Price { get; set; }
        
        public String Description { get; set; }

        public virtual List<Vendor> Vendors { get; set; }
        public virtual List<OrderDetail> OrderDetails { get; set; }

        public Product()
        {
            if (Vendors == null)
            {
                Vendors = new List<Vendor>();
            }

            if (OrderDetails == null)
            {
                OrderDetails = new List<OrderDetail>();
            }
        }
    }
}