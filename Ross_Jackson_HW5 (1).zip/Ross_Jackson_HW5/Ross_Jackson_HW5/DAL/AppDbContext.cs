﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ross_Jackson_HW5.Models;
using System.Data.Entity;

namespace Ross_Jackson_HW5.DAL
{
    public class AppDbContext : DbContext
    {
        //Constructor that invokes the base constructor
        public AppDbContext() : base("MyDBConnection") { }

        //Create the db set
        public DbSet<Repository> Repositories { get; set; }
        public DbSet<Language> Languages { get; set; }
    }
}