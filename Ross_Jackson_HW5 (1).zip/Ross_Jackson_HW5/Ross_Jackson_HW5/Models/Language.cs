﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Ross_Jackson_HW5.Models
{
    public class Language
    {
        public Int32 LanguageID { get; set; }

        [Display(Name = "Language")]
        public String Name { get; set; }

        public List<Repository> Repositories { get; set; }
    }
}