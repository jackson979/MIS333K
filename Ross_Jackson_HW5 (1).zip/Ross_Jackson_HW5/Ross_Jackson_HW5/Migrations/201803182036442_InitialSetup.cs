namespace Ross_Jackson_HW5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialSetup : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Languages",
                c => new
                    {
                        LanguageID = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.LanguageID);
            
            CreateTable(
                "dbo.Repositories",
                c => new
                    {
                        RepositoryID = c.Int(nullable: false, identity: true),
                        UserName = c.String(),
                        RepositoryName = c.String(),
                        Description = c.String(),
                        Tags = c.String(),
                        URL = c.String(),
                        LastUpdate = c.DateTime(nullable: false),
                        StarCount = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Language_LanguageID = c.Int(),
                    })
                .PrimaryKey(t => t.RepositoryID)
                .ForeignKey("dbo.Languages", t => t.Language_LanguageID)
                .Index(t => t.Language_LanguageID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Repositories", "Language_LanguageID", "dbo.Languages");
            DropIndex("dbo.Repositories", new[] { "Language_LanguageID" });
            DropTable("dbo.Repositories");
            DropTable("dbo.Languages");
        }
    }
}
