using Ross_Jackson_HW5.Models;
using Ross_Jackson_HW5.DAL;
using System.Data.Entity.Migrations;
using System.Linq;

namespace Ross_Jackson_HW5.Migrations
{
	public class LanguageData
	{
		public void SeedLanguages(AppDbContext db)
		{
			Language lang1 = new Language();
			lang1.Name = "Assembly";
			db.Languages.AddOrUpdate(l => l.Name, lang1);
			db.SaveChanges();

			Language lang2 = new Language();
			lang2.Name = "C";
			db.Languages.AddOrUpdate(l => l.Name, lang2);
			db.SaveChanges();

			Language lang3 = new Language();
			lang3.Name = "C++";
			db.Languages.AddOrUpdate(l => l.Name, lang3);
			db.SaveChanges();

			Language lang4 = new Language();
			lang4.Name = "Clojure";
			db.Languages.AddOrUpdate(l => l.Name, lang4);
			db.SaveChanges();

			Language lang5 = new Language();
			lang5.Name = "CoffeeScript";
			db.Languages.AddOrUpdate(l => l.Name, lang5);
			db.SaveChanges();

			Language lang6 = new Language();
			lang6.Name = "CSS";
			db.Languages.AddOrUpdate(l => l.Name, lang6);
			db.SaveChanges();

			Language lang7 = new Language();
			lang7.Name = "Go";
			db.Languages.AddOrUpdate(l => l.Name, lang7);
			db.SaveChanges();

			Language lang8 = new Language();
			lang8.Name = "HTML";
			db.Languages.AddOrUpdate(l => l.Name, lang8);
			db.SaveChanges();

			Language lang9 = new Language();
			lang9.Name = "Java";
			db.Languages.AddOrUpdate(l => l.Name, lang9);
			db.SaveChanges();

			Language lang10 = new Language();
			lang10.Name = "JavaScript";
			db.Languages.AddOrUpdate(l => l.Name, lang10);
			db.SaveChanges();

			Language lang11 = new Language();
			lang11.Name = "Objective-C";
			db.Languages.AddOrUpdate(l => l.Name, lang11);
			db.SaveChanges();

			Language lang12 = new Language();
			lang12.Name = "Objective-C++";
			db.Languages.AddOrUpdate(l => l.Name, lang12);
			db.SaveChanges();

			Language lang13 = new Language();
			lang13.Name = "PHP";
			db.Languages.AddOrUpdate(l => l.Name, lang13);
			db.SaveChanges();

			Language lang14 = new Language();
			lang14.Name = "Python";
			db.Languages.AddOrUpdate(l => l.Name, lang14);
			db.SaveChanges();

			Language lang15 = new Language();
			lang15.Name = "Ruby";
			db.Languages.AddOrUpdate(l => l.Name, lang15);
			db.SaveChanges();

			Language lang16 = new Language();
			lang16.Name = "Rust";
			db.Languages.AddOrUpdate(l => l.Name, lang16);
			db.SaveChanges();

			Language lang17 = new Language();
			lang17.Name = "Shell";
			db.Languages.AddOrUpdate(l => l.Name, lang17);
			db.SaveChanges();

			Language lang18 = new Language();
			lang18.Name = "Swift";
			db.Languages.AddOrUpdate(l => l.Name, lang18);
			db.SaveChanges();

			Language lang19 = new Language();
			lang19.Name = "TypeScript";
			db.Languages.AddOrUpdate(l => l.Name, lang19);
			db.SaveChanges();

			Language lang20 = new Language();
			lang20.Name = "Unspecified";
			db.Languages.AddOrUpdate(l => l.Name, lang20);
			db.SaveChanges();

			Language lang21 = new Language();
			lang21.Name = "Vim script";
			db.Languages.AddOrUpdate(l => l.Name, lang21);
			db.SaveChanges();

		}
	}
}
