﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Ross_Jackson_HW5.DAL;
using Ross_Jackson_HW5.Models;

namespace Ross_Jackson_HW5.Controllers
{
    public class HomeController : Controller
    {
        private AppDbContext db = new AppDbContext();

        // GET: Home
        public ActionResult Index(String SearchString)
        {
            List<Repository> SelectedRepositories = new List<Repository>();

            var query = from r in db.Repositories select r;

            if (SearchString != null)
            {
                query = query.Where(r => r.RepositoryName.Contains(SearchString) || r.UserName.Contains(SearchString));
            }

            SelectedRepositories = query.ToList();

            ViewBag.TotalRepositories = db.Repositories.Count();
            ViewBag.SelectedRepositories = SelectedRepositories.Count();

            return View(SelectedRepositories.OrderByDescending(r => r.StarCount));
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Repository repository = db.Repositories.Find(id);
            if (repository == null)
            {
                return HttpNotFound();
            }
            return View(repository);
        }

        public ActionResult DetailedSearch()
        {
            ViewBag.AllLanguages = GetAllLanguages();

            return View();

        }

        public ActionResult DisplaySearchResults(String SearchName, String SearchDescription, int SelectedLanguage, String SearchStars, String SelectedOperator, DateTime? SelectedDate)
        {
            var query = from r in db.Repositories select r;

            if (SearchName != null)
            {
                query = query.Where(r => r.RepositoryName.Contains(SearchName) || r.UserName.Contains(SearchName));
            }

            if (SearchDescription != null)
            {
                query = query.Where(r => r.Description.Contains(SearchDescription));
            }

            if (SelectedLanguage >= 0)
            {
                if (SelectedLanguage != 0)
                {
                    query = query.Where(r => r.Language.LanguageID == SelectedLanguage);
                }
            }
            if (SearchStars != null && SearchStars != "")
            {
                Decimal decStars;
                try
                {
                    decStars = Convert.ToDecimal(SearchStars);

                    if (SelectedOperator == "Greater")
                    {
                        query = query.Where(r => r.StarCount >= decStars);
                    }
                    else
                    {
                        query = query.Where(r => r.StarCount <= decStars);
                    }
                }
                catch
                {
                    ViewBag.AllLanguages = GetAllLanguages();
                    return View("DetailedSearch");
                }
            }

            if (SelectedDate != null)
            {
                query = query.Where(r => r.LastUpdate >= SelectedDate);
            }


            List<Repository> RepositoriesToDisplay = query.ToList();
            RepositoriesToDisplay.OrderByDescending(r => r.StarCount);

            ViewBag.TotalRepositories = db.Repositories.Count();
            ViewBag.SelectedRepositories = RepositoriesToDisplay.Count();

            return View("Index", RepositoriesToDisplay);
        }

        public SelectList GetAllLanguages()
        {
            List<Language> Languages = db.Languages.ToList();

            Language SelectNone = new Models.Language() { LanguageID = 0, Name = "All Languages" };

            Languages.Add(SelectNone);

            SelectList AllLanguages = new SelectList(Languages.OrderBy(l => l.LanguageID), "LanguageID", "Name");

            return AllLanguages;
        }
    }
}